import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Send, Loader2, MessageCircle, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "مرحباً! أنا مساعدك الذكي في مجال الأمان الرقمي. كيف يمكنني مساعدتك اليوم؟",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // Generate AI response using keyword matching
      // In production, this would call the LLM API via tRPC
      const assistantResponse = generateResponse(input);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: assistantResponse,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Save interaction to database (optional - for analytics)
      // This would be a tRPC call in production
      if (user) {
        console.log("AI Interaction saved:", {
          userId: user.id,
          question: input,
          answer: assistantResponse,
        });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage: Message = {
        id: (Date.now() + 2).toString(),
        role: "assistant",
        content: "عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateResponse = (userInput: string): string => {
    const lowerInput = userInput.toLowerCase();

    // Comprehensive response map
    const responseMap: { [key: string]: string } = {
      "كلمة مرور":
        "كلمة مرور قوية يجب أن تحتوي على 12 حرف على الأقل، وتجمع بين الأحرف الكبيرة والصغيرة والأرقام والرموز. تجنب استخدام معلومات شخصية أو كلمات قاموسية.",
      احتيال:
        "الاحتيال الإلكتروني (Phishing) هو محاولة الحصول على معلومات شخصية من خلال خداع. تجنبه بعدم الضغط على روابط مريبة والتحقق من عنوان البريد الإلكتروني.",
      أمان:
        "الأمان الرقمي يتضمن حماية بيانات شخصية وأجهزة من الهجمات والسرقة والاحتيال. استخدم كلمات مرور قوية وحدّث برامجك بانتظام.",
      wifi:
        "لتأمين شبكة WiFi: استخدم كلمة مرور قوية، فعّل التشفير WPA3، وغيّر كلمة المرور الافتراضية. أخف اسم الشبكة (SSID) إذا أمكن.",
      خصوصية:
        "حماية خصوصيتك: استخدم إعدادات الخصوصية على وسائل التواصل، وتحكم في من يرى معلوماتك. لا تشارك معلومات حساسة علناً.",
      برامج:
        "البرامج الضارة (Malware) تشمل الفيروسات والديدان وحصان طروادة. حماية نفسك: استخدم برنامج حماية موثوق، لا تحمّل من مصادر غير موثوقة.",
      "ثنائي":
        "المصادقة الثنائية (2FA) توفر طبقة أمان إضافية. بعد إدخال كلمة المرور، تحتاج إلى إدخال رمز من هاتفك أو تطبيق.",
      vpn: "شبكة VPN تشفر اتصالك وتخفي عنوان IP الخاص بك. استخدمها على الشبكات العامة لحماية بيانات حساسة.",
      default:
        "سؤال جيد! يمكنك معرفة المزيد عن هذا الموضوع من خلال دروسنا وفيديوهاتنا التعليمية. هل تريد معرفة المزيد عن موضوع معين؟",
    };

    // Check for keywords in the user input
    for (const [key, value] of Object.entries(responseMap)) {
      if (lowerInput.includes(key)) {
        return value;
      }
    }

    return responseMap.default;
  };

  const suggestedQuestions = [
    "كيف أحمي كلمات مروري؟",
    "ما هو الاحتيال الإلكتروني؟",
    "كيف أأمن شبكتي المنزلية؟",
    "ما هي أفضل ممارسات الأمان الرقمي؟",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-600 to-green-600 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="h-8 w-8" />
            <h1 className="text-4xl font-bold">🤖 المساعد الذكي</h1>
          </div>
          <p className="text-cyan-100">
            اسأل أي سؤال عن الأمان الرقمي والحماية الإلكترونية
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8 h-screen flex flex-col">
        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto mb-6 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                  message.role === "user"
                    ? "bg-pink-600 text-white rounded-br-none"
                    : "bg-slate-700 text-gray-100 rounded-bl-none"
                }`}
              >
                <p className="text-sm leading-relaxed">{message.content}</p>
                <p className="text-xs mt-2 opacity-70">
                  {message.timestamp.toLocaleTimeString("ar-SA", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-700 px-4 py-3 rounded-lg rounded-bl-none flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm">جاري الكتابة...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="mb-6">
            <p className="text-sm text-gray-400 mb-3">أسئلة مقترحة:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {suggestedQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setInput(question);
                  }}
                  className="text-left p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors text-sm"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Form */}
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <Input
            type="text"
            placeholder="اكتب سؤالك هنا..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-slate-700 border-slate-600 text-white placeholder-gray-400"
          />
          <Button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-green-600 hover:bg-green-700 gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                إرسال
              </>
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
