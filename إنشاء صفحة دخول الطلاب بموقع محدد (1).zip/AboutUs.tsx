/**
 * صفحة من نحن
 * Design Philosophy: حديث آمن وموثوق مع ألوان داكنة ولمسات نيون زاهية
 */

import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowRight } from "lucide-react";

export default function AboutUs() {
  const [, navigate] = useLocation();

  const goals = [
    {
      icon: "🎯",
      title: "التوعية الرقمية",
      description:
        "نشر الوعي بأهمية الأمان الرقمي والحماية من المخاطر الإلكترونية",
    },
    {
      icon: "🛡️",
      title: "الحماية والأمان",
      description:
        "توفير أدوات وموارد عملية لحماية البيانات الشخصية والخصوصية",
    },
    {
      icon: "📚",
      title: "التعليم المستمر",
      description:
        "تقديم محتوى تعليمي شامل يغطي جميع جوانب الأمان الرقمي",
    },
    {
      icon: "👥",
      title: "بناء المجتمع",
      description:
        "خلق مجتمع آمن يتشارك المعرفة والخبرات في الفضاء الرقمي",
    },
    {
      icon: "💡",
      title: "الابتكار والتطور",
      description:
        "تطوير حلول مبتكرة لمواجهة التحديات الرقمية الناشئة",
    },
    {
      icon: "🌍",
      title: "الوصول العام",
      description:
        "توفير محتوى مجاني وسهل الوصول لجميع فئات المجتمع",
    },
  ];

  const values = [
    {
      title: "الشفافية",
      description: "نؤمن بالتواصل الواضح والصادق مع مجتمعنا",
    },
    {
      title: "الموثوقية",
      description: "نقدم معلومات دقيقة وموثوقة من مصادر موثوقة",
    },
    {
      title: "الشمول",
      description: "نستهدف جميع الفئات العمرية والخلفيات التعليمية",
    },
    {
      title: "الابتكار",
      description: "نبحث باستمرار عن طرق جديدة وأفضل للتعليم",
    },
  ];

  const stats = [
    { number: "10K+", label: "مستخدم نشط" },
    { number: "50+", label: "درس تعليمي" },
    { number: "100+", label: "ساعة محتوى" },
    { number: "24/7", label: "دعم متاح" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1f2e] via-[#1a3a52] to-[#0a1f2e] text-foreground">
      {/* Header */}
      <header className="border-b border-[#2a5a82] bg-[#0a1f2e]/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-primary hover:text-[#00ffff] transition-colors"
            >
              <span className="text-2xl">🛡️</span>
              <span className="font-bold">Spirit Platform</span>
            </button>
            <nav className="flex items-center gap-6">
              <button
                onClick={() => navigate("/")}
                className="text-foreground hover:text-primary transition-colors"
              >
                الرئيسية
              </button>
              <button
                onClick={() => navigate("/about-us")}
                className="text-primary font-semibold"
              >
                ℹ️ من نحن
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block mb-6 p-4 bg-gradient-to-br from-primary/20 to-[#00ffff]/20 rounded-full border border-primary/30">
            <span className="text-5xl">🛡️</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-[#00ffff] to-primary bg-clip-text text-transparent">
            من نحن
          </h1>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            منصة Spirit Platform متخصصة في الأمان الرقمي والتوعية الإلكترونية، نسعى لحماية وتعليم الجيل الرقمي العربي
          </p>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-[#1a3a52] to-[#0f2a3d] border border-[#2a5a82] rounded-lg p-8 mb-12">
            <h2 className="text-3xl font-bold mb-6 text-primary">عن المشروع</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Spirit Platform هي منصة تعليمية متخصصة في الأمان الرقمي والحماية من المخاطر الإلكترونية. تم تصميمها خصيصاً لتلبية احتياجات المجتمع العربي في عصر التحول الرقمي السريع.
              </p>
              <p>
                نؤمن بأن الأمان الرقمي ليس خياراً بل ضرورة حتمية في عالمنا المتصل. لذلك، نعمل على توفير محتوى تعليمي شامل وسهل الفهم يساعد الجميع على حماية أنفسهم وبياناتهم الشخصية.
              </p>
              <p>
                من خلال دروس تفاعلية وفيديوهات تعليمية ومساعد ذكي، نوفر حلاً متكاملاً لجميع احتياجات التعليم الأمني الرقمي.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="p-6 rounded-lg bg-gradient-to-br from-[#1a3a52] to-[#0f2a3d] border border-[#2a5a82] text-center"
            >
              <div className="text-3xl font-bold text-primary mb-2">
                {stat.number}
              </div>
              <div className="text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Goals Section */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">أهدافنا</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal, index) => (
            <div
              key={index}
              className="p-6 rounded-lg bg-gradient-to-br from-[#1a3a52] to-[#0f2a3d] border border-[#2a5a82] hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="text-4xl mb-4">{goal.icon}</div>
              <h3 className="text-xl font-semibold mb-3 text-primary">
                {goal.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {goal.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">قيمنا الأساسية</h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {values.map((value, index) => (
            <div
              key={index}
              className="p-8 rounded-lg bg-gradient-to-br from-[#1a3a52] to-[#0f2a3d] border border-primary/30"
            >
              <h3 className="text-2xl font-bold mb-3 text-primary">
                {value.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="bg-gradient-to-r from-primary/10 via-[#00ffff]/10 to-primary/10 border border-primary/30 rounded-lg p-12 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">رسالتنا</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            نسعى لتمكين الأفراد والمجتمعات من خلال التعليم والتوعية بالأمان الرقمي، لبناء عالم رقمي أكثر أماناً وثقة للجميع.
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 border border-primary/30 rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">انضم إلينا اليوم</h2>
          <p className="text-lg text-muted-foreground mb-8">
            ابدأ رحلتك نحو الأمان الرقمي مع Spirit Platform
          </p>
          <Button
            onClick={() => navigate("/")}
            className="bg-primary hover:bg-[#00ffff] text-[#0a1f2e] font-semibold px-8 py-6 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-primary/50 flex items-center gap-2 mx-auto"
          >
            العودة للرئيسية
            <ArrowRight size={20} />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#2a5a82] bg-[#0a1f2e]/80 mt-16 py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>© 2025 Spirit Platform - جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
