"use client";

import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Achievements() {
  const { data: achievements, refetch } = trpc.engagement.achievements.byUser.useQuery();
  const { data: badgesFromDb, isLoading: badgesLoading } = trpc.academic.badges.list.useQuery();
  const checkAchievementsMutation = trpc.engagement.achievements.check.useMutation();

  useEffect(() => {
    // Check for new achievements when page loads
    checkAchievementsMutation.mutate();
  }, []);

  const handleCheckAchievements = async () => {
    try {
      await checkAchievementsMutation.mutateAsync();
      refetch();
      toast.success("تم التحقق من الإنجازات!");
    } catch (error) {
      toast.error("حدث خطأ في التحقق من الإنجازات");
    }
  };

  const badges = badgesFromDb || [];
  const earnedBadges = new Set(achievements?.map((a) => a.badge) || []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🏅 الإنجازات والشارات</h1>
          <p className="text-slate-300">
            حصلت على {achievements?.length || 0} من {badges.length} شارات
          </p>
        </div>

        {/* Check Button */}
        <div className="mb-8">
          <Button
            onClick={handleCheckAchievements}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            🔄 التحقق من الإنجازات الجديدة
          </Button>
        </div>

        {/* Progress Bar */}
        {badges.length > 0 && (
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-white font-semibold">التقدم</span>
              <span className="text-purple-400 font-semibold">
                {Math.round(((achievements?.length || 0) / badges.length) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full transition-all"
                style={{
                  width: `${((achievements?.length || 0) / badges.length) * 100}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* Badges Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((badge) => {
            const isEarned = earnedBadges.has(badge.name);
            return (
              <Card
                key={badge.id}
                className={`p-6 text-center transition-all ${
                  isEarned
                    ? "bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/50"
                    : "bg-slate-800/50 border-slate-700 opacity-50"
                }`}
              >
                <div className="text-5xl mb-3">{badge.icon || badge.name.split(" ")[0]}</div>
                <h3 className={`text-lg font-bold mb-2 ${isEarned ? "text-white" : "text-slate-400"}`}>
                  {badge.name}
                </h3>
                <p className={`text-sm ${isEarned ? "text-slate-300" : "text-slate-500"}`}>
                  {badge.description}
                </p>
                {isEarned && (
                  <div className="mt-4">
                    <span className="inline-block px-3 py-1 bg-yellow-500/30 text-yellow-300 rounded-full text-xs font-semibold">
                      ✓ تم إنجازها
                    </span>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {badges.length === 0 && !badgesLoading && (
          <div className="text-center py-12">
            <p className="text-slate-400 text-lg">لا توجد شارات متاحة حالياً</p>
          </div>
        )}
      </div>
    </div>
  );
}
