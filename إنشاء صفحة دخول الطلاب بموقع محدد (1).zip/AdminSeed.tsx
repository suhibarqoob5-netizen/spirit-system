import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function AdminSeed() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const seedMutation = trpc.academic.seedData.useMutation();

  const handleSeed = async () => {
    setLoading(true);
    try {
      const response = await seedMutation.mutateAsync();
      setResult(response);
      console.log("Seed response:", response);
    } catch (error) {
      console.error("Seed error:", error);
      setResult({ success: false, error: String(error) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-2xl mx-auto">
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h1 className="text-2xl font-bold text-white mb-4">Admin Seed Data</h1>
          
          <Button 
            onClick={handleSeed} 
            disabled={loading}
            className="bg-cyan-500 hover:bg-cyan-600 text-white mb-4"
          >
            {loading ? "جاري الإضافة..." : "إضافة البيانات"}
          </Button>

          {result && (
            <div className="mt-4 p-4 bg-slate-700 rounded-lg text-white">
              <pre>{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
