import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import AdminSeed from "@/pages/AdminSeed";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CybersecurityLesson from "./pages/CybersecurityLesson";
import Programs from "./pages/Programs";
import Program from "./pages/Program";
import Level from "./pages/Level";
import Course from "./pages/Course";
import StudentDashboard from "./pages/StudentDashboard";
import Leaderboard from "./pages/Leaderboard";
import Skills from "./pages/Skills";
import Achievements from "./pages/Achievements";
import { HebrewHome } from "./pages/HebrewHome";
import Videos from "./pages/Videos";
import AIAssistant from "./pages/AIAssistant";
import Progress from "./pages/Progress";
import Badges from "./pages/Badges";
import Comments from "./pages/Comments";
import DailyChallenge from "./pages/DailyChallenge";
import News from "./pages/News";
import Notifications from "./pages/Notifications";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Lessons from "./pages/Lessons";
import Lesson from "./pages/Lesson";
import InitializeData from "./pages/InitializeData";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/hebrew" component={HebrewHome} />
      <Route path="/admin/seed" component={AdminSeed} />
      <Route path="/initialize" component={InitializeData} />
      <Route path="/cybersecurity-lesson" component={CybersecurityLesson} />
      <Route path="/dashboard" component={StudentDashboard} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/skills" component={Skills} />
      <Route path="/achievements" component={Achievements} />
      <Route path="/progress" component={Progress} />
      <Route path="/lessons" component={Lessons} />
      <Route path="/lesson/:id" component={Lesson} />
      <Route path="/videos" component={Videos} />
      <Route path="/ai-assistant" component={AIAssistant} />
      <Route path="/badges" component={Badges} />
      <Route path="/comments" component={Comments} />
      <Route path="/daily-challenge" component={DailyChallenge} />
      <Route path="/news" component={News} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/programs" component={Programs} />
      <Route path="/program/:slug" component={Program} />
      <Route path="/level/:id" component={Level} />
      <Route path="/course/:slug" component={Course} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
