import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Clock, MapPin, Shield, TrendingUp } from 'lucide-react';

interface AttackDetail {
  id: number;
  country: string;
  city?: string;
  latitude: number;
  longitude: number;
  attackCount: number;
  severity: 'منخفضة' | 'متوسطة' | 'عالية' | 'حرجة';
  threatType?: string;
  timestamp: number;
}

interface AttackDetailModalProps {
  attack: AttackDetail | null;
  isOpen: boolean;
  onClose: () => void;
}

const severityColors = {
  'منخفضة': 'bg-green-100 text-green-800',
  'متوسطة': 'bg-yellow-100 text-yellow-800',
  'عالية': 'bg-orange-100 text-orange-800',
  'حرجة': 'bg-red-100 text-red-800',
};

const severityIcons = {
  'منخفضة': '🟢',
  'متوسطة': '🟡',
  'عالية': '🟠',
  'حرجة': '🔴',
};

export function AttackDetailModal({ attack, isOpen, onClose }: AttackDetailModalProps) {
  if (!attack) return null;

  const attackDate = new Date(attack.timestamp * 1000);
  const formattedTime = attackDate.toLocaleString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const recommendations = {
    'DDoS': [
      'تفعيل WAF (Web Application Firewall)',
      'استخدام CDN لتوزيع الحمل',
      'تحديد معدل الطلبات (Rate Limiting)',
      'مراقبة حركة المرور بشكل مستمر',
    ],
    'Phishing': [
      'تدريب الموظفين على التعرف على الرسائل المريبة',
      'تفعيل التحقق الثنائي',
      'استخدام أدوات كشف البريد الإلكتروني الضار',
      'فحص الروابط قبل النقر عليها',
    ],
    'Malware': [
      'تثبيت برنامج مكافحة فيروسات قوي',
      'تحديث جميع البرامج والأنظمة',
      'عدم تحميل ملفات من مصادر غير موثوقة',
      'عمل نسخ احتياطية منتظمة',
    ],
    'default': [
      'تحديث أنظمة الأمان',
      'مراقبة السجلات بانتظام',
      'تفعيل المصادقة الثنائية',
      'تدريب الموظفين على الأمان السيبراني',
    ],
  };

  const threatRecommendations = recommendations[attack.threatType as keyof typeof recommendations] || recommendations.default;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 rounded-lg">
        <DialogHeader className="mb-4">
          <DialogTitle className="flex items-center gap-2 text-xl">
            <span className="text-2xl">{severityIcons[attack.severity]}</span>
            تفاصيل الهجوم - {attack.country}
          </DialogTitle>
          <DialogDescription className="mt-2">
            معلومات شاملة عن الهجوم السيبراني المكتشف
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* الموقع والوقت */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">معلومات الموقع والوقت</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-blue-500" />
                <div>
                  <p className="text-sm text-gray-600">الموقع الجغرافي</p>
                  <p className="font-semibold">
                    {attack.city ? `${attack.city}, ${attack.country}` : attack.country}
                  </p>
                  <p className="text-xs text-gray-500">
                    الإحداثيات: {attack.latitude.toFixed(4)}, {attack.longitude.toFixed(4)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-sm text-gray-600">وقت الهجوم</p>
                  <p className="font-semibold">{formattedTime}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* نوع الهجوم والخطورة */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">نوع الهجوم والخطورة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-orange-500" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">نوع الهجوم</p>
                  <p className="font-semibold">{attack.threatType || 'غير محدد'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-purple-500" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">مستوى الخطورة</p>
                  <Badge className={severityColors[attack.severity]}>
                    {attack.severity}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* الإحصائيات */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">الإحصائيات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-red-500" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">عدد الهجمات المشابهة</p>
                  <p className="font-semibold text-lg">{attack.attackCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* التوصيات */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">توصيات الحماية</CardTitle>
              <CardDescription>
                خطوات موصى بها للحماية من هذا النوع من الهجمات
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {threatRecommendations.map((rec, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <span className="text-green-500 font-bold mt-1">✓</span>
                    <span className="text-sm">{rec}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* معلومات إضافية */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">معلومات إضافية</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-600">
              <p>
                هذا الهجوم تم اكتشافه من قبل نظام المراقبة الأمني. يُنصح بمراجعة السجلات الأمنية والتأكد من عدم تأثر أي أنظمة حساسة.
              </p>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
