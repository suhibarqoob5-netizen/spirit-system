import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge as BadgeComponent } from "@/components/ui/badge";
import {
  Trophy,
  Zap,
  Shield,
  Heart,
  Brain,
  Star,
  Lock,
  Unlock,
  Loader2,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

interface Badge {
  id: number;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  requirement: string;
}

const BADGE_DEFINITIONS: Badge[] = [
  {
    id: 1,
    name: "البداية الذكية",
    description: "أكمل أول درس لك",
    icon: <Brain className="h-8 w-8" />,
    color: "from-blue-500 to-cyan-500",
    requirement: "أكمل درس واحد",
  },
  {
    id: 2,
    name: "حامي الأمان",
    description: "أكمل 5 دروس",
    icon: <Shield className="h-8 w-8" />,
    color: "from-green-500 to-emerald-500",
    requirement: "أكمل 5 دروس",
  },
  {
    id: 3,
    name: "خبير الأمان",
    description: "أكمل 10 دروس",
    icon: <Trophy className="h-8 w-8" />,
    color: "from-yellow-500 to-orange-500",
    requirement: "أكمل 10 دروس",
  },
  {
    id: 4,
    name: "الرياح القوية",
    description: "احصل على 100 نقطة",
    icon: <Zap className="h-8 w-8" />,
    color: "from-purple-500 to-pink-500",
    requirement: "احصل على 100 نقطة",
  },
  {
    id: 5,
    name: "قلب الحامي",
    description: "ساعد المجتمع",
    icon: <Heart className="h-8 w-8" />,
    color: "from-red-500 to-pink-500",
    requirement: "شارك تعليقات مفيدة",
  },
  {
    id: 6,
    name: "النجم المتألق",
    description: "احصل على 250 نقطة",
    icon: <Star className="h-8 w-8" />,
    color: "from-indigo-500 to-purple-500",
    requirement: "احصل على 250 نقطة",
  },
];

export default function Badges() {
  const { user } = useAuth();
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(
    BADGE_DEFINITIONS[0]
  );

  // Fetch user achievements
  const { data: achievements = [], isLoading: achievementsLoading } =
    trpc.engagement.achievements.byUser.useQuery(undefined, {
      enabled: !!user,
    });

  // Fetch user ranking for progress calculation
  const { data: ranking } = trpc.engagement.rankings.userRanking.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Fetch user progress
  const { data: userProgress = [] } = trpc.academic.userProgress.useQuery(
    undefined,
    { enabled: !!user }
  );

  // Get earned badge IDs
  const earnedBadgeIds = new Set(achievements.map((a) => a.badge));

  // Calculate progress for each badge
  const getBadgeProgress = (badge: Badge): { progress: number; unlocked: boolean } => {
    const isUnlocked = earnedBadgeIds.has(badge.name);

    let progress = 0;
    if (badge.id === 1) {
      // First lesson - check if any lesson is completed
      progress = userProgress.some((p) => p.completed) ? 100 : 0;
    } else if (badge.id === 2) {
      // 5 lessons - count completed lessons
      const completedCount = userProgress.filter((p) => p.completed).length;
      progress = Math.min((completedCount / 5) * 100, 100);
    } else if (badge.id === 3) {
      // 10 lessons
      const completedCount = userProgress.filter((p) => p.completed).length;
      progress = Math.min((completedCount / 10) * 100, 100);
    } else if (badge.id === 4) {
      // 100 points
      const points = ranking?.totalPoints || 0;
      progress = Math.min((points / 100) * 100, 100);
    } else if (badge.id === 5) {
      // Comments/help - placeholder
      progress = 0;
    } else if (badge.id === 6) {
      // 250 points
      const points = ranking?.totalPoints || 0;
      progress = Math.min((points / 250) * 100, 100);
    }

    return { progress, unlocked: isUnlocked };
  };

  const unlockedCount = BADGE_DEFINITIONS.filter(
    (b) => getBadgeProgress(b).unlocked
  ).length;
  const totalCount = BADGE_DEFINITIONS.length;
  const completionPercentage = Math.round((unlockedCount / totalCount) * 100);

  if (achievementsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-400">جاري تحميل الشارات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-600 to-orange-600 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="h-8 w-8" />
            <h1 className="text-4xl font-bold">الشارات والإنجازات</h1>
          </div>
          <p className="text-yellow-100">
            اجمع الشارات وأثبت براعتك في الأمان الرقمي
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Progress Summary */}
        <Card className="bg-slate-800 border-slate-700 p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">تقدمك</h2>
            <BadgeComponent className="bg-yellow-600">
              {unlockedCount}/{totalCount}
            </BadgeComponent>
          </div>

          <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-yellow-500 to-orange-500 h-full transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>

          <p className="text-gray-300 mt-3">
            لقد فتحت {unlockedCount} من {totalCount} شارة ({completionPercentage}%)
          </p>
        </Card>

        {/* Selected Badge Details */}
        {selectedBadge && (
          <Card className="bg-slate-800 border-slate-700 p-6 mb-8">
            <div className="flex items-start gap-6">
              <div
                className={`bg-gradient-to-br ${selectedBadge.color} p-6 rounded-lg`}
              >
                {selectedBadge.icon}
              </div>

              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">{selectedBadge.name}</h3>
                <p className="text-gray-300 mb-4">{selectedBadge.description}</p>

                <div className="space-y-2">
                  <p className="text-sm text-gray-400">
                    <span className="font-semibold">المتطلب:</span>{" "}
                    {selectedBadge.requirement}
                  </p>

                  {getBadgeProgress(selectedBadge).unlocked ? (
                    <BadgeComponent className="bg-green-600 w-fit">
                      <Unlock className="h-3 w-3 mr-1 inline" />
                      تم فتحها
                    </BadgeComponent>
                  ) : (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">التقدم</span>
                        <span className="text-sm font-semibold">
                          {Math.round(getBadgeProgress(selectedBadge).progress)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full transition-all duration-500"
                          style={{
                            width: `${getBadgeProgress(selectedBadge).progress}%`,
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Badges Grid */}
        <div>
          <h3 className="text-2xl font-bold mb-6">جميع الشارات</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {BADGE_DEFINITIONS.map((badge) => {
              const { progress, unlocked } = getBadgeProgress(badge);
              return (
                <button
                  key={badge.id}
                  onClick={() => setSelectedBadge(badge)}
                  className={`text-left transition-all ${
                    selectedBadge?.id === badge.id ? "ring-2 ring-yellow-500" : ""
                  }`}
                >
                  <Card
                    className={`bg-slate-700 border-slate-600 p-4 h-full hover:bg-slate-600 transition-colors ${
                      selectedBadge?.id === badge.id ? "bg-slate-600" : ""
                    }`}
                  >
                    <div
                      className={`bg-gradient-to-br ${badge.color} p-4 rounded-lg mb-4 w-fit`}
                    >
                      {unlocked ? badge.icon : <Lock className="h-8 w-8" />}
                    </div>

                    <h4 className="font-semibold text-sm mb-1">{badge.name}</h4>
                    <p className="text-xs text-gray-400 mb-3">
                      {badge.description}
                    </p>

                    {unlocked ? (
                      <BadgeComponent className="bg-green-600 text-xs">
                        <Unlock className="h-2 w-2 mr-1 inline" />
                        تم فتحها
                      </BadgeComponent>
                    ) : (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-400">التقدم</span>
                          <span className="text-xs font-semibold">
                            {Math.round(progress)}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full transition-all duration-500"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </Card>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
