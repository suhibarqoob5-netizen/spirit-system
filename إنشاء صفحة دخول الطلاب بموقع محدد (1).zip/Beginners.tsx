import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Spinner } from "@/components/ui/spinner";
import { BookOpen, Search, Clock, Eye } from "lucide-react";

export default function Beginners() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedArticle, setSelectedArticle] = useState<any>(null);

  // Fetch all articles
  const { data: articlesData, isLoading } = trpc.articles.getAll.useQuery();
  const articles = articlesData?.data || [];

  // Filter articles
  const filteredArticles = articles.filter((article: any) => {
    const matchesCategory = !selectedCategory || article.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Get unique categories
  const categories = Array.from(new Set(articles.map((a: any) => a.category)));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold text-white">مقالات المبتدئين</h1>
          </div>
          <p className="text-slate-300 text-lg">
            تعلم أساسيات الأمن السيبراني من خلال مقالات تعليمية وفيديوهات شاملة
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="ابحث عن مقالات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder-slate-400"
            />
          </div>
        </div>

        {/* Categories Filter */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              الكل
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category ? "bg-cyan-600 hover:bg-cyan-700" : ""}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredArticles.map((article: any) => (
            <Card
              key={article.id}
              className="bg-slate-800 border-slate-700 hover:border-cyan-500 cursor-pointer transition-all hover:shadow-lg hover:shadow-cyan-500/20"
              onClick={() => setSelectedArticle(article)}
            >
              {article.thumbnail && (
                <div className="w-full h-48 bg-gradient-to-br from-cyan-500 to-blue-600 overflow-hidden">
                  <img
                    src={article.thumbnail}
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <Badge className="bg-cyan-600">{article.level}</Badge>
                  <Badge variant="outline" className="text-slate-300">
                    {article.category}
                  </Badge>
                </div>
                <CardTitle className="text-white line-clamp-2">{article.title}</CardTitle>
                <CardDescription className="text-slate-400 line-clamp-2">
                  {article.summary || article.content.substring(0, 100)}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-slate-400">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{article.readingTime || 5} دقائق</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{article.views || 0}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-400 text-lg">لم يتم العثور على مقالات</p>
          </div>
        )}

        {/* Article Modal */}
        {selectedArticle && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <Card className="bg-slate-800 border-slate-700 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader className="sticky top-0 bg-slate-800 border-b border-slate-700">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex gap-2 mb-2">
                      <Badge className="bg-cyan-600">{selectedArticle.level}</Badge>
                      <Badge variant="outline" className="text-slate-300">
                        {selectedArticle.category}
                      </Badge>
                    </div>
                    <CardTitle className="text-white">{selectedArticle.title}</CardTitle>
                  </div>
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedArticle(null)}
                    className="text-slate-400"
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {/* Video */}
                {selectedArticle.videoUrl && (
                  <div className="mb-6 aspect-video bg-black rounded-lg overflow-hidden">
                    <iframe
                      src={selectedArticle.videoUrl}
                      className="w-full h-full"
                      allowFullScreen
                      title={selectedArticle.title}
                    />
                  </div>
                )}

                {/* Article Content */}
                <div className="prose prose-invert max-w-none">
                  <div className="text-slate-300 mb-6 whitespace-pre-wrap">
                    {selectedArticle.content}
                  </div>
                </div>

                {/* Metadata */}
                <div className="border-t border-slate-700 pt-4 mt-6 flex items-center justify-between text-sm text-slate-400">
                  <div>
                    <span>بقلم: {selectedArticle.author}</span>
                  </div>
                  <div className="flex gap-4">
                    <span>وقت القراءة: {selectedArticle.readingTime || 5} دقائق</span>
                    <span>المشاهدات: {selectedArticle.views || 0}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
