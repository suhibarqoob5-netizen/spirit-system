/**
 * صفحة غصن البرقوق - للشباب
 * Design Philosophy: حديث آمن وموثوق مع ألوان داكنة ولمسات أخضر فيروزي زاهية
 * Color Scheme: أزرق داكن (#1a3a52) مع أخضر فيروزي (#00d9ff)
 */

import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowRight } from "lucide-react";

export default function BoysSection() {
  const [, navigate] = useLocation();

  const topics = [
    {
      icon: "🔒",
      title: "الأمن الإلكتروني",
      description: "أساسيات الأمن الرقمي وحماية حساباتك من الاختراق",
    },
    {
      icon: "🛡️",
      title: "حماية البيانات",
      description: "تقنيات متقدمة لحماية بياناتك الشخصية والحساسة",
    },
    {
      icon: "💪",
      title: "بناء القوة الرقمية",
      description: "كيفية بناء وجود رقمي قوي وآمن على الإنترنت",
    },
    {
      icon: "⚡",
      title: "مواجهة التحديات",
      description: "استراتيجيات للتعامل مع التحديات الرقمية بثقة",
    },
    {
      icon: "🔐",
      title: "كلمات المرور الآمنة",
      description: "إنشاء وإدارة كلمات مرور قوية وآمنة",
    },
    {
      icon: "🌐",
      title: "الخصوصية على الإنترنت",
      description: "الحفاظ على خصوصيتك وحماية معلوماتك الشخصية",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1f2e] via-[#1a3a52] to-[#0a1f2e] text-foreground">
      {/* Header */}
      <header className="border-b border-[#2a5a82] bg-[#0a1f2e]/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-primary hover:text-[#00ffff] transition-colors"
            >
              <span className="text-2xl">🛡️</span>
              <span className="font-bold">Spirit Platform</span>
            </button>
            <nav className="flex items-center gap-6">
              <button
                onClick={() => navigate("/")}
                className="text-foreground hover:text-primary transition-colors"
              >
                الرئيسية
              </button>
              <button
                onClick={() => navigate("/boys-section")}
                className="text-primary font-semibold"
              >
                🌿 غصن البرقوق
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <div className="inline-block mb-6 p-4 bg-gradient-to-br from-primary/20 to-[#00ffff]/20 rounded-full border border-primary/30">
            <span className="text-5xl">🌿</span>
          </div>
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-[#00ffff] to-primary bg-clip-text text-transparent">
            غصن البرقوق
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            قسم الشباب: الأمن الإلكتروني، الحماية، بناء القوة الرقمية، ومواجهة التحديات
          </p>
          <p className="text-lg text-foreground leading-relaxed">
            في هذا القسم ستجدون محتوى شامل يركز على الأمن الإلكتروني المتقدم وبناء مهارات رقمية قوية.
          </p>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">المواضيع الرئيسية</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topics.map((topic, index) => (
            <div
              key={index}
              className="p-6 rounded-lg bg-gradient-to-br from-[#1a3a52] to-[#0f2a3d] border border-[#2a5a82] hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="text-4xl mb-4">{topic.icon}</div>
              <h3 className="text-xl font-semibold mb-3 text-primary">
                {topic.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {topic.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="bg-gradient-to-r from-primary/10 via-[#00ffff]/10 to-primary/10 border border-primary/30 rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">ابدأ رحلتك نحو الأمان الرقمي</h2>
          <p className="text-lg text-muted-foreground mb-8">
            تعلم المزيد عن حماية نفسك في الفضاء الرقمي
          </p>
          <Button
            onClick={() => navigate("/")}
            className="bg-primary hover:bg-[#00ffff] text-[#0a1f2e] font-semibold px-8 py-6 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-primary/50 flex items-center gap-2 mx-auto"
          >
            العودة للرئيسية
            <ArrowRight size={20} />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#2a5a82] bg-[#0a1f2e]/80 mt-16 py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>© 2025 Spirit Platform - جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}
