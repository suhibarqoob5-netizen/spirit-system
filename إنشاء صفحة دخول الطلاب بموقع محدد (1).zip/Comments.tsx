import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Spinner } from "@/components/ui/spinner";
import {
  MessageCircle,
  ThumbsUp,
  Reply,
  Send,
  User,
  Clock,
  AlertCircle,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

interface CommentUI {
  id: number;
  userId: number;
  lessonId: number;
  text: string;
  rating: number;
  createdAt: Date;
  userName?: string;
  liked?: boolean;
  likes?: number;
}

export default function Comments() {
  const { user } = useAuth();
  const [selectedLessonId, setSelectedLessonId] = useState<number>(1);
  const [newComment, setNewComment] = useState("");
  const [newRating, setNewRating] = useState<number>(5);

  // Fetch comments for selected lesson
  const { data: comments = [], isLoading: commentsLoading } =
    trpc.engagement.comments.byLesson.useQuery(
      { lessonId: selectedLessonId },
      { enabled: !!selectedLessonId }
    );

  // Create comment mutation
  const createCommentMutation = trpc.engagement.comments.create.useMutation({
    onSuccess: () => {
      setNewComment("");
      setNewRating(5);
      // Invalidate and refetch comments
      utils.engagement.comments.byLesson.invalidate();
    },
    onError: (error) => {
      console.error("Failed to create comment:", error);
    },
  });

  const utils = trpc.useUtils();

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    if (!user) {
      alert('يرجى تسجيل الدخول لإضافة تعليق');
      return;
    }

    await createCommentMutation.mutateAsync({
      lessonId: selectedLessonId,
      text: newComment,
      rating: newRating,
    });
  };

  // Lessons list for sidebar
  const lessons = [
    { id: 1, title: "مقدمة في الأمن السيبراني" },
    { id: 2, title: "كلمات المرور القوية" },
    { id: 3, title: "التصيد الإلكتروني" },
    { id: 4, title: "الشبكات الآمنة" },
    { id: 5, title: "الحماية من البرامج الضارة" },
  ];

  const selectedLesson = lessons.find((l) => l.id === selectedLessonId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <MessageCircle className="h-8 w-8" />
            <h1 className="text-4xl font-bold">التعليقات والملاحظات</h1>
          </div>
          <p className="text-purple-100">
            شارك ملاحظاتك وتعليقاتك على الدروس
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Lessons List */}
          <div className="lg:col-span-1">
            <h3 className="text-xl font-bold mb-4">الدروس</h3>
            <div className="space-y-2">
              {lessons.map((lesson) => (
                <button
                  key={lesson.id}
                  onClick={() => setSelectedLessonId(lesson.id)}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    selectedLessonId === lesson.id
                      ? "bg-purple-600 border-2 border-purple-400"
                      : "bg-slate-700 hover:bg-slate-600 border border-slate-600"
                  }`}
                >
                  <p className="font-semibold text-sm truncate">
                    {lesson.title}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-300">
                    <MessageCircle className="h-3 w-3" />
                    <span>
                      {comments.filter((c) => c.lessonId === lesson.id).length}{" "}
                      تعليق
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Comments Section */}
          <div className="lg:col-span-3 space-y-6">
            {/* Lesson Header */}
            {selectedLesson && (
              <Card className="bg-slate-800 border-slate-700 p-6">
                <h2 className="text-2xl font-bold mb-2">{selectedLesson.title}</h2>
                <p className="text-gray-300 mb-4">
                  اقرأ التعليقات والملاحظات من الطلاب الآخرين
                </p>

                <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    <span>
                      {comments.filter((c) => c.lessonId === selectedLessonId)
                        .length}{" "}
                      تعليق
                    </span>
                  </div>
                </div>
              </Card>
            )}

            {/* New Comment Form */}
            {user && (
              <Card className="bg-slate-800 border-slate-700 p-6">
                <h3 className="font-semibold mb-4">أضف تعليقك</h3>
                <div className="space-y-3">
                  <Textarea
                    placeholder="شارك ملاحظتك أو سؤالك..."
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder-gray-400"
                    rows={3}
                  />

                  {/* Rating */}
                  <div className="flex items-center gap-3">
                    <label className="text-sm font-medium">التقييم:</label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setNewRating(star)}
                          className={`text-2xl transition-transform ${
                            star <= newRating
                              ? "text-yellow-400 scale-110"
                              : "text-gray-500"
                          }`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={handleAddComment}
                    disabled={
                      !newComment.trim() || createCommentMutation.isPending
                    }
                    className="bg-purple-600 hover:bg-purple-700 gap-2"
                  >
                    {createCommentMutation.isPending ? (
                      <>
                        <Spinner className="h-4 w-4" />
                        جاري الإرسال...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        نشر التعليق
                      </>
                    )}
                  </Button>
                </div>
              </Card>
            )}

            {/* Comments List */}
            <div>
              <h3 className="font-semibold mb-4">
                التعليقات (
                {comments.filter((c) => c.lessonId === selectedLessonId).length}
                )
              </h3>

              {commentsLoading ? (
                <Card className="bg-slate-800 border-slate-700 p-6 text-center">
                  <Spinner className="h-6 w-6 mx-auto mb-2" />
                  <p className="text-gray-400">جاري تحميل التعليقات...</p>
                </Card>
              ) : comments.filter((c) => c.lessonId === selectedLessonId)
                  .length === 0 ? (
                <Card className="bg-slate-800 border-slate-700 p-6 text-center">
                  <p className="text-gray-400">لا توجد تعليقات حتى الآن</p>
                  <p className="text-sm text-gray-500 mt-2">
                    كن أول من يعلق على هذا الدرس
                  </p>
                </Card>
              ) : (
                <div className="space-y-4">
                  {comments
                    .filter((c) => c.lessonId === selectedLessonId)
                    .sort(
                      (a, b) =>
                        new Date(b.createdAt).getTime() -
                        new Date(a.createdAt).getTime()
                    )
                    .map((comment) => (
                      <Card
                        key={comment.id}
                        className="bg-slate-700 border-slate-600 p-4"
                      >
                        <div className="flex gap-3">
                          <div className="text-2xl flex-shrink-0">👤</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <div>
                                <p className="font-semibold text-sm">
                                  مستخدم #{comment.userId}
                                </p>
                                <div className="flex items-center gap-1 text-xs text-gray-400">
                                  <Clock className="h-3 w-3" />
                                  <span>
                                    {new Date(comment.createdAt).toLocaleDateString(
                                      "ar-SA"
                                    )}{" "}
                                    {new Date(comment.createdAt).toLocaleTimeString(
                                      "ar-SA",
                                      {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                      }
                                    )}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Rating Stars */}
                            <div className="flex gap-1 mb-2">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <span
                                  key={star}
                                  className={`text-sm ${
                                    star <= (comment.rating || 5)
                                      ? "text-yellow-400"
                                      : "text-gray-500"
                                  }`}
                                >
                                  ★
                                </span>
                              ))}
                            </div>

                            <p className="text-sm text-gray-200">
                              {comment.text}
                            </p>
                          </div>
                        </div>
                      </Card>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
