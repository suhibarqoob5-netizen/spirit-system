import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ChevronLeft, Play } from "lucide-react";

export default function Course() {
  const [location, setLocation] = useLocation();
  const { slug } = useParams<{ slug: string }>();
  
  const { data: course } = trpc.academic.courses.bySlug.useQuery(slug || "");
  const { data: lessons, isLoading } = trpc.academic.lessons.byCourse.useQuery(
    course?.id || 0,
    { enabled: !!course }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="text-slate-300">جاري التحميل...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => window.history.back()}
          className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          عودة
        </button>

        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {course?.title}
          </h1>
          <p className="text-lg text-slate-300">{course?.description}</p>
        </div>

        {/* Lessons List */}
        {lessons && lessons.length > 0 ? (
          <div className="space-y-4">
            {lessons.map((lesson: any, index: number) => (
              <Card
                key={lesson.id}
                className="bg-slate-800 border-cyan-500/30 hover:border-cyan-500 hover:shadow-lg hover:shadow-cyan-500/20 transition-all cursor-pointer group"
                onClick={() => setLocation(`/lesson/${lesson.id}`)}
              >
                <div className="p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    {/* Lesson Number */}
                    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>

                    {/* Lesson Info */}
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">
                        {lesson.title}
                      </h3>
                      <p className="text-sm text-slate-400 line-clamp-2">
                        {lesson.description}
                      </p>
                    </div>
                  </div>

                  {/* Action Button */}
                  <Button
                    className="flex-shrink-0 ml-4 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/lesson/${lesson.id}`);
                    }}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    ابدأ
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-slate-400">لا توجد دروس متاحة</p>
          </div>
        )}
      </div>
    </div>
  );
}
