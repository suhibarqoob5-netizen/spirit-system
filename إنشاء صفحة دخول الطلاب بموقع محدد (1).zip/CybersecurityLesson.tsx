import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, Send } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

export default function CybersecurityLesson() {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [learnedConcepts, setLearnedConcepts] = useState<string[]>([]);
  const [points, setPoints] = useState(0);

  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "مرحباً! أنا مساعدك لتعلم الأمن السيبراني. اسألني عن أي مفهوم أو طلب تدريب.",
    },
  ]);

  // All hooks must be called before any early returns
  const { user, loading } = useAuth();
  const utils = trpc.useUtils();
  
  // Fetch concepts from database
  const { data: conceptsFromDb, isLoading: conceptsLoading } = trpc.academic.concepts.list.useQuery();
  
  const { data: userProgress } = trpc.academic.userProgress.useQuery(undefined, {
    enabled: !!user && !loading,
  });
  
  const { data: userRanking } = trpc.engagement.rankings.userRanking.useQuery(
    undefined,
    { enabled: !!user && !loading }
  );
  
  const markConceptMutation = trpc.academic.markConceptLearned.useMutation({
    onSuccess: () => {
      utils.academic.userProgress.invalidate();
      utils.engagement.rankings.userRanking.invalidate();
    },
  });

  // Load learned concepts from database
  useEffect(() => {
    if (!userProgress) return;
    const learned = userProgress
      .filter((p: any) => p.completed)
      .map((p: any) => {
        // Map lesson IDs to concept IDs
        const conceptIds = ["phishing", "malware", "password", "social-engineering", "wifi"];
        return conceptIds[p.lessonId - 1] || `concept-${p.lessonId}`;
      });
    setLearnedConcepts(learned);
  }, [userProgress]);

  // Update points from ranking
  useEffect(() => {
    if (userRanking) {
      setPoints(userRanking.totalPoints || 0);
    }
  }, [userRanking]);

  // Use concepts from DB, or empty array if loading
  const concepts = conceptsFromDb || [];
  const selectedConcept = concepts[selectedIndex];

  const progress = useMemo(() => {
    if (concepts.length === 0) return 0;
    return Math.min(
      100,
      Math.round((learnedConcepts.length / concepts.length) * 100)
    );
  }, [learnedConcepts, concepts]);

  const currentLevel = useMemo(() => {
    if (learnedConcepts.length < 2) return "مبتدئ";
    if (learnedConcepts.length < 3) return "متوسط";
    if (learnedConcepts.length < 4) return "متقدم";
    return "خبير";
  }, [learnedConcepts]);

  // Early returns after all hooks
  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <p className="text-white">جاري التحميل...</p>
      </div>
    );
  }

  if (conceptsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-cyan-400 mx-auto mb-4" />
          <p className="text-white text-lg">جاري تحميل المفاهيم...</p>
        </div>
      </div>
    );
  }

  if (!selectedConcept) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <p className="text-white text-lg">لا توجد مفاهيم متاحة</p>
        </div>
      </div>
    );
  }

  function markConceptLearned() {
    if (!selectedConcept) return;
    if (learnedConcepts.includes(selectedConcept.conceptId)) return;
    if (!user?.id) return;

    markConceptMutation.mutate(
      { conceptId: selectedConcept.conceptId },
      {
        onSuccess: () => {
          setLearnedConcepts((prev) => [...prev, selectedConcept.conceptId]);
          setPoints((p) => p + 20);
          
          // Refresh rankings
          utils.engagement.rankings.leaderboard.invalidate();
          utils.engagement.rankings.userRanking.invalidate();
          utils.academic.userProgress.invalidate();
        },
      }
    );
  }

  async function sendMessage(prefilled?: string) {
    const text = (prefilled ?? chatInput).trim();
    if (!text || chatLoading || !selectedConcept) return;

    const nextMessages: ChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setChatInput("");
    setChatLoading(true);

    try {
      const response = await fetch("/api/cybersecurity-tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          progress: { learnedConcepts, points },
          currentConcept: {
            id: selectedConcept.conceptId,
            title: selectedConcept.title,
            description: selectedConcept.description,
            risk: selectedConcept.risk,
            example: selectedConcept.example,
            prevention: selectedConcept.prevention,
          },
        }),
      });

      if (!response.ok) throw new Error("Request failed");

      const data = (await response.json()) as { reply: string };
      setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "عذراً، حدث خطأ في الاتصال. يرجى المحاولة مجدداً.",
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🔒 درس الأمن السيبراني</h1>
          <p className="text-slate-400">تعلم مفاهيم الأمان الرقمي الأساسية</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white font-semibold">التقدم: {progress}%</span>
            <span className="text-cyan-400 font-semibold">المستوى: {currentLevel}</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-3 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Concepts List */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-xl font-bold text-white mb-4">المفاهيم</h2>
              <div className="space-y-2">
                {concepts.map((concept, idx) => (
                  <button
                    key={concept.id}
                    onClick={() => setSelectedIndex(idx)}
                    className={`w-full text-right p-3 rounded-lg transition-all ${
                      selectedIndex === idx
                        ? "bg-cyan-600 text-white"
                        : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{concept.title}</span>
                      {learnedConcepts.includes(concept.conceptId) && (
                        <span className="text-green-400">✓</span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </Card>

            {/* Stats */}
            <Card className="bg-slate-800 border-slate-700 p-6 mt-6">
              <h3 className="text-lg font-bold text-white mb-4">الإحصائيات</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-slate-400 text-sm">النقاط الإجمالية</p>
                  <p className="text-3xl font-bold text-cyan-400">{points}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">المفاهيم المتعلمة</p>
                  <p className="text-3xl font-bold text-purple-400">{learnedConcepts.length}/{concepts.length}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Concept Details */}
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-2xl font-bold text-white mb-4">{selectedConcept.title}</h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-cyan-400 font-semibold mb-2">الوصف</h3>
                  <p className="text-slate-300">{selectedConcept.description}</p>
                </div>

                <div>
                  <h3 className="text-red-400 font-semibold mb-2">⚠️ المخاطر</h3>
                  <p className="text-slate-300">{selectedConcept.risk}</p>
                </div>

                <div>
                  <h3 className="text-yellow-400 font-semibold mb-2">📌 مثال واقعي</h3>
                  <p className="text-slate-300">{selectedConcept.example}</p>
                </div>

                <div>
                  <h3 className="text-green-400 font-semibold mb-2">✓ الحماية والوقاية</h3>
                  <p className="text-slate-300">{selectedConcept.prevention}</p>
                </div>
              </div>

              {!learnedConcepts.includes(selectedConcept.conceptId) && (
                <Button
                  onClick={markConceptLearned}
                  disabled={markConceptMutation.isPending}
                  className="w-full mt-6 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
                >
                  {markConceptMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      جاري الحفظ...
                    </>
                  ) : (
                    "✓ تم فهم المفهوم (+20 نقطة)"
                  )}
                </Button>
              )}

              {learnedConcepts.includes(selectedConcept.conceptId) && (
                <div className="w-full mt-6 p-4 bg-green-900/30 border border-green-500/50 rounded-lg text-center">
                  <p className="text-green-400 font-semibold">✓ تم تعلم هذا المفهوم بنجاح!</p>
                </div>
              )}
            </Card>

            {/* Chat */}
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-xl font-bold text-white mb-4">💬 مساعد التعلم</h2>

              <div className="bg-slate-900 rounded-lg p-4 h-64 overflow-y-auto mb-4 space-y-3">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs p-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-cyan-600 text-white"
                          : "bg-slate-700 text-slate-200"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
                {chatLoading && (
                  <div className="flex justify-start">
                    <Loader2 className="w-5 h-5 animate-spin text-cyan-400" />
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                  placeholder="اسأل عن المفهوم الحالي..."
                  className="bg-slate-700 border-slate-600 text-white"
                  disabled={chatLoading}
                />
                <Button
                  onClick={() => sendMessage()}
                  disabled={chatLoading || !chatInput.trim()}
                  className="bg-cyan-600 hover:bg-cyan-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
