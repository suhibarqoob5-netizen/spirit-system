import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Flame, Trophy, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const DAILY_CHALLENGES: Question[] = [
  {
    id: "1",
    text: "ما هي أفضل ممارسة لحماية كلمة المرور؟",
    options: [
      "استخدام نفس كلمة المرور في جميع الحسابات",
      "استخدام كلمة مرور قوية وفريدة لكل حساب",
      "كتابة كلمة المرور على ورقة بجانب الحاسوب",
      "استخدام تاريخ ميلادك كجزء من كلمة المرور",
    ],
    correctAnswer: 1,
    explanation:
      "استخدام كلمة مرور قوية وفريدة لكل حساب هو أفضل ممارسة لحماية حساباتك.",
  },
  {
    id: "2",
    text: "ما هو التصيد الإلكتروني (Phishing)؟",
    options: [
      "برنامج يحمي من الفيروسات",
      "محاولة الحصول على معلومات شخصية عبر خداع",
      "نوع من أنواع الأسماك",
      "تحديث أمان للبرامج",
    ],
    correctAnswer: 1,
    explanation:
      "التصيد الإلكتروني هو محاولة الحصول على معلومات شخصية عبر خداع المستخدمين.",
  },
  {
    id: "3",
    text: "كم عدد الأحرف المطلوبة لكلمة مرور قوية؟",
    options: [
      "6 أحرف على الأقل",
      "8 أحرف على الأقل",
      "12 حرف على الأقل",
      "4 أحرف على الأقل",
    ],
    correctAnswer: 2,
    explanation:
      "كلمة مرور قوية يجب أن تحتوي على 12 حرف على الأقل، وتجمع بين الأحرف الكبيرة والصغيرة والأرقام والرموز.",
  },
];

export default function DailyChallenge() {
  const { user } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [completedToday, setCompletedToday] = useState(false);
  const [score, setScore] = useState(0);
  const [totalQuestions] = useState(DAILY_CHALLENGES.length);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Get today's challenge (same for all users)
  const getTodayChallenge = () => {
    const today = new Date();
    const dayOfYear = Math.floor(
      (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000
    );
    return DAILY_CHALLENGES[dayOfYear % DAILY_CHALLENGES.length];
  };

  const todayChallenge = getTodayChallenge();
  const challengeIndex = DAILY_CHALLENGES.findIndex((q) => q.id === todayChallenge.id);

  const handleSubmitAnswer = async () => {
    if (selectedAnswer === null) return;

    setIsSubmitting(true);
    const correct = selectedAnswer === todayChallenge.correctAnswer;
    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      setScore(score + 1);
      setCompletedToday(true);

      // Award points to user (50 points for correct answer)
      try {
        // This would be a tRPC call to award points
        console.log("Awarding 50 points to user:", user?.id);
      } catch (error) {
        console.error("Error awarding points:", error);
      }
    }

    setIsSubmitting(false);
  };

  const handleNextChallenge = () => {
    setSelectedAnswer(null);
    setShowResult(false);
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setCompletedToday(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4 md:p-8" dir="rtl">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Flame className="h-8 w-8 text-orange-500" />
            <h1 className="text-4xl font-bold">التحدي اليومي</h1>
          </div>
          <p className="text-slate-400">
            أجب على السؤال الصحيح واحصل على 50 نقطة!
          </p>
        </div>

        {/* Progress */}
        <Card className="bg-slate-800 border-slate-700 p-4 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-slate-400">السؤال</p>
              <p className="text-2xl font-bold">
                {challengeIndex + 1}/{totalQuestions}
              </p>
            </div>
            <div className="flex-1 mx-4">
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-orange-500 to-pink-500 h-full rounded-full transition-all"
                  style={{
                    width: `${((challengeIndex + 1) / totalQuestions) * 100}%`,
                  }}
                />
              </div>
            </div>
            <div>
              <p className="text-sm text-slate-400">النقاط</p>
              <p className="text-2xl font-bold text-orange-500">+50</p>
            </div>
          </div>
        </Card>

        {/* Question Card */}
        <Card className="bg-slate-800 border-slate-700 p-8 mb-6">
          <h2 className="text-2xl font-bold mb-6">{todayChallenge.text}</h2>

          {!showResult ? (
            <div className="space-y-4">
              <RadioGroup
                value={selectedAnswer?.toString() || ""}
                onValueChange={(value) => setSelectedAnswer(parseInt(value))}
              >
                {todayChallenge.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem
                      value={index.toString()}
                      id={`option-${index}`}
                      className="border-slate-500"
                    />
                    <Label
                      htmlFor={`option-${index}`}
                      className="flex-1 p-3 rounded-lg bg-slate-700 hover:bg-slate-600 cursor-pointer transition-colors"
                    >
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <Button
                onClick={handleSubmitAnswer}
                disabled={selectedAnswer === null || isSubmitting}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 mt-6"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    جاري التحقق...
                  </>
                ) : (
                  "تحقق من الإجابة"
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Result */}
              <div
                className={`p-4 rounded-lg flex items-center gap-3 ${
                  isCorrect
                    ? "bg-green-900/30 border border-green-500/50"
                    : "bg-red-900/30 border border-red-500/50"
                }`}
              >
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="h-6 w-6 text-green-500" />
                    <div>
                      <p className="font-bold text-green-400">إجابة صحيحة! 🎉</p>
                      <p className="text-sm text-green-300">لقد حصلت على 50 نقطة</p>
                    </div>
                  </>
                ) : (
                  <>
                    <XCircle className="h-6 w-6 text-red-500" />
                    <div>
                      <p className="font-bold text-red-400">إجابة خاطئة</p>
                      <p className="text-sm text-red-300">حاول مرة أخرى غداً</p>
                    </div>
                  </>
                )}
              </div>

              {/* Explanation */}
              <div className="bg-slate-700 p-4 rounded-lg">
                <p className="text-sm text-slate-300 mb-2">الشرح:</p>
                <p className="text-slate-200">{todayChallenge.explanation}</p>
              </div>

              {/* Correct Answer */}
              <div className="bg-slate-700 p-4 rounded-lg">
                <p className="text-sm text-slate-300 mb-2">الإجابة الصحيحة:</p>
                <p className="text-slate-200 font-semibold">
                  {todayChallenge.options[todayChallenge.correctAnswer]}
                </p>
              </div>

              {/* Next Button */}
              <Button
                onClick={handleNextChallenge}
                className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 mt-6"
              >
                {currentQuestion < totalQuestions - 1 ? "السؤال التالي" : "انتهى"}
              </Button>
            </div>
          )}
        </Card>

        {/* Completion Message */}
        {completedToday && (
          <Card className="bg-gradient-to-r from-orange-600 to-pink-600 border-0 p-6">
            <div className="flex items-center gap-4">
              <Trophy className="h-8 w-8" />
              <div>
                <h3 className="font-bold text-lg">تم إكمال التحدي اليومي!</h3>
                <p className="text-sm text-orange-100">
                  تحقق مجدداً غداً للحصول على تحدٍ جديد
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Tips */}
        <Card className="bg-slate-800 border-slate-700 p-6 mt-8">
          <h3 className="font-bold text-lg mb-4">💡 نصائح</h3>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ أجب على التحدي اليومي للحصول على 50 نقطة</li>
            <li>✓ يمكنك الإجابة مرة واحدة فقط كل يوم</li>
            <li>✓ النقاط تُضاف فوراً إلى حسابك</li>
            <li>✓ تحقق من ترتيبك في لوحة الترتيب</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
