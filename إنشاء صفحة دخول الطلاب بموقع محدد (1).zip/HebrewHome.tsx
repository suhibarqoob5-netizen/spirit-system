import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

export function HebrewHome() {
  const [, setLocation] = useLocation();
  const { user, loading } = useAuth();

  // Don't auto-redirect - let user choose to go to dashboard via button

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white">טוען...</p>
        </div>
      </div>
    );
  }

  // If not logged in, show Hebrew content
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 text-white" dir="rtl">
      {/* Navigation */}
      <nav className="border-b border-blue-800">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold">🔒 Spirit Platform</div>
          <div className="flex gap-4">
            <a href="/hebrew" className="text-blue-300 hover:text-white">עברית</a>
            <a href="/" className="text-blue-300 hover:text-white">English</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-20 text-center">
        <h1 className="text-5xl font-bold mb-6">🛡️ למדו אבטחה סייבר</h1>
        <p className="text-xl text-blue-200 mb-8">
          פלטפורמה מקיפה ללימוד יסודות האבטחה הדיגיטלית וחיזוק המיומנויות שלכם
        </p>
        
        <div className="flex gap-4 justify-center mb-12">
          {user ? (
            <Button 
              size="lg"
              onClick={() => setLocation("/dashboard")}
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-3"
            >
              לוח הבקרה
            </Button>
          ) : (
            <Button 
              size="lg"
              onClick={() => window.location.href = getLoginUrl()}
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3"
            >
              התחברות
            </Button>
          )}
          <Button 
            size="lg"
            variant="outline"
            className="border-blue-400 text-blue-400 hover:bg-blue-900 px-8 py-3"
          >
            עוד מידע
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-blue-800 bg-opacity-50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">תכונות עיקריות</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-blue-900 bg-opacity-50 p-6 rounded-lg border border-blue-700">
              <div className="text-4xl mb-4">📚</div>
              <h3 className="text-xl font-bold mb-3">קורסים מקיפים</h3>
              <p className="text-blue-200">
                למדו את יסודות האבטחה הסייבר מהבסיס ועד לרמות מתקדמות
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-blue-900 bg-opacity-50 p-6 rounded-lg border border-blue-700">
              <div className="text-4xl mb-4">🏆</div>
              <h3 className="text-xl font-bold mb-3">מערכת דירוג</h3>
              <p className="text-blue-200">
                תחרוּ עם משתמשים אחרים וקבלו נקודות על כל השלמת קורס
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-blue-900 bg-opacity-50 p-6 rounded-lg border border-blue-700">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-bold mb-3">למידה אינטראקטיבית</h3>
              <p className="text-blue-200">
                חוויה למידה דינמית עם משימות ותרגילים מעשיים
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-6xl mx-auto px-4 py-16 text-center">
        <h2 className="text-3xl font-bold mb-6">מוכנים להתחיל?</h2>
        <p className="text-xl text-blue-200 mb-8">
          הצטרפו לקהילה שלנו וחזקו את המיומנויות שלכם באבטחה סייבר
        </p>
        <Button 
          size="lg"
          onClick={() => window.location.href = getLoginUrl()}
          className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3"
        >
          התחברות עכשיו
        </Button>
      </section>

      {/* Footer */}
      <footer className="border-t border-blue-800 py-8 text-center text-blue-300">
        <p>&copy; 2026 Spirit Platform. כל הזכויות שמורות.</p>
      </footer>
    </div>
  );
}
