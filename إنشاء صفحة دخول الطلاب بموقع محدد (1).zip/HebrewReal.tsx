import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { AlertCircle, CheckCircle, XCircle, Zap } from "lucide-react";

type Scenario = {
  id: string;
  text: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  level: "أساس" | "واقع" | "خطر";
};

const scenarios: Scenario[] = [
  {
    id: "1",
    text: "שלום, זכית בפרס! לחץ כאן",
    question: "ما معنى هذه الرسالة؟",
    options: ["رسالة عادية", "إعلان عادي", "احتيال محتمل"],
    correctAnswer: 2,
    explanation:
      "هذه رسالة احتيال نموذجية! تستخدم كلمات مثل 'فزت' لجذب انتباهك وتحفيزك على النقر على الرابط المزيف.",
    level: "أساس",
  },
  {
    id: "2",
    text: "אימות חשבון נדרש מיד",
    question: "شو هدف هذه الرسالة؟",
    options: ["حماية حسابك", "سرقة بيانات دخولك", "تنبيه عادي"],
    correctAnswer: 1,
    explanation:
      "محاولة احتيال! الخدمات الشرعية لا تطلب منك التحقق من بيانات دخولك عبر رسائل. هذا أسلوب شهير للتصيد الاحتيالي.",
    level: "واقع",
  },
  {
    id: "3",
    text: "הבנק שלך דורש עדכון מידי של הפרטים",
    question: "هل يجب أن تنقر على الرابط؟",
    options: ["نعم، بسرعة", "لا، اتصل بالبنك مباشرة", "ربما لاحقاً"],
    correctAnswer: 1,
    explanation:
      "لا تنقر أبداً! البنوك الحقيقية لا تطلب تحديثات عبر رسائل. اتصل بالبنك مباشرة على الرقم الموجود في بطاقتك.",
    level: "خطر",
  },
  {
    id: "4",
    text: "אתה זוכה בכרטיס מתנה בשווי 500 שקל",
    question: "كيف تتعامل معها؟",
    options: [
      "أنقر فوراً",
      "أتجاهلها",
      "أتحقق من الرابط من موقع رسمي",
    ],
    correctAnswer: 2,
    explanation:
      "الطريقة الآمنة: لا تنقر على الروابط في الرسائل. بدلاً من ذلك، ادخل مباشرة إلى الموقع الرسمي من متصفحك.",
    level: "واقع",
  },
  {
    id: "5",
    text: "עדכון חשוב: בדוק את חשבונך עכשיו!",
    question: "ما الخطر هنا؟",
    options: [
      "لا يوجد خطر",
      "الرسالة تحتوي على برامج ضارة",
      "قد تكون محاولة احتيال",
    ],
    correctAnswer: 2,
    explanation:
      "الكلمات المستعجلة مثل 'عاجل' و'الآن' هي علامات تحذير. المحتالون يستخدمونها لدفعك للتصرف بسرعة دون تفكير.",
    level: "خطر",
  },
];

export default function HebrewReal() {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [points, setPoints] = useState(0);
  const [completed, setCompleted] = useState(0);

  const current = scenarios[currentIndex];
  const progress = ((currentIndex + 1) / scenarios.length) * 100;

  const handleAnswer = (optionIndex: number) => {
    setSelectedAnswer(optionIndex);
    setShowResult(true);

    if (optionIndex === current.correctAnswer) {
      setPoints((prev) => prev + 10);
      setCompleted((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < scenarios.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // Quiz completed
      alert(
        `تم إكمال الاختبار! حصلت على ${points + (selectedAnswer === current.correctAnswer ? 10 : 0)} نقطة`
      );
      setCurrentIndex(0);
      setSelectedAnswer(null);
      setShowResult(false);
      setPoints(0);
      setCompleted(0);
    }
  };

  const isCorrect = selectedAnswer === current.correctAnswer;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            العبري في الواقع 🇮🇱
          </h1>
          <p className="text-slate-300">
            تعلم كيفية التعرف على رسائل الاحتيال بالعبرية
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700 p-4">
            <p className="text-sm text-slate-400 mb-1">النقاط</p>
            <p className="text-2xl font-bold text-cyan-400">{points}</p>
          </Card>
          <Card className="bg-slate-800 border-slate-700 p-4">
            <p className="text-sm text-slate-400 mb-1">الإجابات الصحيحة</p>
            <p className="text-2xl font-bold text-green-400">{completed}</p>
          </Card>
          <Card className="bg-slate-800 border-slate-700 p-4">
            <p className="text-sm text-slate-400 mb-1">المستوى</p>
            <p className="text-2xl font-bold text-purple-400">{current.level}</p>
          </Card>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-slate-400">
              السؤال {currentIndex + 1} من {scenarios.length}
            </span>
            <span className="text-sm text-cyan-400">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Scenario Card */}
        <Card className="bg-slate-800 border-cyan-500/30 p-8 mb-8">
          {/* Hebrew Text */}
          <div className="bg-slate-900 rounded-lg p-6 mb-8 border border-slate-700">
            <p className="text-2xl text-right font-hebrew text-white break-words">
              {current.text}
            </p>
          </div>

          {/* Question */}
          <h3 className="text-xl font-bold text-white mb-6">{current.question}</h3>

          {/* Options */}
          <div className="space-y-3 mb-8">
            {current.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrectOption = index === current.correctAnswer;

              let bgColor = "bg-slate-700 hover:bg-slate-600";
              let borderColor = "border-slate-600";

              if (showResult) {
                if (isCorrectOption) {
                  bgColor = "bg-green-900/50";
                  borderColor = "border-green-500";
                } else if (isSelected && !isCorrect) {
                  bgColor = "bg-red-900/50";
                  borderColor = "border-red-500";
                }
              } else if (isSelected) {
                bgColor = "bg-cyan-900/50";
                borderColor = "border-cyan-500";
              }

              return (
                <button
                  key={index}
                  onClick={() => !showResult && handleAnswer(index)}
                  disabled={showResult}
                  className={`w-full p-4 rounded-lg border-2 text-right transition-all ${bgColor} ${borderColor} text-white font-semibold disabled:cursor-default`}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    {showResult && isCorrectOption && (
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    )}
                    {showResult && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Result */}
          {showResult && (
            <div
              className={`p-4 rounded-lg mb-8 border-l-4 ${
                isCorrect
                  ? "bg-green-900/30 border-green-500"
                  : "bg-red-900/30 border-red-500"
              }`}
            >
              <div className="flex items-start gap-3">
                {isCorrect ? (
                  <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
                )}
                <div>
                  <p
                    className={`font-bold mb-2 ${
                      isCorrect ? "text-green-400" : "text-red-400"
                    }`}
                  >
                    {isCorrect ? "إجابة صحيحة! ✓" : "إجابة خاطئة ✗"}
                  </p>
                  <p className="text-slate-300">{current.explanation}</p>
                </div>
              </div>
            </div>
          )}

          {/* Next Button */}
          {showResult && (
            <Button
              onClick={handleNext}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold py-3"
            >
              {currentIndex === scenarios.length - 1 ? "إنهاء" : "التالي"}
              <Zap className="w-4 h-4 mr-2" />
            </Button>
          )}
        </Card>

        {/* Tips */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h4 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-yellow-400" />
            نصائح الأمان
          </h4>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ لا تنقر على روابط في الرسائل غير المتوقعة</li>
            <li>✓ تحقق دائماً من عنوان المرسل</li>
            <li>✓ الخدمات الحقيقية لا تطلب كلمات المرور عبر الرسائل</li>
            <li>✓ الكلمات المستعجلة علامة تحذير</li>
            <li>✓ عند الشك، اتصل بالخدمة مباشرة</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
