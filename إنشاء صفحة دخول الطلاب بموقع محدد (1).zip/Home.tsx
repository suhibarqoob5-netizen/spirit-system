import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { ChevronRight } from "lucide-react";

export default function Home() {
  // Force rebuild - v3 2026-04-12
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white" dir="rtl">
      {/* Navigation */}
      <nav className="border-b border-slate-800 sticky top-0 z-50 bg-slate-950/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold">Spirit</div>
            <div className="text-2xl font-bold text-cyan-400">Platform</div>
          </div>
          <div className="flex gap-6 items-center">
            <a href="/" className="hover:text-cyan-400 transition">الرئيسية</a>
            <button onClick={() => setLocation("/programs")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">🌸 زهرة البرقوق</button>
            <button onClick={() => setLocation("/programs")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">🌿 غصن البرقوق</button>
            <button onClick={() => setLocation("/programs")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">🌺 عطر الفرموزة</button>
            <button onClick={() => setLocation("/lessons")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">📚 الدروس</button>
            <button onClick={() => setLocation("/videos")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">🎥 الفيديوهات</button>
            <button onClick={() => setLocation("/ai-assistant")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">🤖 المساعد الذكي</button>
            <button onClick={() => setLocation("/ai-assistant")} className="text-cyan-400 hover:text-cyan-300 transition">اسأل المساعد</button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-32 px-4 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-block px-4 py-2 bg-slate-800 border border-slate-700 rounded-full mb-6">
            <span className="text-sm text-slate-300">منصة الأمان الرقمي العربية الشاملة</span>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold mb-6">
            <span className="text-white">حمايتك</span>
            <br />
            <span className="bg-gradient-to-r from-pink-500 to-cyan-400 bg-clip-text text-transparent">أولويتنا</span>
          </h1>
          
          <p className="text-2xl text-slate-400 mb-4">في الفضاء الرقمي</p>
          
          <p className="text-lg text-slate-300 mb-12 max-w-2xl mx-auto">
            منصة متخصصة في الأمان الرقمي توفر الحماية والتعليم والدعم لكل من يواجه تحديات العالم الرقمي
          </p>

          <div className="flex gap-4 justify-center mb-16 flex-wrap">
            <Button
              onClick={() => setLocation("/programs")}
              className="px-8 py-6 text-lg bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-bold rounded-lg"
            >
              ادخلي الآن
            </Button>
            <Button
              onClick={() => setLocation("/programs")}
              className="px-8 py-6 text-lg bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-bold rounded-lg"
            >
              ادخل الآن
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="text-4xl font-bold text-cyan-400 mb-2">10K+</div>
              <div className="text-slate-400">مستخدم محمي</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-pink-400 mb-2">50+</div>
              <div className="text-slate-400">درس تعليمي</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-400 mb-2">100%</div>
              <div className="text-slate-400">مجاني وآمن</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-slate-400">مساعدة متاحة</div>
            </div>
          </div>

          {/* CTA Button */}
          <Button
            onClick={() => setLocation("/programs")}
            className="px-12 py-6 text-lg bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold rounded-lg"
          >
            اكتشف المزيد
          </Button>
        </div>
      </section>

      {/* Choose Your Path Section */}
      <section className="py-20 px-4 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">اختر قسمك</h2>
            <p className="text-slate-400 text-lg">محتوى مخصص يناسب احتياجاتك</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Zahr Al-Barqooq */}
            <Card className="bg-gradient-to-br from-pink-900/30 to-pink-800/20 border-pink-500/30 p-8 hover:border-pink-500 transition cursor-pointer group"
              onClick={() => setLocation("/programs")}>
              <div className="text-5xl mb-6">🌸</div>
              <h3 className="text-2xl font-bold mb-4">زهرة البرقوق</h3>
              <p className="text-slate-300 mb-6">
                قسم مخصص للبنات: الحماية، الخصوصية، التعامل مع الابتزاز، وبناء الثقة الرقمية
              </p>
              <Button className="w-full bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700">
                ادخلي الآن
              </Button>
            </Card>

            {/* Ghasn Al-Barqooq */}
            <Card className="bg-gradient-to-br from-cyan-900/30 to-cyan-800/20 border-cyan-500/30 p-8 hover:border-cyan-500 transition cursor-pointer group"
              onClick={() => setLocation("/programs")}>
              <div className="text-5xl mb-6">🌿</div>
              <h3 className="text-2xl font-bold mb-4">غصن البرقوق</h3>
              <p className="text-slate-300 mb-6">
                قسم الشباب: الأمن الإلكتروني، الحماية، بناء القوة الرقمية، ومواجهة التحديات
              </p>
              <Button className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700">
                ادخل الآن
              </Button>
            </Card>

            {/* Atr Al-Farmooza */}
            <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/20 border-purple-500/30 p-8 hover:border-purple-500 transition cursor-pointer group"
              onClick={() => setLocation("/programs")}>
              <div className="text-5xl mb-6">🌺</div>
              <h3 className="text-2xl font-bold mb-4">عطر الفرموزة</h3>
              <p className="text-slate-300 mb-6">
                قسم متخصص: المحتوى المتقدم، الأبحاث الأمنية، والتطبيقات العملية للحماية الرقمية
              </p>
              <Button className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700">
                استكشف الآن
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* What Will You Learn Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">ماذا ستتعلم؟</h2>
            <p className="text-slate-400 text-lg">محتوى شامل يغطي جميع جوانب الأمان الرقمي بأسلوب عملي وسهل الفهم</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: "🔒", title: "حماية الخصوصية", desc: "تعلم كيف تحمي بياناتك الشخصية من الاختراق والتجسس" },
              { icon: "⚠️", title: "مواجهة الابتزاز", desc: "خطوات عملية للتعامل مع حالات الابتزاز الإلكتروني بثقة" },
              { icon: "🛡️", title: "الأمن الإلكتروني", desc: "أساسيات الأمن الرقمي وحماية حساباتك من الاختراق" },
              { icon: "📱", title: "حماية الهاتف", desc: "كيف تؤمّن هاتفك وتمنع الوصول غير المصرح به" },
              { icon: "🧠", title: "الوعي الرقمي", desc: "اكتشف المخاطر الرقمية وكيف تتجنبها في حياتك اليومية" },
              { icon: "👥", title: "مجتمع آمن", desc: "انضم لمجتمع يتشارك المعرفة ويدعم بعضه في الفضاء الرقمي" },
            ].map((item, idx) => (
              <Card key={idx} className="bg-slate-800 border-slate-700 p-6 hover:border-cyan-500 transition">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-slate-300">{item.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Explore Platform Section */}
      <section className="py-20 px-4 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">استكشف المنصة</h2>
            <p className="text-slate-400 text-lg">محتوى مخصص يناسب احتياجاتك</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: "📚", title: "الدروس", desc: "دروس تفاعلية في الأمان الرقمي من الأساسيات للمتقدم", btn: "ابدأ التعلم", onClick: () => setLocation("/lessons") },
              { icon: "🎥", title: "الفيديوهات", desc: "فيديوهات تعليمية مختارة لتعلم الأمان الرقمي بصريًا", btn: "شاهد الآن", onClick: () => setLocation("/videos") },
              { icon: "🤖", title: "المساعد الذكي", desc: "اسأل مساعدنا الذكي عن أي موضوع في الأمان الرقمي", btn: "اسأل الآن", onClick: () => setLocation("/ai-assistant") },
            ].map((item, idx) => (
              <Card key={idx} className="bg-slate-800 border-slate-700 p-8 hover:border-cyan-500 transition cursor-pointer" onClick={item.onClick}>
                <div className="text-5xl mb-6">{item.icon}</div>
                <h3 className="text-2xl font-bold mb-3">{item.title}</h3>
                <p className="text-slate-300 mb-6">{item.desc}</p>
                <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600">
                  {item.btn}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block px-4 py-2 bg-slate-800 border border-slate-700 rounded-full mb-6">
            <span className="text-sm text-slate-300">🛡️ ابدأ رحلتك الآن</span>
          </div>
          
          <h2 className="text-5xl font-bold mb-6">
            <span className="text-white">أمانك الرقمي</span>
            <br />
            <span className="bg-gradient-to-r from-pink-500 to-cyan-400 bg-clip-text text-transparent">يبدأ هنا</span>
          </h2>
          
          <p className="text-xl text-slate-300 mb-12">
            انضم لآلاف المستخدمين الذين يتعلمون ويحمون أنفسهم في الفضاء الرقمي
          </p>

          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              onClick={() => setLocation("/programs")}
              className="px-8 py-6 text-lg bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-bold rounded-lg"
            >
              🌸 للبنات - زهرة البرقوق
            </Button>
            <Button
              onClick={() => setLocation("/programs")}
              className="px-8 py-6 text-lg bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-bold rounded-lg"
            >
              🌿 للشباب - غصن البرقوق
            </Button>
            <Button
              onClick={() => setLocation("/programs")}
              className="px-8 py-6 text-lg bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-bold rounded-lg"
            >
              🌺 عطر الفرموزة
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-12 px-4 bg-slate-950">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="text-2xl font-bold">Spirit</div>
                <div className="text-2xl font-bold text-cyan-400">Platform</div>
              </div>
              <p className="text-slate-400 text-sm">
                منصة الأمان الرقمي الشاملة. نحمي ونُعلّم ونُمكّن الجيل الرقمي العربي.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-bold mb-4">روابط سريعة</h3>
              <div className="space-y-2">
                <button onClick={() => setLocation("/programs")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">🌸 زهرة البرقوق</button>
                <button onClick={() => setLocation("/programs")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">🌿 غصن البرقوق</button>
                <button onClick={() => setLocation("/programs")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">🌺 عطر الفرموزة</button>
                <button onClick={() => setLocation("/lessons")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">📚 الدروس</button>
                <button onClick={() => setLocation("/videos")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">🎥 الفيديوهات</button>
              </div>
            </div>

            {/* Resources */}
            <div>
              <h3 className="font-bold mb-4">الأمان الرقمي</h3>
              <div className="space-y-2">
                <a href="#" className="text-slate-400 hover:text-cyan-400 transition text-sm">حماية البيانات الشخصية</a>
                <a href="#" className="text-slate-400 hover:text-cyan-400 transition text-sm">التعامل مع الابتزاز</a>
                <a href="#" className="text-slate-400 hover:text-cyan-400 transition text-sm">الأمن الإلكتروني</a>
                <a href="#" className="text-slate-400 hover:text-cyan-400 transition text-sm">بناء القوة الرقمية</a>
              </div>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-bold mb-4">تواصل معنا</h3>
              <div className="space-y-2">
                <p className="text-slate-400 text-sm">البريد الإلكتروني</p>
                <p className="text-slate-400 text-sm">الهاتف</p>
                <p className="text-slate-400 text-sm">وسائل التواصل</p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 text-center text-slate-400 text-sm">
            <p className="mb-2">© 2025 Spirit Platform - جميع الحقوق محفوظة</p>
            <p>صُنع بـ <span className="text-cyan-400">❤️</span> لأجل الأمان الرقمي العربي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
