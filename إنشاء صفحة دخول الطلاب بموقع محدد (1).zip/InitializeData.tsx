import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";

export default function InitializeData() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const seedMutation = trpc.seed.seedData.useMutation();

  const handleSeed = async () => {
    setLoading(true);
    try {
      const response = await seedMutation.mutateAsync();
      setResult(response);
      console.log("Seed response:", response);
      
      // Redirect to programs after successful seed
      if (response.success) {
        setTimeout(() => {
          setLocation("/programs");
        }, 2000);
      }
    } catch (error) {
      console.error("Seed error:", error);
      setResult({ success: false, error: String(error) });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Auto-seed on mount
    handleSeed();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8 flex items-center justify-center">
      <div className="max-w-2xl mx-auto w-full">
        <Card className="bg-slate-800 border-slate-700 p-8">
          <h1 className="text-3xl font-bold text-white mb-6 text-center">جاري تحضير البيانات</h1>
          
          {!result && (
            <div className="text-center py-8">
              <div className="inline-block">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
              </div>
              <p className="text-slate-300 mt-4">جاري إنشاء البرامج والمستويات والدورات...</p>
            </div>
          )}

          {result && (
            <div className="mt-6 p-6 bg-slate-700 rounded-lg text-white">
              {result.success ? (
                <>
                  <div className="text-green-400 font-bold mb-4">✅ تم بنجاح!</div>
                  <pre className="text-sm overflow-auto">{JSON.stringify(result.data, null, 2)}</pre>
                  <p className="text-slate-300 mt-4">جاري الانتقال للبرامج...</p>
                </>
              ) : (
                <>
                  <div className="text-red-400 font-bold mb-4">❌ حدث خطأ</div>
                  <pre className="text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre>
                  <Button 
                    onClick={handleSeed}
                    className="mt-4 bg-cyan-500 hover:bg-cyan-600"
                  >
                    إعادة المحاولة
                  </Button>
                </>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
