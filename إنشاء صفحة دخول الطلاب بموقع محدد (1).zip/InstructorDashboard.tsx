import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Plus,
  Edit2,
  Trash2,
  Users,
  BookOpen,
  BarChart3,
  LogOut,
} from "lucide-react";

export default function InstructorDashboard() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"programs" | "analytics">(
    "programs"
  );
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    slug: "",
    icon: "📚",
    color: "#06b6d4",
  });

  const { data: programs } = trpc.academic.programs.list.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation("/");
  };

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="text-center">
          <p className="text-red-400 text-lg mb-4">
            ليس لديك صلاحية الوصول لهذه الصفحة
          </p>
          <Button onClick={() => setLocation("/")} className="bg-cyan-600">
            العودة للرئيسية
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">
              لوحة المدرس 👨‍🏫
            </h1>
            <p className="text-slate-400">إدارة البرامج والدروس والطلاب</p>
          </div>
          <Button
            onClick={handleLogout}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700"
          >
            <LogOut className="w-4 h-4" />
            تسجيل خروج
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setActiveTab("programs")}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
              activeTab === "programs"
                ? "bg-cyan-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <BookOpen className="w-5 h-5" />
            البرامج
          </button>
          <button
            onClick={() => setActiveTab("analytics")}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
              activeTab === "analytics"
                ? "bg-cyan-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            <BarChart3 className="w-5 h-5" />
            التحليلات
          </button>
        </div>

        {/* Programs Tab */}
        {activeTab === "programs" && (
          <div>
            {/* Add Program Button */}
            <div className="mb-8">
              <Button
                onClick={() => setShowForm(!showForm)}
                className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-bold"
              >
                <Plus className="w-5 h-5" />
                إضافة برنامج جديد
              </Button>
            </div>

            {/* Add Program Form */}
            {showForm && (
              <Card className="bg-slate-800 border-slate-700 p-6 mb-8">
                <h3 className="text-lg font-bold text-white mb-4">
                  إضافة برنامج جديد
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-300 mb-2">
                      العنوان
                    </label>
                    <Input
                      value={formData.title}
                      onChange={(e) =>
                        setFormData({ ...formData, title: e.target.value })
                      }
                      placeholder="مثال: الأمن السيبراني"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-300 mb-2">
                      الوصف
                    </label>
                    <Input
                      value={formData.description}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          description: e.target.value,
                        })
                      }
                      placeholder="وصف البرنامج"
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-slate-300 mb-2">
                        الرابط (Slug)
                      </label>
                      <Input
                        value={formData.slug}
                        onChange={(e) =>
                          setFormData({ ...formData, slug: e.target.value })
                        }
                        placeholder="cybersecurity"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-300 mb-2">
                        الأيقونة
                      </label>
                      <Input
                        value={formData.icon}
                        onChange={(e) =>
                          setFormData({ ...formData, icon: e.target.value })
                        }
                        placeholder="🔒"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Button className="flex-1 bg-green-600 hover:bg-green-700">
                      حفظ البرنامج
                    </Button>
                    <Button
                      onClick={() => setShowForm(false)}
                      className="flex-1 bg-slate-700 hover:bg-slate-600"
                    >
                      إلغاء
                    </Button>
                  </div>
                </div>
              </Card>
            )}

            {/* Programs List */}
            <div className="space-y-4">
              {programs && programs.length > 0 ? (
                programs.map((program: any) => (
                  <Card
                    key={program.id}
                    className="bg-slate-800 border-slate-700 p-6"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="text-3xl">{program.icon}</div>
                        <div>
                          <h3 className="text-lg font-bold text-white">
                            {program.title}
                          </h3>
                          <p className="text-sm text-slate-400">
                            {program.description}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12">
                  <p className="text-slate-400">لا توجد برامج بعد</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Total Students */}
            <Card className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 border-blue-500/30 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">إجمالي الطلاب</p>
                  <p className="text-3xl font-bold text-blue-400">24</p>
                </div>
                <Users className="w-12 h-12 text-blue-500 opacity-50" />
              </div>
            </Card>

            {/* Active Lessons */}
            <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 border-green-500/30 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">الدروس النشطة</p>
                  <p className="text-3xl font-bold text-green-400">12</p>
                </div>
                <BookOpen className="w-12 h-12 text-green-500 opacity-50" />
              </div>
            </Card>

            {/* Completion Rate */}
            <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500/30 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">معدل الإكمال</p>
                  <p className="text-3xl font-bold text-purple-400">68%</p>
                </div>
                <BarChart3 className="w-12 h-12 text-purple-500 opacity-50" />
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
