"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function Leaderboard() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  // Fetch leaderboard from database
  const { data: leaderboard = [] } = trpc.engagement.rankings.leaderboard.useQuery(
    { limit: 100 },
    { enabled: true }
  );

  // Fetch user's ranking from database
  const { data: userRanking } = trpc.engagement.rankings.userRanking.useQuery(
    undefined,
    { enabled: !!user }
  );

  useEffect(() => {
    // Simulate loading state
    const timer = setTimeout(() => setIsLoading(false), 300);
    return () => clearTimeout(timer);
  }, []);

  // Helper function to get title by points
  function getTitleByPoints(points: number): string {
    if (points < 50) return "مبتدئ";
    if (points < 100) return "متقدم";
    if (points < 200) return "محترف";
    return "أسطورة";
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🏆 لوحة الترتيب</h1>
          <p className="text-slate-400">أفضل الطلاب في منصة الأمان الرقمي</p>
        </div>

        {/* User's Current Ranking */}
        {user && userRanking && (
          <Card className="bg-gradient-to-r from-cyan-600 to-blue-600 border-0 p-6 mb-8">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-cyan-100 text-sm">ترتيبك الحالي</p>
                <h2 className="text-3xl font-bold text-white">{userRanking.rank || "N/A"}</h2>
              </div>
              <div className="text-right">
                <p className="text-cyan-100 text-sm">نقاطك</p>
                <p className="text-4xl font-bold text-white">{userRanking.totalPoints || 0}</p>
              </div>
              <div className="text-right">
                <p className="text-cyan-100 text-sm">مستواك</p>
                <Badge className="bg-yellow-500 text-black font-bold">
                  {getTitleByPoints(userRanking.totalPoints || 0)}
                </Badge>
              </div>
            </div>
          </Card>
        )}

        {/* Leaderboard Table */}
        <Card className="bg-slate-800 border-slate-700 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-900 border-b border-slate-700">
                <tr>
                  <th className="px-6 py-4 text-right text-slate-300 font-semibold">الترتيب</th>
                  <th className="px-6 py-4 text-right text-slate-300 font-semibold">الطالب</th>
                  <th className="px-6 py-4 text-right text-slate-300 font-semibold">النقاط</th>
                  <th className="px-6 py-4 text-right text-slate-300 font-semibold">المستوى</th>
                </tr>
              </thead>
              <tbody>
                {leaderboard.map((entry: any, idx: number) => {
                  const medalEmoji = idx === 0 ? "🥇" : idx === 1 ? "🥈" : idx === 2 ? "🥉" : "";
                  const isCurrentUser = user?.id === entry.userId;
                  
                  return (
                    <tr
                      key={entry.userId}
                      className={`border-b border-slate-700 transition-colors ${
                        isCurrentUser
                          ? "bg-cyan-900/30"
                          : "hover:bg-slate-700/50"
                      }`}
                    >
                      <td className="px-6 py-4 text-slate-300">
                        <span className="font-bold text-lg">{medalEmoji} {entry.rank}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={isCurrentUser ? "text-cyan-400 font-semibold" : "text-white"}>
                          {entry.userName || "مستخدم"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-white font-semibold">{entry.totalPoints}</td>
                      <td className="px-6 py-4">
                        <Badge className={
                          entry.totalPoints < 50 ? "bg-blue-600" :
                          entry.totalPoints < 100 ? "bg-purple-600" :
                          entry.totalPoints < 200 ? "bg-orange-600" :
                          "bg-red-600"
                        }>
                          {getTitleByPoints(entry.totalPoints)}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {leaderboard.length === 0 && (
            <div className="text-center py-12">
              <p className="text-slate-400 text-lg">لا توجد بيانات في الترتيب حالياً</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
