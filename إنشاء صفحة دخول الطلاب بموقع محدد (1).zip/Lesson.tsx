import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { BookOpen, ChevronRight, ArrowLeft, CheckCircle2 } from "lucide-react";

export default function Lesson() {
  // Lesson page - displays individual lesson content - Force rebuild v2
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  
  // Try to parse as number first, otherwise extract ID from slug
  let lessonId: number | undefined;
  if (id) {
    const parsed = parseInt(id, 10);
    if (!isNaN(parsed)) {
      lessonId = parsed;
    } else {
      // Try to extract ID from slug like "lesson-1-1" → ID should be from database
      // For now, just try to parse the first number
      const match = id.match(/\d+/);
      if (match) {
        lessonId = parseInt(match[0], 10);
      }
    }
  }

  const { data: lesson, isLoading } = trpc.academic.lessons.byId.useQuery(lessonId || 0, {
    enabled: !!lessonId,
    retry: 1,
  });
  
  const finalLesson = lesson;
  const finalIsLoading = isLoading;

  const markCompleteMutation = trpc.academic.markLessonComplete.useMutation({
    onSuccess: () => {
      setLocation("/lessons");
    },
  });

  if (finalIsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-center">
        <p className="text-slate-400">جاري التحميل...</p>
      </div>
    );
  }

  if (!finalLesson) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400 mb-4">الدرس غير موجود</p>
          <Button onClick={() => setLocation("/lessons")} variant="outline">
            العودة إلى الدروس
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-cyan-500" />
            <h1 className="text-2xl font-bold">{finalLesson.title}</h1>
          </div>
          <Button
            onClick={() => setLocation("/lessons")}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="bg-slate-800/50 border-slate-700 p-8">
          <div className="space-y-6">
            {/* Lesson Description */}
            <div>
              <h2 className="text-xl font-bold mb-4">محتوى الدرس</h2>
              <p className="text-slate-300 leading-relaxed">
                {finalLesson.contentHtml || finalLesson.description || "لا يوجد محتوى متاح"}
              </p>
            </div>

            {/* Lesson Details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <p className="text-slate-400 text-sm mb-1">رقم الدرس</p>
                <p className="text-xl font-bold">{finalLesson.id}</p>
              </div>
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <p className="text-slate-400 text-sm mb-1">المستوى</p>
                <p className="text-xl font-bold">{finalLesson.difficulty || "مبتدئ"}</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4">
              <Button
                onClick={() => markCompleteMutation.mutate({ lessonId: finalLesson?.id || lessonId || 0 })}
                disabled={markCompleteMutation.isPending}
                className="flex-1 gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                {markCompleteMutation.isPending ? "جاري الحفظ..." : "تم إكمال الدرس"}
              </Button>
              <Button
                onClick={() => setLocation("/lessons")}
                variant="outline"
                className="flex-1 gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                العودة بدون إكمال
              </Button>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
