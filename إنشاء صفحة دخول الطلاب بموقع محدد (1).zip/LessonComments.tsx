import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Send, Star } from "lucide-react";

interface Comment {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  text: string;
  timestamp: string;
  likes: number;
}

interface LessonCommentsProps {
  lessonId: string;
  lessonTitle: string;
}

export default function LessonComments({ lessonId, lessonTitle }: LessonCommentsProps) {
  const [comments, setComments] = useState<Comment[]>([
    {
      id: "1",
      author: "فاطمة محمد",
      avatar: "👩‍💻",
      rating: 5,
      text: "شرح رائع جداً! ساعدني كثيراً في فهم مفهوم الاحتيال الإلكتروني. شكراً لك!",
      timestamp: "منذ ساعة",
      likes: 12,
    },
    {
      id: "2",
      author: "أحمد علي",
      avatar: "👨‍💻",
      rating: 4,
      text: "معلومات مفيدة جداً. كان يمكن إضافة المزيد من الأمثلة العملية.",
      timestamp: "منذ 3 ساعات",
      likes: 8,
    },
    {
      id: "3",
      author: "سارة حسن",
      avatar: "👩‍🎓",
      rating: 5,
      text: "أفضل درس تعليمي عن الأمان الرقمي. شكراً على الجهد!",
      timestamp: "منذ يوم",
      likes: 25,
    },
  ]);

  const [newComment, setNewComment] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleAddComment = () => {
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: String(comments.length + 1),
      author: "أنت",
      avatar: "👤",
      rating: newRating,
      text: newComment,
      timestamp: "الآن",
      likes: 0,
    };

    setComments([comment, ...comments]);
    setNewComment("");
    setNewRating(5);
  };

  const handleLike = (id: string) => {
    setComments(
      comments.map((comment) =>
        comment.id === id ? { ...comment, likes: comment.likes + 1 } : comment
      )
    );
  };

  return (
    <div className="mt-12 mb-8">
      <Card className="bg-slate-800 border-slate-700 p-6">
        <h2 className="text-2xl font-bold text-white mb-6">💬 التعليقات والآراء</h2>

        {/* Add Comment Section */}
        <div className="bg-slate-900/50 rounded-lg p-6 mb-8">
          <div className="mb-4">
            <label className="text-slate-300 text-sm mb-2 block">تقييمك للدرس</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setNewRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-6 h-6 ${
                      star <= (hoveredRating || newRating)
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-slate-500"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <label className="text-slate-300 text-sm mb-2 block">أضف تعليقك</label>
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="شارك رأيك وتجربتك مع هذا الدرس..."
              className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 resize-none"
              rows={3}
            />
          </div>

          <Button
            onClick={handleAddComment}
            disabled={!newComment.trim()}
            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 disabled:opacity-50"
          >
            <Send className="w-4 h-4 mr-2" />
            نشر التعليق
          </Button>
        </div>

        {/* Comments List */}
        <div className="space-y-4">
          {comments.map((comment) => (
            <div key={comment.id} className="bg-slate-900/30 border border-slate-700 rounded-lg p-4 hover:border-slate-600 transition">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="text-3xl">{comment.avatar}</div>
                  <div>
                    <p className="text-white font-semibold">{comment.author}</p>
                    <p className="text-slate-400 text-sm">{comment.timestamp}</p>
                  </div>
                </div>

                {/* Rating Stars */}
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= comment.rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "text-slate-600"
                      }`}
                    />
                  ))}
                </div>
              </div>

              <p className="text-slate-300 mb-3">{comment.text}</p>

              <button
                onClick={() => handleLike(comment.id)}
                className="text-slate-400 hover:text-cyan-400 transition text-sm flex items-center gap-1"
              >
                👍 {comment.likes > 0 && <span>{comment.likes}</span>}
              </button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
