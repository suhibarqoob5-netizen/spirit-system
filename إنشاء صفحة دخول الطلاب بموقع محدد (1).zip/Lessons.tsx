import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { BookOpen, ChevronRight, ArrowLeft, CheckCircle2, Clock } from "lucide-react";

export default function Lessons() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProgram, setSelectedProgram] = useState<number | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<number | null>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      // Temporarily disabled for testing
      // setLocation("/login");
    }
  }, [user, setLocation]);

  const { data: programs = [], isLoading: programsLoading } = trpc.academic.programs.list.useQuery(undefined, {
    enabled: true,
    retry: 1,
  });

  const { data: levels = [], isLoading: levelsLoading } = trpc.academic.levels.byProgram.useQuery(
    selectedProgram || 0,
    {
      enabled: !!selectedProgram,
      retry: 1,
    }
  );

  const { data: courses = [], isLoading: coursesLoading } = trpc.academic.courses.byLevel.useQuery(
    selectedLevel || 0,
    {
      enabled: !!selectedLevel,
      retry: 1,
    }
  );

  const { data: lessons = [], isLoading: lessonsLoading } = trpc.academic.lessons.byCourse.useQuery(
    selectedCourse || 0,
    {
      enabled: !!selectedCourse,
      retry: 1,
    }
  );

  const { data: userProgress = [], isLoading: progressLoading } = trpc.academic.userProgress.useQuery(undefined, {
    enabled: true,
    retry: 1,
  });

  useEffect(() => {
    const allLoading = programsLoading || levelsLoading || coursesLoading || lessonsLoading || progressLoading;
    setIsLoading(allLoading);
  }, [programsLoading, levelsLoading, coursesLoading, lessonsLoading, progressLoading]);

  // Temporarily disabled for testing
  // if (!user) {
  //   return null;
  // }

  const completedLessonIds = new Set(
    Array.isArray(userProgress) ? userProgress.filter((p: any) => p.completed).map((p: any) => p.lessonId) : []
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-cyan-500" />
            <h1 className="text-2xl font-bold">الدروس</h1>
          </div>
          <Button
            onClick={() => setLocation("/dashboard")}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!selectedProgram ? (
          <>
            <h2 className="text-xl font-bold mb-4">اختر برنامجاً</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {programs.map((program: any) => (
                <Card
                  key={program.id}
                  className="bg-slate-800/50 border-slate-700 p-6 hover:border-pink-500 transition-colors cursor-pointer"
                  onClick={() => {
                    setSelectedProgram(program.id);
                    setSelectedLevel(null);
                    setSelectedCourse(null);
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="text-3xl mb-2">{program.icon}</div>
                      <h3 className="text-lg font-bold mb-2">{program.title}</h3>
                      <p className="text-slate-400 text-sm">{program.description}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400" />
                  </div>
                </Card>
              ))}
            </div>
          </>
        ) : !selectedLevel ? (
          <>
            <div className="flex items-center gap-2 mb-6">
              <Button
                onClick={() => {
                  setSelectedProgram(null);
                  setSelectedLevel(null);
                  setSelectedCourse(null);
                }}
                variant="ghost"
                size="sm"
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                العودة للبرامج
              </Button>
            </div>

            <h2 className="text-xl font-bold mb-4">اختر المستوى</h2>

            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-slate-400">جاري التحميل...</p>
              </div>
            ) : levels.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-slate-400">لا توجد مستويات متاحة</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {levels.map((level: any) => (
                  <Card
                    key={level.id}
                    className="bg-slate-800/50 border-slate-700 p-6 hover:border-pink-500 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedLevel(level.id);
                      setSelectedCourse(null);
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold mb-2">{level.title}</h3>
                        <p className="text-slate-400 text-sm">{level.description}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400" />
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </>
        ) : !selectedCourse ? (
          <>
            <div className="flex items-center gap-2 mb-6">
              <Button
                onClick={() => {
                  setSelectedLevel(null);
                  setSelectedCourse(null);
                }}
                variant="ghost"
                size="sm"
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                العودة للمستويات
              </Button>
            </div>

            <h2 className="text-xl font-bold mb-4">اختر الدورة</h2>

            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-slate-400">جاري التحميل...</p>
              </div>
            ) : courses.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-slate-400">لا توجد دورات متاحة</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {courses.map((course: any) => (
                  <Card
                    key={course.id}
                    className="bg-slate-800/50 border-slate-700 p-6 hover:border-pink-500 transition-colors cursor-pointer"
                    onClick={() => setSelectedCourse(course.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold mb-2">{course.title}</h3>
                        <p className="text-slate-400 text-sm">{course.description}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400" />
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-6">
              <Button
                onClick={() => setSelectedCourse(null)}
                variant="ghost"
                size="sm"
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                العودة للدورات
              </Button>
            </div>

            <h2 className="text-xl font-bold mb-4">دروس الدورة</h2>

            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-slate-400">جاري التحميل...</p>
              </div>
            ) : lessons.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-slate-400">لا توجد دروس متاحة</p>
              </div>
            ) : (
              <div className="space-y-4">
                {lessons.map((lesson: any, index: number) => {
                  const isCompleted = completedLessonIds.has(lesson.id);
                  return (
                    <Card
                      key={lesson.id}
                      className="bg-slate-800/50 border-slate-700 p-6 hover:border-pink-500 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="text-2xl font-bold text-slate-600">
                              {String(index + 1).padStart(2, "0")}
                            </span>
                            <div>
                              <h3 className="text-lg font-bold flex items-center gap-2">
                                {lesson.title}
                                {isCompleted && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                              </h3>
                              <p className="text-slate-400 text-sm">{lesson.content || lesson.description}</p>
                            </div>
                          </div>
                        </div>

                        <Button
                          onClick={() => setLocation(`/lesson/${lesson.id}`)}
                          variant={isCompleted ? "outline" : "default"}
                          className="gap-2"
                        >
                          {isCompleted ? "أعد الدرس" : "ابدأ الآن"}
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
