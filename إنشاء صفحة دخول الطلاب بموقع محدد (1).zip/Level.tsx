import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ChevronLeft } from "lucide-react";

export default function Level() {
  const [location, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const levelId = parseInt(id || "0");
  
  const { data: level } = trpc.academic.levels.byId.useQuery(levelId || 0);
  const { data: courses, isLoading } = trpc.academic.courses.byLevel.useQuery(
    levelId || 0,
    { enabled: !!levelId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="text-slate-300">جاري التحميل...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => window.history.back()}
          className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          عودة
        </button>

        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {level?.title}
          </h1>
          <p className="text-lg text-slate-300">{level?.description}</p>
        </div>

        {/* Courses Grid */}
        {courses && courses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course: any) => (
              <Card
                key={course.id}
                className="bg-slate-800 border-purple-500/30 hover:border-purple-500 hover:shadow-lg hover:shadow-purple-500/20 transition-all cursor-pointer group"
                onClick={() => setLocation(`/course/${course.slug}`)}
              >
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">
                    {course.title}
                  </h3>
                  <p className="text-sm text-slate-300 mb-4 line-clamp-3">
                    {course.description}
                  </p>
                  <Button
                    className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/course/${course.slug}`);
                    }}
                  >
                    ادخل المادة
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-slate-400">لا توجد مواد متاحة</p>
          </div>
        )}
      </div>
    </div>
  );
}
