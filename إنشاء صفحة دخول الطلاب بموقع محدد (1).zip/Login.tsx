import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const STUDENTS = [
  { name: "Yosef hamamrah", password: "yosef123" },
  { name: "Istabraq Abu Srhan", password: "istabraq123" },
  { name: "Naheel fatayergy", password: "naheel123" },
  { name: "Mai farrah", password: "mai123" },
  { name: "Mays Nasser", password: "mays123" },
  { name: "Diaa othman", password: "diaa123" },
  { name: "Ward alayan", password: "ward123" },
];

export default function Login() {
  const [, setLocation] = useLocation();
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPasswordInput, setShowPasswordInput] = useState(false);

  const handleStudentSelect = (studentName: string) => {
    setSelectedStudent(studentName);
    setShowPasswordInput(true);
    setPassword("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedStudent) {
      toast.error("يرجى اختيار اسم الطالب");
      return;
    }

    const student = STUDENTS.find((s) => s.name === selectedStudent);
    if (!student) {
      toast.error("الطالب غير موجود");
      return;
    }

    if (password !== student.password) {
      toast.error("كلمة المرور غير صحيحة");
      return;
    }

    setIsLoading(true);
    try {
      // محاكاة تسجيل الدخول - في الواقع يجب أن يكون هناك API
      localStorage.setItem("currentStudent", selectedStudent);
      toast.success(`مرحباً ${selectedStudent}!`);
      setLocation("/dashboard");
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدخول");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-slate-800/50 border-slate-700">
        <div className="p-8">
          <div className="text-center mb-8">
            <div className="text-4xl mb-3">🌸</div>
            <h1 className="text-2xl font-bold text-white mb-2">عطر الفرموزة</h1>
            <p className="text-slate-400">طلاب بيت صفافا</p>
          </div>

          {!showPasswordInput ? (
            <div className="space-y-3">
              <p className="text-slate-300 text-center mb-4">اختر اسم الطالب:</p>
              {STUDENTS.map((student) => (
                <Button
                  key={student.name}
                  onClick={() => handleStudentSelect(student.name)}
                  className="w-full bg-slate-700 hover:bg-pink-500 text-white font-bold py-2 rounded-lg transition-all"
                >
                  {student.name}
                </Button>
              ))}
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="student" className="text-slate-200">
                  الطالب المختار
                </Label>
                <div className="mt-2 p-3 bg-slate-700 border border-slate-600 rounded-lg text-white font-bold">
                  {selectedStudent}
                </div>
              </div>

              <div>
                <Label htmlFor="password" className="text-slate-200">
                  كلمة المرور
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="أدخل كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="mt-2 bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                  disabled={isLoading}
                  autoFocus
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="flex-1 bg-pink-500 hover:bg-pink-600 text-white font-bold py-2 rounded-lg transition-all"
                  disabled={isLoading}
                >
                  {isLoading ? "جاري الدخول..." : "دخول"}
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    setShowPasswordInput(false);
                    setSelectedStudent(null);
                    setPassword("");
                  }}
                  className="flex-1 bg-slate-700 hover:bg-slate-600 text-white font-bold py-2 rounded-lg transition-all"
                  disabled={isLoading}
                >
                  رجوع
                </Button>
              </div>
            </form>
          )}

          <div className="mt-6 text-center">
            <p className="text-slate-400 text-sm">
              تطير النحلة تشدو بين ألوان الزهور
            </p>
            <p className="text-slate-400 text-sm mt-1">
              بين زهرة البرقوق وعطر الفرموزة يحلو
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
