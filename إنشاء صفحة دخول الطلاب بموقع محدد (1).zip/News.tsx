import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Spinner } from "@/components/ui/spinner";
import { AlertCircle, Search, TrendingUp } from "lucide-react";

const categoryColors: Record<string, string> = {
  "تهديدات": "bg-red-100 text-red-800",
  "نصائح": "bg-green-100 text-green-800",
  "تحديثات": "bg-blue-100 text-blue-800",
  "أبحاث": "bg-purple-100 text-purple-800",
  "أحداث": "bg-yellow-100 text-yellow-800",
  "أخرى": "bg-gray-100 text-gray-800",
};

const severityColors: Record<string, string> = {
  "منخفضة": "bg-green-100 text-green-800",
  "متوسطة": "bg-yellow-100 text-yellow-800",
  "عالية": "bg-orange-100 text-orange-800",
  "حرجة": "bg-red-100 text-red-800",
};

export default function News() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNews, setSelectedNews] = useState<any>(null);

  // Fetch latest news
  const { data: latestNews, isLoading: latestLoading } = trpc.news.latest.useQuery(
    { limit: 20 },
    { staleTime: 5 * 60 * 1000 } // Cache for 5 minutes
  );

  // Fetch news by category
  const { data: categoryNews } = trpc.news.byCategory.useQuery(
    { category: selectedCategory as any, limit: 20 },
    { enabled: !!selectedCategory, staleTime: 5 * 60 * 1000 }
  );

  // Search news
  const { data: searchResults } = trpc.news.search.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length > 2, staleTime: 5 * 60 * 1000 }
  );

  // Determine which news to display
  const displayNews = useMemo(() => {
    if (searchQuery.length > 2 && searchResults?.data) {
      return searchResults.data;
    }
    if (selectedCategory && categoryNews?.data) {
      return categoryNews.data;
    }
    return latestNews?.data || [];
  }, [searchQuery, searchResults, selectedCategory, categoryNews, latestNews]);

  const categories = ["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث"];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold">أخبار الأمان السيبراني</h1>
          </div>
          <p className="text-slate-300 text-lg">
            آخر أخبار وتحديثات الأمان السيبراني والتهديدات الرقمية
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              type="text"
              placeholder="ابحث عن الأخبار..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-700 border-slate-600 text-white placeholder-slate-400"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="mb-8">
          <p className="text-sm font-semibold text-slate-300 mb-3">الفئات:</p>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="rounded-full"
            >
              الكل
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className="rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Loading State */}
        {latestLoading && (
          <div className="flex justify-center items-center py-12">
            <Spinner className="w-8 h-8" />
          </div>
        )}

        {/* News Grid */}
        {!latestLoading && displayNews && displayNews.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayNews.map((news: any) => (
              <Card
                key={news.id}
                className="bg-slate-700 border-slate-600 hover:border-cyan-400 transition-all cursor-pointer"
                onClick={() => setSelectedNews(news)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <Badge className={categoryColors[news.category] || categoryColors["أخرى"]}>
                      {news.category}
                    </Badge>
                    <Badge className={severityColors[news.severity] || severityColors["متوسطة"]}>
                      {news.severity}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl text-white line-clamp-2">
                    {news.title}
                  </CardTitle>
                  <CardDescription className="text-slate-300">
                    {new Date(news.publishedAt).toLocaleDateString("ar-SA", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {news.imageUrl && (
                    <img
                      src={news.imageUrl}
                      alt={news.title}
                      className="w-full h-40 object-cover rounded-lg mb-4"
                    />
                  )}
                  <p className="text-slate-300 line-clamp-3">
                    {news.summary || news.content}
                  </p>
                  {news.source && (
                    <p className="text-sm text-slate-400 mt-3">
                      المصدر: {news.source}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!latestLoading && (!displayNews || displayNews.length === 0) && (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-300 text-lg">لا توجد أخبار في هذه الفئة</p>
          </div>
        )}

        {/* News Detail Modal */}
        {selectedNews && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-slate-800 border-slate-600 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <CardHeader className="sticky top-0 bg-slate-800 border-b border-slate-600">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex gap-2">
                    <Badge className={categoryColors[selectedNews.category]}>
                      {selectedNews.category}
                    </Badge>
                    <Badge className={severityColors[selectedNews.severity]}>
                      {selectedNews.severity}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedNews(null)}
                    className="text-slate-300"
                  >
                    ✕
                  </Button>
                </div>
                <CardTitle className="text-2xl text-white">
                  {selectedNews.title}
                </CardTitle>
                <CardDescription className="text-slate-300">
                  {new Date(selectedNews.publishedAt).toLocaleDateString("ar-SA", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {selectedNews.imageUrl && (
                  <img
                    src={selectedNews.imageUrl}
                    alt={selectedNews.title}
                    className="w-full h-80 object-cover rounded-lg mb-6"
                  />
                )}
                <div className="prose prose-invert max-w-none">
                  <p className="text-slate-200 leading-relaxed whitespace-pre-wrap">
                    {selectedNews.content}
                  </p>
                </div>
                {selectedNews.source && (
                  <div className="mt-6 pt-6 border-t border-slate-600">
                    <p className="text-sm text-slate-400">
                      المصدر: {selectedNews.source}
                    </p>
                    {selectedNews.sourceUrl && (
                      <a
                        href={selectedNews.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 text-sm mt-2 inline-block"
                      >
                        اقرأ المزيد →
                      </a>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
