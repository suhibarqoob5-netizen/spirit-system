import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Bell, X } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

export function NotificationBell() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  // Get unread count
  const { data: countData } = trpc.notifications.unreadCount.useQuery(
    undefined,
    { enabled: !!user, refetchInterval: 30000 } // Refetch every 30 seconds
  );

  // Get unread notifications
  const { data: notifData } = trpc.notifications.unread.useQuery(
    { limit: 5 },
    { enabled: !!user && isOpen }
  );

  // Mark as read mutation
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation();

  useEffect(() => {
    if (notifData?.data) {
      setNotifications(notifData.data);
    }
  }, [notifData]);

  if (!user) return null;

  const unreadCount = (countData?.unreadCount as number) || 0;

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 rounded-lg shadow-xl z-50 border border-slate-200 dark:border-slate-700">
          <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h3 className="font-semibold">الإشعارات</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {notifications.length > 0 ? (
              notifications.map((notif) => (
                <div
                  key={notif.id}
                  className="p-3 border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer"
                  onClick={() => {
                    markAsReadMutation.mutate({ notificationId: notif.id });
                  }}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{notif.title}</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                        {notif.message}
                      </p>
                    </div>
                    {notif.type === "breaking" && (
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">
                        عاجل
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-2">
                    {new Date(notif.createdAt).toLocaleTimeString("ar-SA")}
                  </p>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-slate-500 text-sm">
                لا توجد إشعارات جديدة
              </div>
            )}
          </div>

          <div className="p-3 border-t border-slate-200 dark:border-slate-700">
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => {
                setIsOpen(false);
                // Navigate to notifications page
                window.location.href = "/notifications";
              }}
            >
              عرض جميع الإشعارات
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
