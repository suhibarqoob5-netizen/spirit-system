import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Spinner } from "@/components/ui/spinner";
import { Bell, Trash2, CheckCircle } from "lucide-react";

export default function Notifications() {
  const [filter, setFilter] = useState<"all" | "unread">("unread");

  // Fetch notifications
  const { data: notificationsData, isLoading } = trpc.notifications[
    filter === "unread" ? "unread" : "all"
  ].useQuery(
    { limit: 100 },
    { staleTime: 10 * 1000 } // Cache for 10 seconds
  );

  // Mutations
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation();
  const markAllAsReadMutation = trpc.notifications.markAllAsRead.useMutation();
  const deleteMutation = trpc.notifications.delete.useMutation();
  const deleteAllMutation = trpc.notifications.deleteAll.useMutation();

  const notifications = notificationsData?.data || [];

  const typeColors: Record<string, string> = {
    breaking: "bg-red-100 text-red-800",
    urgent: "bg-orange-100 text-orange-800",
    important: "bg-yellow-100 text-yellow-800",
    info: "bg-blue-100 text-blue-800",
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl font-bold">الإشعارات</h1>
          </div>
          <p className="text-slate-300 text-lg">
            آخر الإشعارات والتنبيهات الخاصة بك
          </p>
        </div>

        {/* Filter and Actions */}
        <div className="mb-8 flex justify-between items-center gap-4">
          <div className="flex gap-2">
            <Button
              variant={filter === "unread" ? "default" : "outline"}
              onClick={() => setFilter("unread")}
            >
              غير مقروءة
            </Button>
            <Button
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
            >
              الكل
            </Button>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={notifications.length === 0}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              تحديث الكل
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => deleteAllMutation.mutate()}
              disabled={notifications.length === 0}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              حذف الكل
            </Button>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Spinner className="w-8 h-8" />
          </div>
        )}

        {/* Notifications List */}
        {!isLoading && notifications.length > 0 && (
          <div className="space-y-4">
            {notifications.map((notif: any) => (
              <Card
                key={notif.id}
                className={`bg-slate-700 border-slate-600 ${
                  !notif.isRead ? "border-l-4 border-l-cyan-400" : ""
                }`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={typeColors[notif.type] || typeColors["info"]}>
                          {notif.type === "breaking" && "عاجل"}
                          {notif.type === "urgent" && "عاجل جداً"}
                          {notif.type === "important" && "مهم"}
                          {notif.type === "info" && "معلومة"}
                        </Badge>
                        {!notif.isRead && (
                          <span className="w-3 h-3 bg-cyan-400 rounded-full"></span>
                        )}
                      </div>
                      <CardTitle className="text-xl text-white">
                        {notif.title}
                      </CardTitle>
                      <CardDescription className="text-slate-300 mt-2">
                        {new Date(notif.createdAt).toLocaleDateString("ar-SA", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {!notif.isRead && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            markAsReadMutation.mutate({ notificationId: notif.id })
                          }
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate({ notificationId: notif.id })}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                {notif.message && (
                  <CardContent>
                    <p className="text-slate-300">{notif.message}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && notifications.length === 0 && (
          <div className="text-center py-12">
            <Bell className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-300 text-lg">
              {filter === "unread"
                ? "لا توجد إشعارات غير مقروءة"
                : "لا توجد إشعارات"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
