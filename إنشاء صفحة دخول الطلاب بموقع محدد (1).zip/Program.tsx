import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ChevronLeft } from "lucide-react";

export default function Program() {
  const [location, setLocation] = useLocation();
  const { slug } = useParams<{ slug: string }>();
  
  const { data: program } = trpc.academic.programs.bySlug.useQuery(slug || "");
  const { data: levels, isLoading } = trpc.academic.levels.byProgram.useQuery(
    program?.id || 0,
    { enabled: !!program }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="text-slate-300">جاري التحميل...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => setLocation("/programs")}
          className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          عودة للبرامج
        </button>

        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {program?.title}
          </h1>
          <p className="text-lg text-slate-300">{program?.description}</p>
        </div>

        {/* Levels Grid */}
        {levels && levels.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {levels.map((level: any) => (
              <Card
                key={level.id}
                className="bg-slate-800 border-pink-500/30 hover:border-pink-500 hover:shadow-lg hover:shadow-pink-500/20 transition-all cursor-pointer group"
                onClick={() => setLocation(`/level/${level.id}`)}
              >
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">
                    {level.title}
                  </h3>
                  <p className="text-sm text-slate-300 mb-4 line-clamp-3">
                    {level.description}
                  </p>
                  <Button
                    className="w-full bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/level/${level.id}`);
                    }}
                  >
                    ابدأ المستوى
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-slate-400">لا توجد مستويات متاحة</p>
          </div>
        )}
      </div>
    </div>
  );
}
