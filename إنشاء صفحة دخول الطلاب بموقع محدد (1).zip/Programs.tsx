import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

export default function Programs() {
  const [, setLocation] = useLocation();
  const { data: programs, isLoading } = trpc.academic.programs.list.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            البرامج التعليمية
          </h1>
          <p className="text-lg text-cyan-300">
            اختر البرنامج الذي تريد تعلمه وابدأ رحلتك التعليمية
          </p>
        </div>

        {/* Programs Grid */}
        {programs && programs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {programs.map((program: any) => (
              <Card
                key={program.id}
                className="bg-slate-800 border-cyan-500/30 hover:border-cyan-500 hover:shadow-lg hover:shadow-cyan-500/20 transition-all cursor-pointer group"
                onClick={() => setLocation(`/program/${program.slug}`)}
              >
                <div className="p-6">
                  {/* Icon */}
                  {program.icon && (
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">
                      {program.icon}
                    </div>
                  )}

                  {/* Title */}
                  <h3 className="text-xl font-bold text-white mb-2">
                    {program.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-300 mb-4 line-clamp-3">
                    {program.description}
                  </p>

                  {/* Button */}
                  <Button
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLocation(`/program/${program.slug}`);
                    }}
                  >
                    ابدأ الآن
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg text-slate-400">لا توجد برامج متاحة حالياً</p>
          </div>
        )}
      </div>
    </div>
  );
}
