import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";
import { BookOpen, CheckCircle, Clock, Award } from "lucide-react";

export default function ProgressPage() {
  const [, setLocation] = useLocation();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const { data: userProgress } = trpc.academic.userProgress.useQuery(undefined, {
    enabled: !!user,
  });
  const { data: programs } = trpc.academic.programs.list.useQuery();
  const { data: userRanking } = trpc.engagement.rankings.userRanking.useQuery(
    undefined,
    { enabled: !!user }
  );

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="text-slate-300">جاري التحميل...</p>
      </div>
    );
  }

  const completedLessons = userProgress?.filter((p: any) => p.completed).length || 0;
  const totalLessons = userProgress?.length || 1;
  const completionPercentage =
    totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">📊 تقدمك التعليمي</h1>
          <p className="text-gray-400">تابع مسيرتك في رحلة التعلم</p>
        </div>

        {/* Overall Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">الدروس المكتملة</p>
                <p className="text-3xl font-bold text-cyan-400">{completedLessons}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </Card>

          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">إجمالي الدروس</p>
                <p className="text-3xl font-bold text-cyan-400">{totalLessons}</p>
              </div>
              <BookOpen className="w-8 h-8 text-blue-400" />
            </div>
          </Card>

          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">نسبة الإكمال</p>
                <p className="text-3xl font-bold text-pink-400">{completionPercentage}%</p>
              </div>
              <Clock className="w-8 h-8 text-pink-400" />
            </div>
          </Card>

          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">النقاط الإجمالية</p>
                <p className="text-3xl font-bold text-yellow-400">{userRanking?.totalPoints || 0}</p>
              </div>
              <Award className="w-8 h-8 text-yellow-400" />
            </div>
          </Card>
        </div>

        {/* Overall Progress Bar */}
        <Card className="bg-slate-800 border-slate-700 p-6 mb-8">
          <h2 className="text-xl font-bold text-white mb-4">التقدم الإجمالي</h2>
          <Progress value={completionPercentage} className="h-3" />
          <p className="text-gray-400 text-sm mt-2">{completionPercentage}% مكتمل</p>
        </Card>

        {/* Progress by Program */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">التقدم حسب البرنامج</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {programs?.map((program: any) => {
              const programLessons = userProgress?.filter(
                (p: any) => p.lessonId && (typeof p.lessonId === 'string' ? p.lessonId.includes(program.id) : p.lessonId === program.id)
              ) || [];
              const completed = programLessons.filter((p: any) => p.completed).length;
              const total = programLessons.length || 1;
              const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

              return (
                <Card key={program.id} className="bg-slate-800 border-slate-700 p-6">
                  <h3 className="text-lg font-bold text-white mb-4">{program.name}</h3>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-gray-400">{completed} من {total}</span>
                        <span className="text-cyan-400 font-bold">{percentage}%</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                    <Button
                      onClick={() => setLocation(`/program/${program.slug}`)}
                      className="w-full bg-cyan-600 hover:bg-cyan-700"
                    >
                      عرض التفاصيل
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Lessons List */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">قائمة الدروس</h2>
          <div className="space-y-3">
            {userProgress?.map((lesson: any, idx: number) => (
              <Card
                key={idx}
                className={`border-slate-700 p-4 flex items-center justify-between ${
                  lesson.completed ? "bg-green-900/20 border-green-700" : "bg-slate-800"
                }`}
              >
                <div className="flex items-center gap-4">
                  {lesson.completed ? (
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  ) : (
                    <Clock className="w-6 h-6 text-yellow-400" />
                  )}
                  <div>
                    <p className="font-semibold text-white">الدرس #{idx + 1}</p>
                    <p className="text-sm text-gray-400">
                      {lesson.completed ? "✓ مكتمل" : "قيد الدراسة"}
                    </p>
                  </div>
                </div>
                <span className={`text-sm font-bold ${lesson.completed ? "text-green-400" : "text-yellow-400"}`}>
                  {lesson.completed ? "مكتمل" : "قيد الدراسة"}
                </span>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
