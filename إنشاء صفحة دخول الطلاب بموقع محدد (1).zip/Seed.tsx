// Seed page removed - using API endpoint instead
