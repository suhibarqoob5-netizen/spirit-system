import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function Skills() {
  const { data: skills, refetch } = trpc.engagement.skills.byUser.useQuery();
  const { data: skillsCount } = trpc.engagement.skills.count.useQuery();
  const createSkillMutation = trpc.engagement.skills.create.useMutation();

  const [skillName, setSkillName] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateSkill = async () => {
    if (!skillName.trim()) {
      toast.error("أدخل اسم المهارة");
      return;
    }

    setIsCreating(true);
    try {
      await createSkillMutation.mutateAsync({
        name: skillName,
        points: 10,
        level: "مبتدئ",
      });
      setSkillName("");
      refetch();
      toast.success("تم إضافة المهارة بنجاح!");
    } catch (error) {
      toast.error("حدث خطأ في إضافة المهارة");
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🎓 المهارات المكتسبة</h1>
          <p className="text-slate-300">عدد المهارات: {skillsCount || 0}</p>
        </div>

        {/* Create Skill Form */}
        <Card className="mb-8 p-6 bg-slate-800/50 border-slate-700">
          <h2 className="text-xl font-bold text-white mb-4">إضافة مهارة جديدة</h2>
          <div className="flex gap-2">
            <Input
              placeholder="اسم المهارة (مثال: قراءة العبرية)"
              value={skillName}
              onChange={(e) => setSkillName(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              onKeyPress={(e) => e.key === "Enter" && handleCreateSkill()}
            />
            <Button
              onClick={handleCreateSkill}
              disabled={isCreating}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
            >
              {isCreating ? "جاري..." : "إضافة"}
            </Button>
          </div>
        </Card>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {skills?.map((skill) => (
            <Card
              key={skill.id}
              className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 hover:border-blue-500 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{skill.name}</h3>
                  <Badge
                    variant="outline"
                    className={`mt-2 ${
                      skill.level === "مبتدئ"
                        ? "bg-green-500/20 text-green-300 border-green-500/50"
                        : skill.level === "متوسط"
                        ? "bg-yellow-500/20 text-yellow-300 border-yellow-500/50"
                        : "bg-red-500/20 text-red-300 border-red-500/50"
                    }`}
                  >
                    {skill.level}
                  </Badge>
                </div>
                <span className="text-2xl font-bold text-blue-400">{skill.points || 10}</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full"
                  style={{
                    width: `${Math.min((skill.points || 10) / 50 * 100, 100)}%`,
                  }}
                ></div>
              </div>

              {/* Stats */}
              <div className="mt-4 flex justify-between text-sm text-slate-400">
                <span>تاريخ الحصول: {new Date(skill.createdAt).toLocaleDateString("ar-EG")}</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {!skills || skills.length === 0 && (
          <Card className="p-8 text-center bg-slate-800/50 border-slate-700">
            <p className="text-slate-300 text-lg">لم تكتسب أي مهارات حتى الآن</p>
            <p className="text-slate-400 text-sm mt-2">أكمل الدروس وحول معرفتك إلى مهارات!</p>
          </Card>
        )}
      </div>
    </div>
  );
}
