import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  BookOpen,
  Target,
  Award,
  TrendingUp,
  ChevronRight,
  LogOut,
  Zap,
} from "lucide-react";

// Mock data for fallback
const MOCK_PROGRAMS = [
  {
    id: 1,
    slug: "zahr-al-barqooq",
    title: "زهرة البرقوق 🌸",
    description: "برنامج تعليمي شامل للأمان الرقمي للمبتدئين",
    icon: "🌸",
  },
  {
    id: 2,
    slug: "ghosn-al-barqooq",
    title: "غصن البرقوق 🌿",
    description: "برنامج متقدم في الأمان الرقمي والحماية من التهديدات",
    icon: "🌿",
  },
];

export default function StudentDashboard() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  // Get current student from localStorage
  const [currentStudent, setCurrentStudent] = useState<string | null>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    const student = localStorage.getItem("currentStudent");
    if (!student) {
      setLocation("/login");
    } else {
      setCurrentStudent(student);
    }
  }, [setLocation]);

  // Queries with proper error handling
  const { data: programs = MOCK_PROGRAMS, isLoading: programsLoading } = trpc.academic.programs.list.useQuery(undefined, {
    retry: 1,
    staleTime: 1000 * 60 * 5,
  });

  const { data: userProgress = [], isLoading: progressLoading } = trpc.academic.userProgress.useQuery(undefined, {
    enabled: !!user,
    retry: 1,
  });

  const { data: userRanking = { totalPoints: 0, rank: 0 }, isLoading: rankingLoading } = trpc.engagement.rankings.userRanking.useQuery(
    undefined,
    {
      enabled: !!user,
      retry: 1,
    }
  );

  const { data: userSkills = [], isLoading: skillsLoading } = trpc.engagement.skills.byUser.useQuery(
    undefined,
    {
      enabled: !!user,
      retry: 1,
    }
  );

  const logoutMutation = trpc.auth.logout.useMutation();

  // Set loading state based on all queries
  useEffect(() => {
    const allLoading = programsLoading || progressLoading || rankingLoading || skillsLoading;
    setIsLoading(allLoading);
  }, [programsLoading, progressLoading, rankingLoading, skillsLoading]);

  const handleLogout = async () => {
    try {
      localStorage.removeItem("currentStudent");
      await logoutMutation.mutateAsync();
      setLocation("/login");
    } catch (error) {
      console.error('Logout error:', error);
      localStorage.removeItem("currentStudent");
      setLocation("/login");
    }
  };

  if (!currentStudent) {
    return null;
  }

  const completedLessons = Array.isArray(userProgress) ? userProgress.filter((p: any) => p.completed).length : 0;
  const totalLessons = Array.isArray(userProgress) ? userProgress.length : 0;
  const completionPercentage = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="text-3xl">🌸</div>
            <div>
              <h1 className="text-2xl font-bold">Spirit Platform</h1>
              <p className="text-sm text-slate-400">Ward alayan - نظام الطلاب</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-semibold">{currentStudent}</p>
              <p className="text-sm text-slate-400">Ward alayan</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              تسجيل خروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">أهلاً بك {currentStudent}! 👋</h2>
          <p className="text-slate-400">مرحباً بك في منصة الأمان الرقمي - Ward alayan</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">الدروس المكتملة</p>
                <p className="text-3xl font-bold">{completedLessons}</p>
              </div>
              <BookOpen className="w-8 h-8 text-pink-500" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">النقاط</p>
                <p className="text-3xl font-bold">{userRanking?.totalPoints || 0}</p>
              </div>
              <Zap className="w-8 h-8 text-yellow-500" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">الترتيب</p>
                <p className="text-3xl font-bold">#{userRanking?.rank || 0}</p>
              </div>
              <Target className="w-8 h-8 text-cyan-500" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">المهارات</p>
                <p className="text-3xl font-bold">{userSkills?.length || 0}</p>
              </div>
              <Award className="w-8 h-8 text-green-500" />
            </div>
          </Card>
        </div>

        {/* Progress Section */}
        <Card className="bg-slate-800/50 border-slate-700 p-6 mb-8">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-pink-500" />
            التقدم العام
          </h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">اكتمال الدروس</span>
              <span className="font-semibold">{Math.round(completionPercentage)}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2" />
          </div>
        </Card>

        {/* Programs Section */}
        <div className="mb-8">
          <h3 className="text-xl font-bold mb-4">البرامج التعليمية</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {programs.map((program: any) => (
              <Card
                key={program.id}
                className="bg-slate-800/50 border-slate-700 p-6 hover:border-pink-500 transition-colors cursor-pointer"
                onClick={() => setLocation(`/program/${program.slug}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="text-3xl mb-2">{program.icon}</div>
                    <h4 className="text-lg font-bold mb-2">{program.title}</h4>
                    <p className="text-slate-400 text-sm mb-4">{program.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-400" />
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={() => setLocation("/leaderboard")}
            variant="outline"
            className="h-12 text-base gap-2"
          >
            <TrendingUp className="w-5 h-5" />
            الترتيب العام
          </Button>
          <Button
            onClick={() => setLocation("/progress")}
            variant="outline"
            className="h-12 text-base gap-2"
          >
            <Target className="w-5 h-5" />
            تقدمي
          </Button>
          <Button
            onClick={() => setLocation("/achievements")}
            variant="outline"
            className="h-12 text-base gap-2"
          >
            <Award className="w-5 h-5" />
            الإنجازات
          </Button>
        </div>
      </main>
    </div>
  );
}
