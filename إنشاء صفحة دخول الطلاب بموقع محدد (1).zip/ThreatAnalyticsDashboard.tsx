const ThreatAnalyticsDashboard = () => {
  const stats = [
    { label: "إجمالي التهديدات", value: "443", color: "text-red-500" },
    { label: "الحوادث المسجلة", value: "87", color: "text-yellow-500" },
    { label: "مستويات الخطورة", value: "4", color: "text-blue-500" },
    { label: "معدل النجاح", value: "94%", color: "text-green-500" },
  ];

  const threatTypes = [
    { name: "Malware", count: 35, color: "bg-red-500" },
    { name: "Phishing", count: 25, color: "bg-yellow-500" },
    { name: "DDoS", count: 20, color: "bg-green-500" },
    { name: "Ransomware", count: 15, color: "bg-blue-500" },
    { name: "Other", count: 5, color: "bg-purple-500" },
  ];

  const trendData = [
    { month: "Jan", threats: 120 },
    { month: "Feb", threats: 145 },
    { month: "Mar", threats: 132 },
    { month: "Apr", threats: 178 },
    { month: "May", threats: 165 },
    { month: "Jun", threats: 210 },
  ];

  return (
    <div className="min-h-screen bg-black text-white" dir="rtl">
      {/* Navigation */}
      <nav className="border-b border-gray-800 sticky top-0 z-50 bg-black/95">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold">Spirit Platform</div>
          <div className="flex gap-6 items-center text-sm">
            <a href="/" className="hover:text-cyan-400 transition">الرئيسية</a>
            <a href="/programs" className="hover:text-pink-500 transition">🌸 زهرة</a>
            <a href="/programs" className="hover:text-green-400 transition">🌿 غصن</a>
            <a href="/cybersecurity-lesson" className="hover:text-cyan-400 transition">📚 الدروس</a>
            <a href="/videos" className="hover:text-cyan-400 transition">🎥 الفيديوهات</a>
            <a href="/ai-assistant" className="hover:text-cyan-400 transition">🤖 المساعد</a>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-5xl font-bold mb-4">
          <span className="text-cyan-400">لوحة</span> <span className="text-pink-500">التحليلات</span>
        </h1>
        <p className="text-xl text-gray-300 mb-8">تحليل شامل للتهديدات الأمنية والإحصائيات</p>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          {stats.map((stat, idx) => (
            <div key={idx} className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 hover:border-cyan-500 transition">
              <p className="text-gray-400 mb-2">{stat.label}</p>
              <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Threat Types Distribution */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-6 text-cyan-400">توزيع أنواع التهديدات</h2>
          <div className="space-y-4">
            {threatTypes.map((threat, idx) => (
              <div key={idx}>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-300">{threat.name}</span>
                  <span className="text-gray-400">{threat.count}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className={`${threat.color} h-3 rounded-full`}
                    style={{ width: `${threat.count}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trend Chart */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-6 text-green-400">اتجاهات التهديدات الشهرية</h2>
          <div className="flex items-end justify-around h-64 gap-2">
            {trendData.map((data, idx) => {
              const maxValue = Math.max(...trendData.map(d => d.threats));
              const height = (data.threats / maxValue) * 100;
              return (
                <div key={idx} className="flex flex-col items-center gap-2">
                  <div className="flex items-end gap-1">
                    <div 
                      className="w-8 bg-gradient-to-t from-green-500 to-green-400 rounded-t"
                      style={{ height: `${height}%`, minHeight: "20px" }}
                    ></div>
                  </div>
                  <span className="text-xs text-gray-400">{data.month}</span>
                  <span className="text-xs text-gray-300">{data.threats}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Severity Levels */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 text-yellow-400">مستويات الخطورة</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-red-500/20 border border-red-500 rounded">
                <span className="text-red-400 font-bold">حرج</span>
                <span className="text-red-300">45 حادثة</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-yellow-500/20 border border-yellow-500 rounded">
                <span className="text-yellow-400 font-bold">مرتفع</span>
                <span className="text-yellow-300">78 حادثة</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-green-500/20 border border-green-500 rounded">
                <span className="text-green-400 font-bold">متوسط</span>
                <span className="text-green-300">120 حادثة</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-blue-500/20 border border-blue-500 rounded">
                <span className="text-blue-400 font-bold">منخفض</span>
                <span className="text-blue-300">200 حادثة</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6 text-purple-400">الإحصائيات الرئيسية</h2>
            <div className="space-y-4">
              <div className="p-4 bg-purple-500/20 border border-purple-500 rounded">
                <p className="text-purple-300 text-sm mb-1">متوسط وقت الاستجابة</p>
                <p className="text-purple-400 text-2xl font-bold">2.5 ساعة</p>
              </div>
              <div className="p-4 bg-indigo-500/20 border border-indigo-500 rounded">
                <p className="text-indigo-300 text-sm mb-1">معدل الكشف</p>
                <p className="text-indigo-400 text-2xl font-bold">96.8%</p>
              </div>
              <div className="p-4 bg-pink-500/20 border border-pink-500 rounded">
                <p className="text-pink-300 text-sm mb-1">الحوادث المحلولة</p>
                <p className="text-pink-400 text-2xl font-bold">89.3%</p>
              </div>
              <div className="p-4 bg-cyan-500/20 border border-cyan-500 rounded">
                <p className="text-cyan-300 text-sm mb-1">الأنظمة المحمية</p>
                <p className="text-cyan-400 text-2xl font-bold">1,247</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-8 text-center text-gray-400">
        <p>&copy; 2026 Spirit Platform. جميع الحقوق محفوظة.</p>
        <p className="text-sm mt-2">Made with Manus</p>
      </footer>
    </div>
  );
};

export default ThreatAnalyticsDashboard;
