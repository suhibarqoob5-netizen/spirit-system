import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ThreatStatisticsChartsProps {
  threatsByType?: Array<{ name: string; value: number; frequency: number }>;
  threatsBySeverity?: { منخفضة: number; متوسطة: number; عالية: number; حرجة: number };
  frequencyTrends?: Array<{ date: string; occurrences: number }>;
  topCountries?: Array<{ country: string; totalAttacks: number | null; criticalCount: number | null }>;
  impactAnalysis?: Array<{ id?: number; name: string; frequency: number; impactScore: number; severity: string | null; category?: string }>;
}

const SEVERITY_COLORS = {
  منخفضة: '#10b981',
  متوسطة: '#f59e0b',
  عالية: '#ef4444',
  حرجة: '#7c3aed',
};

export function ThreatStatisticsCharts({
  threatsByType = [],
  threatsBySeverity = { منخفضة: 0, متوسطة: 0, عالية: 0, حرجة: 0 },
  frequencyTrends = [],
  topCountries = [],
  impactAnalysis = [],
}: ThreatStatisticsChartsProps) {
  // Prepare severity distribution data
  const severityData = useMemo(() => {
    return Object.entries(threatsBySeverity).map(([severity, count]) => ({
      name: severity,
      value: count,
      color: SEVERITY_COLORS[severity as keyof typeof SEVERITY_COLORS],
    }));
  }, [threatsBySeverity]);

  // Prepare threat types data
  const typesData = useMemo(() => {
    return threatsByType
      .sort((a, b) => b.value - a.value)
      .slice(0, 8)
      .map(item => ({
        ...item,
        color: SEVERITY_COLORS[item.frequency > 5 ? 'حرجة' : item.frequency > 3 ? 'عالية' : 'متوسطة'],
      }));
  }, [threatsByType]);

  // Prepare top countries data
  const countriesData = useMemo(() => {
    return topCountries
      .sort((a, b) => (b.totalAttacks || 0) - (a.totalAttacks || 0))
      .slice(0, 10)
      .map(item => ({
        ...item,
        totalAttacks: item.totalAttacks || 0,
        criticalCount: item.criticalCount || 0,
        color: (item.criticalCount || 0) > 5 ? '#7c3aed' : (item.criticalCount || 0) > 2 ? '#ef4444' : '#f59e0b',
      }));
  }, [topCountries]);

  // Prepare impact analysis data for radar chart
  const impactData = useMemo(() => {
    return impactAnalysis
      .sort((a, b) => b.impactScore - a.impactScore)
      .slice(0, 8)
      .map(item => ({
        ...item,
        impactScore: Math.min(item.impactScore, 100),
      }));
  }, [impactAnalysis]);

  return (
    <div className="space-y-6">
      <Tabs defaultValue="severity" className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-5">
          <TabsTrigger value="severity">الخطورة</TabsTrigger>
          <TabsTrigger value="types">الأنواع</TabsTrigger>
          <TabsTrigger value="countries">الدول</TabsTrigger>
          <TabsTrigger value="impact">التأثير</TabsTrigger>
          <TabsTrigger value="trends" className="hidden lg:flex">الاتجاهات</TabsTrigger>
        </TabsList>

        {/* Severity Distribution - Pie Chart */}
        <TabsContent value="severity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">توزيع التهديدات حسب مستوى الخطورة</CardTitle>
              <CardDescription className="text-right">
                عدد التهديدات المكتشفة حسب مستوى الخطورة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={severityData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {severityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value} تهديد`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Threat Types - Bar Chart */}
        <TabsContent value="types" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">أنواع التهديدات الأكثر شيوعاً</CardTitle>
              <CardDescription className="text-right">
                توزيع التهديدات حسب النوع والفئة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={typesData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 200, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={190} />
                    <Tooltip formatter={(value) => `${value} تهديد`} />
                    <Bar dataKey="value" fill="#06b6d4" radius={[0, 8, 8, 0]}>
                      {typesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Top Countries - Bar Chart */}
        <TabsContent value="countries" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">أكثر الدول تعرضاً للهجمات</CardTitle>
              <CardDescription className="text-right">
                توزيع الهجمات السيبرانية حسب الدول
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={countriesData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="country"
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value} هجوم`} />
                    <Legend />
                    <Bar dataKey="totalAttacks" fill="#06b6d4" name="إجمالي الهجمات" radius={[8, 8, 0, 0]}>
                      {countriesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || '#06b6d4'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Impact Analysis - Radar Chart */}
        <TabsContent value="impact" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">تحليل تأثير التهديدات</CardTitle>
              <CardDescription className="text-right">
                تقييم تأثير كل نوع من التهديدات بناءً على التكرار والخطورة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={impactData}>
                    <PolarGrid stroke="#374151" />
                    <PolarAngleAxis dataKey="name" />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} />
                    <Radar
                      name="درجة التأثير"
                      dataKey="impactScore"
                      stroke="#06b6d4"
                      fill="#06b6d4"
                      fillOpacity={0.6}
                    />
                    <Tooltip formatter={(value) => `${typeof value === 'number' ? value.toFixed(1) : value}/100`} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Frequency Trends - Line Chart */}
        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">اتجاهات التهديدات عبر الوقت</CardTitle>
              <CardDescription className="text-right">
                تطور عدد التهديدات المكتشفة يومياً
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={frequencyTrends}
                    margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value} تهديد`} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="occurrences"
                      stroke="#06b6d4"
                      strokeWidth={2}
                      dot={{ fill: '#06b6d4', r: 4 }}
                      activeDot={{ r: 6 }}
                      name="عدد التهديدات"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-right">إجمالي التهديدات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-right">
              {threatsByType.reduce((sum, t) => sum + t.value, 0)}
            </div>
            <p className="text-xs text-muted-foreground text-right mt-1">
              نوع من التهديدات المكتشفة
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-right">التهديدات الحرجة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500 text-right">
              {threatsBySeverity.حرجة}
            </div>
            <p className="text-xs text-muted-foreground text-right mt-1">
              تهديدات بمستوى حرج
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-right">الدول المتأثرة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500 text-right">
              {topCountries.length}
            </div>
            <p className="text-xs text-muted-foreground text-right mt-1">
              دول تحت الهجوم
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-right">أعلى تأثير</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-cyan-500 text-right">
              {impactAnalysis.length > 0 ? impactAnalysis[0].name : 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground text-right mt-1">
              أكثر التهديدات تأثيراً
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
