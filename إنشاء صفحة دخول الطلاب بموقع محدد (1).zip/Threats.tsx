import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Search, Filter } from "lucide-react";

export default function Threats() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSeverity, setSelectedSeverity] = useState<string | null>(null);

  const { data: allThreats = [], isLoading: threatsLoading } = trpc.threats.getAll.useQuery();
  const { data: categories = [] } = trpc.threats.getCategories.useQuery();
  const { data: severityDist = {} } = trpc.threats.getSeverityDistribution.useQuery();

  const filteredThreats = useMemo(() => {
    return allThreats.filter((threat: any) => {
      const matchesSearch = threat.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        threat.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = !selectedCategory || threat.category === selectedCategory;
      const matchesSeverity = !selectedSeverity || threat.severity === selectedSeverity;
      return matchesSearch && matchesCategory && matchesSeverity;
    });
  }, [allThreats, searchTerm, selectedCategory, selectedSeverity]);

  const getSeverityColor = (severity: string | null) => {
    switch (severity) {
      case "منخفضة": return "bg-green-100 text-green-800";
      case "متوسطة": return "bg-yellow-100 text-yellow-800";
      case "عالية": return "bg-orange-100 text-orange-800";
      case "حرجة": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getSeverityIcon = (severity: string | null) => {
    switch (severity) {
      case "حرجة": return "🔴";
      case "عالية": return "🟠";
      case "متوسطة": return "🟡";
      case "منخفضة": return "🟢";
      default: return "⚪";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2 flex items-center gap-3">
            <AlertCircle className="w-8 h-8 text-destructive" />
            التهديدات السيبرانية
          </h1>
          <p className="text-muted-foreground">
            تعرف على أكثر التهديدات السيبرانية شيوعاً وكيفية الحماية منها
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{allThreats.length}</div>
            <div className="text-sm text-muted-foreground">إجمالي التهديدات</div>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{(severityDist as any).حرجة || 0}</div>
            <div className="text-sm text-muted-foreground">تهديدات حرجة</div>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{(severityDist as any).عالية || 0}</div>
            <div className="text-sm text-muted-foreground">تهديدات عالية</div>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{categories.length}</div>
            <div className="text-sm text-muted-foreground">فئات</div>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="ابحث عن التهديدات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="flex items-center gap-2"
            >
              <Filter className="w-4 h-4" />
              جميع الفئات
            </Button>
            {categories.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedSeverity === null ? "default" : "outline"}
              onClick={() => setSelectedSeverity(null)}
            >
              جميع المستويات
            </Button>
            {["منخفضة", "متوسطة", "عالية", "حرجة"].map(severity => (
              <Button
                key={severity}
                variant={selectedSeverity === severity ? "default" : "outline"}
                onClick={() => setSelectedSeverity(severity)}
              >
                {getSeverityIcon(severity)} {severity}
              </Button>
            ))}
          </div>
        </div>

        {/* Threats List */}
        {threatsLoading ? (
          <div className="text-center py-12">جاري التحميل...</div>
        ) : filteredThreats.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            لم يتم العثور على تهديدات تطابق معايير البحث
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredThreats.map(threat => (
              <Card key={threat.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-foreground flex items-center gap-2">
                      <span>{getSeverityIcon(threat.severity)}</span>
                      {threat.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">{threat.category}</p>
                  </div>
                  <Badge className={getSeverityColor(threat.severity)}>
                    {threat.severity}
                  </Badge>
                </div>

                <p className="text-foreground mb-4">{threat.description}</p>

                {threat.mitigation && (
                  <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg mb-4">
                    <h4 className="font-semibold text-green-900 dark:text-green-100 mb-2">
                      🛡️ كيفية الحماية:
                    </h4>
                    <p className="text-green-800 dark:text-green-200 text-sm">{threat.mitigation}</p>
                  </div>
                )}

                {threat.examples && Array.isArray(threat.examples) && threat.examples.length > 0 ? (
                  <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                      📌 أمثلة:
                    </h4>
                    <ul className="text-blue-800 dark:text-blue-200 text-sm space-y-1">
                      {((threat.examples as unknown) as string[])?.map((example: string, idx: number) => (
                        <li key={idx}>• {example}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                <div className="mt-4 flex justify-between items-center text-sm text-muted-foreground">
                  <span>التكرار: {threat.frequency} حالة</span>
                  <span>آخر تحديث: اليوم</span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
