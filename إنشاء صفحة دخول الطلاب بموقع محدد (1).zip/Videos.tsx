import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Play, Clock, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Videos() {
  const [selectedLessonId, setSelectedLessonId] = useState<number>(1);
  const [selectedVideoId, setSelectedVideoId] = useState<number | null>(null);

  // Fetch videos for selected lesson
  const { data: videos = [], isLoading: videosLoading } =
    trpc.academic.videos.byLesson.useQuery(selectedLessonId);

  // Lessons list
  const lessons = [
    { id: 1, title: "مقدمة في الأمن السيبراني" },
    { id: 2, title: "كلمات المرور القوية" },
    { id: 3, title: "التصيد الإلكتروني" },
    { id: 4, title: "الشبكات الآمنة" },
    { id: 5, title: "الحماية من البرامج الضارة" },
  ];

  const selectedLesson = lessons.find((l) => l.id === selectedLessonId);
  const selectedVideo = videos.find((v) => v.id === selectedVideoId) || videos[0];

  // Format duration
  const formatDuration = (seconds: number | null | undefined) => {
    if (!seconds) return "غير محدد";
    const minutes = Math.floor(seconds / 60);
    return `${minutes} دقيقة`;
  };

  // Get video URL based on type
  const getVideoUrl = (video: any) => {
    if (video.type === "youtube") {
      // Extract YouTube video ID from URL
      const youtubeRegex =
        /(?:youtube\.com\/watch\?v=|youtu\.be\/)([^\&\?\/\r\n]+)/;
      const match = video.url.match(youtubeRegex);
      const videoId = match ? match[1] : "";
      return `https://www.youtube.com/embed/${videoId}`;
    }
    return video.url;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-600 to-cyan-600 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Play className="h-8 w-8" />
            <h1 className="text-4xl font-bold">📺 مكتبة الفيديوهات</h1>
          </div>
          <p className="text-pink-100">
            شاهد دروسنا التعليمية حول الأمان الرقمي
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Lessons Sidebar */}
          <div className="lg:col-span-1">
            <h3 className="text-xl font-bold mb-4">الدروس</h3>
            <div className="space-y-2">
              {lessons.map((lesson) => (
                <button
                  key={lesson.id}
                  onClick={() => {
                    setSelectedLessonId(lesson.id);
                    setSelectedVideoId(null);
                  }}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    selectedLessonId === lesson.id
                      ? "bg-pink-600 border-2 border-pink-400"
                      : "bg-slate-700 hover:bg-slate-600 border border-slate-600"
                  }`}
                >
                  <p className="font-semibold text-sm truncate">
                    {lesson.title}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-300">
                    <Play className="h-3 w-3" />
                    <span>
                      {videos.filter((v) => v.lessonId === lesson.id).length}{" "}
                      فيديو
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Video Player */}
            {selectedVideo ? (
              <Card className="bg-slate-800 border-slate-700 overflow-hidden">
                <div className="aspect-video bg-black relative">
                  {selectedVideo.type === "youtube" ? (
                    <iframe
                      width="100%"
                      height="100%"
                      src={getVideoUrl(selectedVideo)}
                      title={selectedVideo.title}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <video
                      width="100%"
                      height="100%"
                      controls
                      src={selectedVideo.url}
                    >
                      متصفحك لا يدعم تشغيل الفيديو
                    </video>
                  )}
                </div>
                <div className="p-6">
                  <h2 className="text-2xl font-bold mb-2">
                    {selectedVideo.title}
                  </h2>
                  <div className="flex items-center gap-4 text-sm text-gray-400 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{formatDuration(selectedVideo.duration)}</span>
                    </div>
                  </div>
                  {selectedVideo.thumbnail && (
                    <p className="text-gray-300">{selectedVideo.thumbnail}</p>
                  )}
                </div>
              </Card>
            ) : videosLoading ? (
              <Card className="bg-slate-800 border-slate-700 p-8 text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                <p className="text-gray-400">جاري تحميل الفيديوهات...</p>
              </Card>
            ) : (
              <Card className="bg-slate-800 border-slate-700 p-8 text-center">
                <p className="text-gray-400">لا توجد فيديوهات لهذا الدرس حتى الآن</p>
              </Card>
            )}

            {/* Videos List */}
            <div>
              <h3 className="text-xl font-bold mb-4">
                الفيديوهات (
                {videos.filter((v) => v.lessonId === selectedLessonId).length})
              </h3>

              {videosLoading ? (
                <Card className="bg-slate-800 border-slate-700 p-6 text-center">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
                  <p className="text-gray-400">جاري تحميل الفيديوهات...</p>
                </Card>
              ) : videos.filter((v) => v.lessonId === selectedLessonId).length ===
                0 ? (
                <Card className="bg-slate-800 border-slate-700 p-6 text-center">
                  <p className="text-gray-400">لا توجد فيديوهات حتى الآن</p>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {videos
                    .filter((v) => v.lessonId === selectedLessonId)
                    .map((video) => (
                      <button
                        key={video.id}
                        onClick={() => setSelectedVideoId(video.id)}
                        className={`text-left transition-all rounded-lg overflow-hidden ${
                          selectedVideoId === video.id
                            ? "ring-2 ring-pink-500"
                            : ""
                        }`}
                      >
                        <Card
                          className={`bg-slate-700 border-slate-600 hover:bg-slate-600 transition-colors ${
                            selectedVideoId === video.id
                              ? "bg-slate-600"
                              : ""
                          }`}
                        >
                          <div className="aspect-video bg-slate-800 relative flex items-center justify-center">
                            <Play className="h-12 w-12 text-pink-400 opacity-70" />
                          </div>
                          <div className="p-4">
                            <h4 className="font-semibold text-sm mb-2 line-clamp-2">
                              {video.title}
                            </h4>
                            <div className="flex items-center gap-2 text-xs text-gray-400">
                              <Clock className="h-3 w-3" />
                              <span>{formatDuration(video.duration)}</span>
                            </div>
                          </div>
                        </Card>
                      </button>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
