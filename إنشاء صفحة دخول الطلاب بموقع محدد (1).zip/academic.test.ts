import { describe, it, expect } from "vitest";
import * as db from "./db";

describe("Academic API", () => {
  describe("Programs", () => {
    it("should return all programs", async () => {
      const programs = await db.getAllPrograms();
      expect(Array.isArray(programs)).toBe(true);
    });

    it("should return program by ID", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const program = await db.getProgramById(programs[0].id);
        expect(program).toBeDefined();
        expect(program?.id).toBe(programs[0].id);
      }
    });

    it("should return program by slug", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const program = await db.getProgramBySlug(programs[0].slug);
        expect(program).toBeDefined();
        expect(program?.slug).toBe(programs[0].slug);
      }
    });
  });

  describe("Levels", () => {
    it("should return levels by program", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        expect(Array.isArray(levels)).toBe(true);
      }
    });

    it("should return level by ID", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const level = await db.getLevelById(levels[0].id);
          expect(level).toBeDefined();
          expect(level?.id).toBe(levels[0].id);
        }
      }
    });
  });

  describe("Courses", () => {
    it("should return courses by level", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          expect(Array.isArray(courses)).toBe(true);
        }
      }
    });

    it("should return course by ID", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const course = await db.getCourseById(courses[0].id);
            expect(course).toBeDefined();
            expect(course?.id).toBe(courses[0].id);
          }
        }
      }
    });

    it("should return course by slug", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const course = await db.getCourseBySlug(courses[0].slug);
            expect(course).toBeDefined();
            expect(course?.slug).toBe(courses[0].slug);
          }
        }
      }
    });
  });

  describe("Lessons", () => {
    it("should return lessons by course", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const lessons = await db.getLessonsByCourse(courses[0].id);
            expect(Array.isArray(lessons)).toBe(true);
          }
        }
      }
    });

    it("should return lesson by ID", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const lessons = await db.getLessonsByCourse(courses[0].id);
            if (lessons.length > 0) {
              const lesson = await db.getLessonById(lessons[0].id);
              expect(lesson).toBeDefined();
              expect(lesson?.id).toBe(lessons[0].id);
            }
          }
        }
      }
    });

    it("should return lesson by slug", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const lessons = await db.getLessonsByCourse(courses[0].id);
            if (lessons.length > 0) {
              const lesson = await db.getLessonBySlug(lessons[0].slug);
              expect(lesson).toBeDefined();
              expect(lesson?.slug).toBe(lessons[0].slug);
            }
          }
        }
      }
    });
  });

  describe("Data Validation", () => {
    it("program should have required fields", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const program = programs[0];
        expect(program).toHaveProperty("id");
        expect(program).toHaveProperty("title");
        expect(program).toHaveProperty("slug");
        expect(program).toHaveProperty("description");
      }
    });

    it("level should have required fields", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const level = levels[0];
          expect(level).toHaveProperty("id");
          expect(level).toHaveProperty("title");
          expect(level).toHaveProperty("programId");
        }
      }
    });

    it("course should have required fields", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const course = courses[0];
            expect(course).toHaveProperty("id");
            expect(course).toHaveProperty("title");
            expect(course).toHaveProperty("slug");
            expect(course).toHaveProperty("levelId");
          }
        }
      }
    });

    it("lesson should have required fields", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const lessons = await db.getLessonsByCourse(courses[0].id);
            if (lessons.length > 0) {
              const lesson = lessons[0];
              expect(lesson).toHaveProperty("id");
              expect(lesson).toHaveProperty("title");
              expect(lesson).toHaveProperty("slug");
              expect(lesson).toHaveProperty("courseId");
            }
          }
        }
      }
    });
  });

  describe("Hierarchy Integrity", () => {
    it("levels should belong to their program", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const program = programs[0];
        const levels = await db.getLevelsByProgram(program.id);
        levels.forEach((level: any) => {
          expect(level.programId).toBe(program.id);
        });
      }
    });

    it("courses should belong to their level", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const level = levels[0];
          const courses = await db.getCoursesByLevel(level.id);
          courses.forEach((course: any) => {
            expect(course.levelId).toBe(level.id);
          });
        }
      }
    });

    it("lessons should belong to their course", async () => {
      const programs = await db.getAllPrograms();
      if (programs.length > 0) {
        const levels = await db.getLevelsByProgram(programs[0].id);
        if (levels.length > 0) {
          const courses = await db.getCoursesByLevel(levels[0].id);
          if (courses.length > 0) {
            const course = courses[0];
            const lessons = await db.getLessonsByCourse(course.id);
            lessons.forEach((lesson: any) => {
              expect(lesson.courseId).toBe(course.id);
            });
          }
        }
      }
    });
  });
});
