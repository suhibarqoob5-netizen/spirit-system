import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import * as db from "../db";
import {
  getAllPrograms,
  getProgramById,
  getProgramBySlug,
  getLevelsByProgram,
  getLevelById,
  getCoursesByLevel,
  getCourseBySlug,
  getCourseById,
  getLessonsByCourse,
  getAllLevels,
  getAllCourses,
  createProgram,
  createLevel,
  createCourse,
  createLesson,
  updateProgram,
  updateLevel,
  updateCourse,
} from "../db";

export const academicRouter = router({
  // Concepts
  concepts: router({
    list: publicProcedure.query(async () => {
      return await db.getAllConcepts();
    }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await db.getConceptById(opts.input);
      }),
  }),

  // Badges
  badges: router({
    list: publicProcedure.query(async () => {
      return await db.getAllBadges();
    }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await db.getBadgeById(opts.input);
      }),
  }),

  // Programs
  programs: router({
    list: publicProcedure.query(async () => {
      return await getAllPrograms();
    }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getProgramById(opts.input);
      }),
    bySlug: publicProcedure
      .input(z.string())
      .query(async (opts) => {
        return await getProgramBySlug(opts.input);
      }),
  }),

  // Levels
  levels: router({
    byProgram: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getLevelsByProgram(opts.input);
      }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getLevelById(opts.input);
      }),
  }),

  // Courses
  courses: router({
    byLevel: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getCoursesByLevel(opts.input);
      }),
    bySlug: publicProcedure
      .input(z.string())
      .query(async (opts) => {
        return await getCourseBySlug(opts.input);
      }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getCourseById(opts.input);
      }),
  }),

  // Lessons
  lessons: router({
    byCourse: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await getLessonsByCourse(opts.input);
      }),
    byId: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await db.getLessonById(opts.input);
      }),
  }),

  // Mark lesson complete
  markLessonComplete: protectedProcedure
    .input(z.object({ lessonId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await db.markLessonComplete(ctx.user.id, input.lessonId);
      
      const currentRanking = await db.getUserRanking(ctx.user.id);
      const currentPoints = currentRanking?.totalPoints || 0;
      const newPoints = currentPoints + 10;
      const skillsCount = currentRanking?.skillsCount || 0;
      const commentsCount = currentRanking?.commentsCount || 0;
      await db.updateUserRanking(ctx.user.id, newPoints, skillsCount, commentsCount);
      
      return { success: true };
    }),

  // User Progress
  userProgress: protectedProcedure.query(async ({ ctx }) => {
    return await db.getUserProgress(ctx.user.id);
  }),

  // Videos
  videos: router({
    byLesson: publicProcedure
      .input(z.number())
      .query(async (opts) => {
        return await db.getVideosByLesson(opts.input);
      }),
  }),

  // Mark concept learned (for cybersecurity lesson)
  markConceptLearned: protectedProcedure
    .input(z.object({ conceptId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const conceptToLessonMap: Record<string, number> = {
        'phishing': 1,
        'malware': 2,
        'password': 3,
        'social-engineering': 4,
        'wifi': 5,
      };
      
      const lessonId = conceptToLessonMap[input.conceptId as keyof typeof conceptToLessonMap] || 1;
      
      await db.markLessonComplete(ctx.user.id, lessonId);
      
      const currentRanking = await db.getUserRanking(ctx.user.id);
      const currentPoints = currentRanking?.totalPoints || 0;
      const newPoints = currentPoints + 20;
      const skillsCount = currentRanking?.skillsCount || 0;
      const commentsCount = currentRanking?.commentsCount || 0;
      await db.updateUserRanking(ctx.user.id, newPoints, skillsCount, commentsCount);
      
      return { success: true };
    }),

  // Seed data
  seedData: publicProcedure.mutation(async () => {
    try {
      const allPrograms = await getAllPrograms();
      
      if (allPrograms.length === 0) {
        return { success: false, message: "No programs found" };
      }

      let levelsCreated = 0;
      let coursesCreated = 0;
      let lessonsCreated = 0;

      for (const program of allPrograms) {
        const existingLevels = await getLevelsByProgram(program.id);
        if (existingLevels.length === 0) {
          for (let i = 1; i <= 3; i++) {
            await createLevel({
              programId: program.id,
              title: `المستوى ${i}: ${['الأساسيات', 'الحماية المتقدمة', 'التعامل مع التهديدات'][i - 1]}`,
              description: `مستوى ${i} من برنامج ${program.title}`,
              orderIndex: i,
              isPublished: true,
            });
            levelsCreated++;
          }
        }
      }

      const allLevels = await db.getAllLevels();
      
      for (const level of allLevels) {
        const existingCourses = await getCoursesByLevel(level.id);
        if (existingCourses.length === 0) {
          for (let i = 1; i <= 2; i++) {
            await createCourse({
              levelId: level.id,
              title: `دورة ${i}: ${['حماية البيانات', 'الأمان الرقمي'][i - 1]}`,
              slug: `course-${level.id}-${i}`,
              orderIndex: i,
              isPublished: true,
            });
            coursesCreated++;
          }
        }
      }

      const allCourses = await db.getAllCourses();
      
      for (const course of allCourses) {
        const existingLessons = await getLessonsByCourse(course.id);
        if (existingLessons.length === 0) {
          for (let i = 1; i <= 2; i++) {
            await createLesson({
              courseId: course.id,
              title: `درس ${i}: ${['مقدمة', 'التطبيق العملي'][i - 1]}`,
              slug: `lesson-${course.id}-${i}`,
              stage: 1,
              orderIndex: i,
              isPublished: true,
              difficulty: 'سهل',
            });
            lessonsCreated++;
          }
        }
      }

      return { 
        success: true, 
        message: "Seed data created successfully",
        data: {
          levelsCreated,
          coursesCreated,
          lessonsCreated,
        }
      };
    } catch (error) {
      console.error("Seed error:", error);
      return { success: false, message: error instanceof Error ? error.message : "Unknown error" };
    }
  }),
});
