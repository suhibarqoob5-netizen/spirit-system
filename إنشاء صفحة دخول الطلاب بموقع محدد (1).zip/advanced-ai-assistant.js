// مساعد ذكي متقدم متخصص في التعليم السيبراني

class CyberSecurityAIAssistant {
    constructor() {
        this.learningData = {
            userLevel: 'beginner',
            completedSections: [],
            questionsAsked: [],
            learningPath: 'none'
        };

        this.courseResponses = {
            'دورة': 'مرحباً! 👋 أنت في الدورة الكاملة للأمان السيبراني. لديك مسارين:\n🌸 زهرة البرقوق (للبنات)\n🌿 غصن البرقوق (للشباب)\nأي مسار تفضل؟',
            'زهرة': 'رائع! 🌸 أنتِ في مسار زهرة البرقوق. هذا المسار مخصص لبناء هويتك الرقمية الآمنة والواعية. سنبدأ بـ:\n1. حماية الحسابات\n2. فهم الخداع الرقمي\n3. تعليم الآخرين\nأي قسم تريدين البدء به؟',
            'غصن': 'ممتاز! 🌿 أنت في مسار غصن البرقوق. هذا المسار يركز على بناء عقلية قيادية واعية. سنبدأ بـ:\n1. حماية متقدمة\n2. تحليل التهديدات\n3. قيادة التوعية\nأي قسم تريد البدء به؟',
            'دروس': 'دروسنا تغطي كل شيء! 📚\n• القسم 1: التمهيد والتعريف\n• القسم 2: أمن واتساب\n• القسم 3: كلمات السر\n• القسم 4: الخصوصية\n• القسم 5: الاحتيال\n• القسم 6: أمن الأجهزة\n• القسم 7: مهارات التعليم\n• القسم 8: التدريب العملي\n• القسم 9: التخرج\nأي درس تريد؟',
            'فيديوهات': 'لدينا فيديوهات متخصصة! 🎥\n✓ حماية الحسابات\n✓ كشف الاحتيال\n✓ أمن الهاتف\n✓ كلمات السر القوية\n✓ الخصوصية الرقمية\nأي فيديو تريد مشاهدته؟',
            'طلاب': 'دخول الطلاب! 👨‍🎓\nطلابنا الأربعة:\n1. Yosef Hamamrah (#SP-2026-001)\n2. Istabraq Abu Srhan (#SP-2026-002)\n3. Naheel Fatayergy (#SP-2026-003)\n4. Mai Farrah (#SP-2026-004)\nتريد معلومات عن أحدهم؟',
            'معلمون': 'المعلمون هم قادة التوعية! 👨‍🏫\nالمعلم الجيد يجب أن يكون:\n✓ واعياً بالتهديدات\n✓ قادراً على الشرح البسيط\n✓ مثالاً حياً للأمان\n✓ معداً للأسئلة الصعبة\nتريد نصائح للمعلمين؟',
            'متعلمون': 'المتعلمون هم أساس التغيير! 📖\nالمتعلم الجيد يجب أن يكون:\n✓ فضولياً وحريصاً على التعلم\n✓ مطبقاً لما يتعلمه\n✓ معلماً لمن حوله\n✓ مسؤولاً عن أمانه الرقمي\nكيف يمكنك أن تصبح متعلماً أفضل؟',
            'محاضرات': 'المحاضرات المتخصصة! 🎤\n• محاضرة 1: الوعي الرقمي\n• محاضرة 2: الهجمات اليومية\n• محاضرة 3: الحماية المتقدمة\n• محاضرة 4: قيادة التوعية\nأي محاضرة تريد؟',
            'مكتبة': 'مكتبتنا غنية بالموارد! 📚\n✓ كتب وأدلة\n✓ أوراق بحثية\n✓ حالات دراسية\n✓ أدوات وتطبيقات\nما الموضوع الذي تهتم به؟',
            'طوارئ': 'الطوارئ الرقمية! 🚨\nإذا حدثت مشكلة:\n1. اتصل بنا فوراً\n2. لا تعطِ معلومات إضافية\n3. غيّر كلمة السر\n4. أبلغ المنصة\nما المشكلة التي تواجهها؟',
            'نحن': 'من نحن؟ 🛡️\nنحن منصة Spirit\nمهمتنا: بناء جيل واعٍ رقمياً\nرؤيتنا: مجتمع آمن سيبرانياً\nقيمنا: الوعي والمسؤولية والقيادة\nتريد معرفة المزيد؟',
            'تواصل': 'تواصل معنا! 📞\nنحن هنا لمساعدتك:\n📧 البريد الإلكتروني\n📱 الهاتف\n💬 الدردشة المباشرة\n🌐 وسائل التواصل\nكيف يمكننا مساعدتك؟'
        };

        this.smartTips = [
            '💡 نصيحة: كلمة السر القوية تحتوي على أحرف كبيرة وصغيرة وأرقام ورموز',
            '💡 نصيحة: لا تشارك معلوماتك الشخصية مع غرباء على الإنترنت',
            '💡 نصيحة: تحقق من الروابط قبل النقر عليها',
            '💡 نصيحة: فعّل التحقق بخطوتين على جميع حساباتك',
            '💡 نصيحة: حدّث تطبيقاتك بانتظام',
            '💡 نصيحة: لا تستخدم نفس كلمة السر لأكثر من حساب',
            '💡 نصيحة: تعلم كيف تعلّم الآخرين الأمان الرقمي'
        ];

        this.initializeAssistant();
    }

    initializeAssistant() {
        // إضافة زر المساعد الذكي
        const assistantBtn = document.querySelector('.assistant-btn');
        if (assistantBtn) {
            assistantBtn.addEventListener('click', () => this.toggleAssistant());
        }

        // إضافة رسالة ترحيب
        setTimeout(() => {
            this.addMessage('مرحباً! 👋 أنا مساعدك الذكي في Spirit Platform. كيف يمكنني مساعدتك في رحلتك نحو الأمان السيبراني؟', 'assistant');
        }, 500);
    }

    toggleAssistant() {
        const chat = document.getElementById('assistantChat');
        if (chat) {
            chat.style.display = chat.style.display === 'none' ? 'flex' : 'none';
        }
    }

    addMessage(text, sender = 'user') {
        const messagesContainer = document.getElementById('messages');
        if (!messagesContainer) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        messageDiv.textContent = text;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    processUserInput(input) {
        const lowerInput = input.toLowerCase();

        // البحث عن الكلمات المفتاحية
        for (const [keyword, response] of Object.entries(this.courseResponses)) {
            if (lowerInput.includes(keyword)) {
                return response;
            }
        }

        // إذا لم تطابق أي كلمة مفتاحية
        if (lowerInput.includes('مساعدة') || lowerInput.includes('help')) {
            return 'أنا هنا لمساعدتك! 🤝\nيمكنك أن تسأل عن:\n• الدورة والمسارات\n• الدروس والفيديوهات\n• الطلاب والمعلمين\n• الطوارئ والمشاكل\n• أي شيء عن الأمان السيبراني\nما الذي تريد معرفته؟';
        }

        // رد عام ذكي
        const randomTip = this.smartTips[Math.floor(Math.random() * this.smartTips.length)];
        return `شكراً على سؤالك! 🙏\n${randomTip}\n\nهل تريد معرفة المزيد عن موضوع معين؟`;
    }

    sendMessage() {
        const input = document.getElementById('userInput');
        if (!input || !input.value.trim()) return;

        const userMessage = input.value;
        this.addMessage(userMessage, 'user');

        // محاكاة التأخير
        setTimeout(() => {
            const response = this.processUserInput(userMessage);
            this.addMessage(response, 'assistant');
        }, 500);

        input.value = '';
    }

    // تحليل مستوى التعلم
    analyzeLearningLevel(completedSections) {
        if (completedSections.length === 0) return 'beginner';
        if (completedSections.length < 3) return 'intermediate';
        if (completedSections.length < 6) return 'advanced';
        return 'expert';
    }

    // توصيات ذكية
    getSmartRecommendations() {
        const level = this.learningData.userLevel;
        const recommendations = {
            'beginner': 'ابدأ بالقسم 1: التمهيد والتعريف 🌱',
            'intermediate': 'انتقل إلى أقسام الحماية المتقدمة 📈',
            'advanced': 'ركز على مهارات التعليم والتدريب 👨‍🏫',
            'expert': 'أنت جاهز للمشروع النهائي والتخرج! 🎓'
        };
        return recommendations[level] || 'استمر في التعلم! 💪';
    }
}

// تهيئة المساعد الذكي
let cyberAI;
document.addEventListener('DOMContentLoaded', () => {
    cyberAI = new CyberSecurityAIAssistant();
});

// دالة عامة للإرسال
function sendMessage() {
    if (cyberAI) {
        cyberAI.sendMessage();
    }
}

function toggleChat() {
    if (cyberAI) {
        cyberAI.toggleAssistant();
    }
}
