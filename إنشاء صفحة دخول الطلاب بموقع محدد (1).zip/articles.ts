import { router, publicProcedure, protectedProcedure, adminProcedure } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";

export const articlesRouter = router({
  // Get all articles
  getAll: publicProcedure.query(async () => {
    try {
      const articles = await db.getAllArticles();
      return {
        success: true,
        count: articles.length,
        data: articles,
      };
    } catch (error) {
      console.error("Error fetching articles:", error);
      return {
        success: false,
        count: 0,
        data: [],
        error: "Failed to fetch articles",
      };
    }
  }),

  // Get articles by category
  getByCategory: publicProcedure
    .input(z.object({ category: z.string() }))
    .query(async ({ input }) => {
      try {
        const articles = await db.getArticlesByCategory(input.category);
        return {
          success: true,
          count: articles.length,
          data: articles,
        };
      } catch (error) {
        console.error("Error fetching articles by category:", error);
        return {
          success: false,
          count: 0,
          data: [],
          error: "Failed to fetch articles",
        };
      }
    }),

  // Get articles by level
  getByLevel: publicProcedure
    .input(z.object({ level: z.string() }))
    .query(async ({ input }) => {
      try {
        const articles = await db.getArticlesByLevel(input.level);
        return {
          success: true,
          count: articles.length,
          data: articles,
        };
      } catch (error) {
        console.error("Error fetching articles by level:", error);
        return {
          success: false,
          count: 0,
          data: [],
          error: "Failed to fetch articles",
        };
      }
    }),

  // Get article by ID
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const article = await db.getArticleById(input.id);
        if (article) {
          // Increment views
          await db.incrementArticleViews(input.id);
        }
        return {
          success: true,
          data: article,
        };
      } catch (error) {
        console.error("Error fetching article:", error);
        return {
          success: false,
          data: null,
          error: "Failed to fetch article",
        };
      }
    }),

  // Get article by slug
  getBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      try {
        const article = await db.getArticleBySlug(input.slug);
        if (article) {
          // Increment views
          await db.incrementArticleViews(article.id);
        }
        return {
          success: true,
          data: article,
        };
      } catch (error) {
        console.error("Error fetching article:", error);
        return {
          success: false,
          data: null,
          error: "Failed to fetch article",
        };
      }
    }),

  // Search articles
  search: publicProcedure
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      try {
        const articles = await db.searchArticles(input.query);
        return {
          success: true,
          count: articles.length,
          data: articles,
        };
      } catch (error) {
        console.error("Error searching articles:", error);
        return {
          success: false,
          count: 0,
          data: [],
          error: "Failed to search articles",
        };
      }
    }),

  // Create article (admin only)
  create: adminProcedure
    .input(z.object({
      title: z.string(),
      slug: z.string(),
      content: z.string(),
      summary: z.string().optional(),
      category: z.string(),
      level: z.string().default("مبتدئ"),
      videoUrl: z.string().optional(),
      thumbnail: z.string().optional(),
      author: z.string().optional(),
      readingTime: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        await db.createArticle({
          ...input,
          isPublished: true,
        });
        return {
          success: true,
          message: "Article created successfully",
        };
      } catch (error) {
        console.error("Error creating article:", error);
        return {
          success: false,
          error: "Failed to create article",
        };
      }
    }),

  // Update article (admin only)
  update: adminProcedure
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      content: z.string().optional(),
      summary: z.string().optional(),
      category: z.string().optional(),
      level: z.string().optional(),
      videoUrl: z.string().optional(),
      thumbnail: z.string().optional(),
      isPublished: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        const { id, ...updateData } = input;
        await db.updateArticle(id, updateData);
        return {
          success: true,
          message: "Article updated successfully",
        };
      } catch (error) {
        console.error("Error updating article:", error);
        return {
          success: false,
          error: "Failed to update article",
        };
      }
    }),

  // Delete article (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      try {
        await db.deleteArticle(input.id);
        return {
          success: true,
          message: "Article deleted successfully",
        };
      } catch (error) {
        console.error("Error deleting article:", error);
        return {
          success: false,
          error: "Failed to delete article",
        };
      }
    }),
});
