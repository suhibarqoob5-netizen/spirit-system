// مساعد ذكي بسيط للموقع
class SpiritChatbot {
  constructor() {
    this.responses = {
      'دروس': { text: 'الدروس متاحة في صفحة الدروس! تحتوي على 4 مراحل تعليمية مختلفة.', link: 'lessons.html' },
      'فيديوهات': { text: 'الفيديوهات التعليمية متوفرة في صفحة الفيديوهات!', link: 'videos.html' },
      'طلاب': { text: 'يمكنك الدخول إلى لوحة الطلاب من صفحة دخول الطلاب!', link: 'students.html' },
      'محاضرات': { text: 'المحاضرات متاحة بأطوال مختلفة (15، 30، 45، 60 دقيقة)!', link: 'lectures.html' },
      'طوارئ': { text: 'صفحة الطوارئ الرقمية تساعدك عند الاختراق أو الاحتيال!', link: 'emergency.html' },
      'معلمين': { text: 'مسار المعلم يوفر دليل شامل للتدريس!', link: 'teachers.html' },
      'متعلمين': { text: 'مسار المتعلم يساعدك في بدء رحلة التعلم!', link: 'learners.html' },
      'مكتبة': { text: 'الكتاب والمكتبة تحتوي على موارد تعليمية شاملة!', link: 'library.html' },
      'من نحن': { text: 'تعرف على مشروع Spirit وأهدافه!', link: 'about.html' },
      'تواصل': { text: 'يمكنك التواصل معنا من صفحة تواصل معنا!', link: 'contact.html' },
      'رئيسية': { text: 'العودة إلى الصفحة الرئيسية!', link: 'index.html' }
    };
  }

  processInput(input) {
    const lowerInput = input.toLowerCase().trim();
    
    for (let key in this.responses) {
      if (lowerInput.includes(key)) {
        return this.responses[key];
      }
    }
    
    return {
      text: 'أهلاً! أنا مساعدك الذكي. يمكنك السؤال عن: الدروس، الفيديوهات، الطلاب، المحاضرات، الطوارئ، المعلمين، المتعلمين، المكتبة، من نحن، التواصل',
      link: null
    };
  }

  createChatbotUI() {
    const chatbotHTML = `
      <div id="spirit-chatbot" class="chatbot-container">
        <div class="chatbot-header">
          <h3>مساعد Spirit 🤖</h3>
          <button id="chatbot-close" class="chatbot-close">×</button>
        </div>
        <div id="chatbot-messages" class="chatbot-messages"></div>
        <div class="chatbot-input-area">
          <input type="text" id="chatbot-input" placeholder="اسأل عن أي شيء..." />
          <button id="chatbot-send">إرسال</button>
        </div>
      </div>
      <button id="chatbot-toggle" class="chatbot-toggle">💬 مساعد</button>
    `;
    
    document.body.insertAdjacentHTML('beforeend', chatbotHTML);
    this.attachEventListeners();
  }

  attachEventListeners() {
    const toggle = document.getElementById('chatbot-toggle');
    const close = document.getElementById('chatbot-close');
    const send = document.getElementById('chatbot-send');
    const input = document.getElementById('chatbot-input');
    const container = document.getElementById('spirit-chatbot');

    toggle.addEventListener('click', () => {
      container.classList.toggle('active');
      toggle.style.display = container.classList.contains('active') ? 'none' : 'block';
    });

    close.addEventListener('click', () => {
      container.classList.remove('active');
      toggle.style.display = 'block';
    });

    send.addEventListener('click', () => this.sendMessage());
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
  }

  sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim();
    
    if (!message) return;

    const messagesDiv = document.getElementById('chatbot-messages');
    
    // إضافة رسالة المستخدم
    messagesDiv.innerHTML += `<div class="message user-message">${message}</div>`;
    input.value = '';

    // الحصول على الرد
    const response = this.processInput(message);
    
    // إضافة رد البوت
    let botMessage = `<div class="message bot-message">${response.text}`;
    if (response.link) {
      botMessage += `<br><a href="${response.link}" class="chatbot-link">اذهب إلى الصفحة →</a>`;
    }
    botMessage += '</div>';
    
    messagesDiv.innerHTML += botMessage;
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }
}

// تهيئة البوت عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  const chatbot = new SpiritChatbot();
  chatbot.createChatbotUI();
});
