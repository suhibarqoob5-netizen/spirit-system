import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";

const cybersecurityConcepts = {
  phishing:
    "الاحتيال الإلكتروني هو محاولة خداع المستخدمين للحصول على معلومات حساسة عبر بريد إلكتروني أو موقع وهمي",
  malware:
    "البرامج الضارة هي برامج مصممة للإضرار بالنظام أو سرقة البيانات الشخصية",
  password:
    "أمان كلمات المرور يتطلب استخدام كلمات قوية وتفعيل المصادقة الثنائية",
  "social-engineering":
    "الهندسة الاجتماعية هي استخدام الخداع النفسي للحصول على معلومات حساسة",
  wifi: "شبكات WiFi العامة قد تكون غير آمنة، استخدم VPN عند الاتصال بها",
};

export const cybersecurityRouter = router({
  tutor: publicProcedure
    .input(
      z.object({
        message: z.string(),
        progress: z.object({
          learnedConcepts: z.array(z.string()),
          points: z.number(),
        }),
        currentConcept: z.object({
          id: z.string(),
          title: z.string(),
          description: z.string(),
          risk: z.string(),
          example: z.string(),
          prevention: z.string(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const { message, progress, currentConcept } = input;

      // Build context for the AI
      const context = `
أنت مساعد تعليمي متخصص في الأمن السيبراني. تتحدث باللغة العربية بشكل ودي وتعليمي.

معلومات الطالب:
- المفاهيم المتعلمة: ${progress.learnedConcepts.length}
- النقاط: ${progress.points}

المفهوم الحالي:
- العنوان: ${currentConcept.title}
- الوصف: ${currentConcept.description}
- المخاطر: ${currentConcept.risk}
- مثال: ${currentConcept.example}
- الحماية: ${currentConcept.prevention}

معلومات عن المفاهيم:
${Object.entries(cybersecurityConcepts)
  .map(([key, value]) => `- ${key}: ${value}`)
  .join("\n")}

تعليمات:
1. أجب على أسئلة الطالب بشكل واضح وبسيط
2. استخدم أمثلة واقعية من الحياة اليومية
3. ركز على الحماية والوقاية
4. إذا طلب الطالب تدريب، أعطه سؤال عملي
5. شجع الطالب على التعلم والممارسة
6. كن ودياً وداعماً
      `;

      try {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: context,
            },
            {
              role: "user",
              content: message,
            },
          ],
        });

        const reply =
          response.choices[0]?.message?.content || "عذراً، حدث خطأ في المعالجة";

        return {
          reply: typeof reply === "string" ? reply : JSON.stringify(reply),
          success: true,
        };
      } catch (error) {
        console.error("[Cybersecurity Tutor] Error:", error);
        return {
          reply: "عذراً، حدث خطأ في الاتصال. حاول مرة أخرى.",
          success: false,
        };
      }
    }),

  // Get concepts
  getConcepts: publicProcedure.query(() => {
    return Object.entries(cybersecurityConcepts).map(([key, value]) => ({
      id: key,
      description: value,
    }));
  }),

  // Log interaction
  logInteraction: publicProcedure
    .input(
      z.object({
        userId: z.number().optional(),
        conceptId: z.string(),
        message: z.string(),
        response: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      // This would be logged to the database in a real scenario
      console.log("[Cybersecurity] Interaction logged:", input);
      return { success: true };
    }),
});
