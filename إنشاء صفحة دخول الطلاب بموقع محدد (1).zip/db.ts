import { eq, and, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import * as bcrypt from 'bcryptjs';
import {
  InsertUser,
  users,
  programs,
  levels,
  courses,
  lessons,
  progress,
  tasks,
  taskSubmissions,
  certificates,
  videos,
  quizzes,
  quizAttempts,
  scenarios,
  scenarioAttempts,
  aiInteractions,
  notifications,
  analytics,
  adminLogs,
  comments,
  skills,
  rankings,
  achievements,
  concepts,
  badges,
  cybersecurityNews,
  newsNotifications,
  userNotificationPreferences,
  deviceTokens,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getAllStudents() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(users)
    .where(eq(users.role, "user"))
    .orderBy(desc(users.createdAt));
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllLessons() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(lessons)
    .where(eq(lessons.isPublished, true))
    .orderBy(asc(lessons.stage), asc(lessons.orderIndex));
}

export async function getLessonBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(lessons)
    .where(eq(lessons.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getLessonById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(lessons)
    .where(eq(lessons.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserProgress(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(progress)
    .where(eq(progress.userId, userId));
}

export async function markLessonComplete(userId: number, lessonId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const existing = await db
    .select()
    .from(progress)
    .where(
      and(eq(progress.userId, userId), eq(progress.lessonId, lessonId))
    )
    .limit(1);
  if (existing.length > 0) {
    return await db
      .update(progress)
      .set({
        completed: true,
        completedAt: new Date(),
      })
      .where(
        and(eq(progress.userId, userId), eq(progress.lessonId, lessonId))
      );
  } else {
    return await db.insert(progress).values({
      userId,
      lessonId,
      completed: true,
      completedAt: new Date(),
    });
  }
}

export async function getCompletionPercentage(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const totalLessons = await db.select().from(lessons).where(eq(lessons.isPublished, true));
  const completedLessons = await db
    .select()
    .from(progress)
    .where(
      and(eq(progress.userId, userId), eq(progress.completed, true))
    );
  if (totalLessons.length === 0) return 0;
  return Math.round((completedLessons.length / totalLessons.length) * 100);
}

export async function getTasksByLesson(lessonId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.lessonId, lessonId), eq(tasks.isActive, true)));
}

export async function createTaskSubmission(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(taskSubmissions).values(data);
}

export async function getTaskSubmissions(taskId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(taskSubmissions)
    .where(eq(taskSubmissions.taskId, taskId))
    .orderBy(desc(taskSubmissions.submittedAt));
}

export async function getUserTaskSubmissions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(taskSubmissions)
    .where(eq(taskSubmissions.userId, userId));
}

export async function updateTaskSubmission(
  submissionId: number,
  status: "جديد" | "تمت المراجعة" | "مقبول" | "يحتاج تعديل",
  review?: string
) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .update(taskSubmissions)
    .set({
      status,
      adminReview: review,
      reviewedAt: new Date(),
    })
    .where(eq(taskSubmissions.id, submissionId));
}

export async function getCertificate(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(certificates)
    .where(eq(certificates.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function issueCertificate(
  userId: number,
  track: string,
  lessonsCompleted: number
) {
  const db = await getDb();
  if (!db) return undefined;
  const certificateNumber = `CERT-${Date.now()}-${userId}`;
  const existing = await getCertificate(userId);
  if (existing) {
    return await db
      .update(certificates)
      .set({
        status: "مصدرة",
        issuedAt: new Date(),
        certificateNumber,
        lessonsCompleted,
      })
      .where(eq(certificates.userId, userId));
  } else {
    return await db.insert(certificates).values({
      userId,
      track,
      lessonsCompleted,
      certificateNumber,
      status: "مصدرة",
      issuedAt: new Date(),
    });
  }
}

export async function getVideosByLesson(lessonId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(videos)
    .where(eq(videos.lessonId, lessonId));
}

export async function getQuizzesByLesson(lessonId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(quizzes)
    .where(and(eq(quizzes.lessonId, lessonId), eq(quizzes.isActive, true)));
}

export async function createQuizAttempt(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(quizAttempts).values(data);
}

export async function getUserQuizAttempts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(quizAttempts)
    .where(eq(quizAttempts.userId, userId));
}

export async function getScenariosByLesson(lessonId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(scenarios)
    .where(and(eq(scenarios.lessonId, lessonId), eq(scenarios.isActive, true)));
}

export async function createScenarioAttempt(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(scenarioAttempts).values(data);
}

export async function createAIInteraction(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(aiInteractions).values(data);
}

export async function getUserAIInteractions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(aiInteractions)
    .where(eq(aiInteractions.userId, userId))
    .orderBy(desc(aiInteractions.createdAt));
}

export async function createNotification(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(notifications).values(data);
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function logAnalytics(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(analytics).values(data);
}

export async function getAnalytics(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(analytics)
    .where(eq(analytics.userId, userId));
}

export async function logAdminAction(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(adminLogs).values(data);
}

export async function getAdminLogs(adminId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(adminLogs)
    .where(eq(adminLogs.adminId, adminId))
    .orderBy(desc(adminLogs.createdAt));
}


// ============================================
// ACADEMIC HIERARCHY QUERIES
// ============================================

export async function getAllPrograms() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(programs)
    .where(eq(programs.isPublished, true))
    .orderBy(asc(programs.createdAt));
}

export async function getProgramBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(programs)
    .where(eq(programs.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProgramById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(programs)
    .where(eq(programs.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getLevelsByProgram(programId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(levels)
    .where(and(eq(levels.programId, programId), eq(levels.isPublished, true)))
    .orderBy(asc(levels.orderIndex));
}

export async function getLevelById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(levels)
    .where(eq(levels.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCoursesByLevel(levelId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(courses)
    .where(and(eq(courses.levelId, levelId), eq(courses.isPublished, true)))
    .orderBy(asc(courses.orderIndex));
}

export async function getCourseBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(courses)
    .where(eq(courses.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCourseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(courses)
    .where(eq(courses.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllLevels() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(levels).where(eq(levels.isPublished, true));
}

export async function getAllCourses() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(courses).where(eq(courses.isPublished, true));
}

export async function getLessonsByCourse(courseId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(lessons)
    .where(and(eq(lessons.courseId, courseId), eq(lessons.isPublished, true)))
    .orderBy(asc(lessons.orderIndex));
}

export async function createProgram(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(programs).values(data);
}

export async function createLevel(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(levels).values(data);
}

export async function createCourse(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(courses).values(data);
}

export async function createLesson(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(lessons).values(data);
}

export async function updateProgram(id: number, data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(programs).set(data).where(eq(programs.id, id));
}

export async function updateLevel(id: number, data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(levels).set(data).where(eq(levels.id, id));
}

export async function updateCourse(id: number, data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.update(courses).set(data).where(eq(courses.id, id));
}


// ============================================================================
// COMMENTS FUNCTIONS
// ============================================================================

export async function getCommentsByLesson(lessonId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(comments).where(eq(comments.lessonId, lessonId)).orderBy(desc(comments.createdAt));
}

export async function createComment(userId: number, lessonId: number, text: string, rating: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(comments).values({
    userId,
    lessonId,
    text,
    rating,
  });
  return result;
}

export async function getCommentsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(comments).where(eq(comments.userId, userId)).orderBy(desc(comments.createdAt));
}

// ============================================================================
// SKILLS FUNCTIONS
// ============================================================================

export async function getSkillsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(skills).where(eq(skills.userId, userId)).orderBy(desc(skills.createdAt));
}

export async function createSkill(userId: number, name: string, points: number = 10, level: string = "مبتدئ", lessonId?: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(skills).values({
    userId,
    name,
    points,
    level: level as "مبتدئ" | "متوسط" | "محترف",
    lessonId,
  });
  return result;
}

export async function getSkillsCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(skills).where(eq(skills.userId, userId));
  return result[0]?.count || 0;
}

export async function updateSkillLevel(skillId: number, newLevel: string) {
  const db = await getDb();
  if (!db) return null;
  return db.update(skills).set({ level: newLevel as "مبتدئ" | "متوسط" | "محترف" }).where(eq(skills.id, skillId));
}

// ============================================================================
// RANKINGS FUNCTIONS
// ============================================================================

export async function getLeaderboard(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  // Join rankings with users to get user names
  return db.select({
    id: rankings.id,
    userId: rankings.userId,
    userName: users.name,
    totalPoints: rankings.totalPoints,
    rank: rankings.rank,
    skillsCount: rankings.skillsCount,
    commentsCount: rankings.commentsCount,
  }).from(rankings)
    .innerJoin(users, eq(rankings.userId, users.id))
    .orderBy(desc(rankings.totalPoints))
    .limit(limit);
}

export async function getUserRanking(userId: number) {
  const db = await getDb();
  if (!db) return null;
  return db.select().from(rankings).where(eq(rankings.userId, userId)).limit(1).then(r => r[0]);
}

export async function updateUserRanking(userId: number, totalPoints: number, skillsCount: number, commentsCount: number) {
  const db = await getDb();
  if (!db) return null;
  
  // Check if ranking exists
  const existing = await db.select().from(rankings).where(eq(rankings.userId, userId)).limit(1);
  
  if (existing.length > 0) {
    await db.update(rankings).set({
      totalPoints,
      skillsCount,
      commentsCount,
    }).where(eq(rankings.userId, userId));
  } else {
    await db.insert(rankings).values({
      userId,
      totalPoints,
      skillsCount,
      commentsCount,
    });
  }
  
  // Recalculate all ranks based on totalPoints
  await recalculateRanks();
}

export async function recalculateRanks() {
  const db = await getDb();
  if (!db) return null;
  
  // Get all rankings sorted by points
  const allRankings = await db.select().from(rankings).orderBy(desc(rankings.totalPoints));
  
  // Update rank for each user
  for (let i = 0; i < allRankings.length; i++) {
    await db.update(rankings).set({
      rank: i + 1,
    }).where(eq(rankings.id, allRankings[i].id));
  }
}

export async function recalculateLeaderboard() {
  const db = await getDb();
  if (!db) return null;
  
  // Get all users
  const allUsers = await db.select().from(users);
  
  for (const user of allUsers) {
    // Count skills
    const skillsCount = await getSkillsCount(user.id);
    
    // Count comments
    const commentsCount = await db.select({ count: sql<number>`count(*)` }).from(comments).where(eq(comments.userId, user.id));
    
    // Calculate total points from skills
    const skillsPoints = await db.select({ total: sql<number>`COALESCE(SUM(points), 0)` }).from(skills).where(eq(skills.userId, user.id));
    const totalPoints = (skillsPoints[0]?.total || 0) + (commentsCount[0]?.count || 0) * 5;
    
    // Update ranking
    await updateUserRanking(user.id, totalPoints, skillsCount, commentsCount[0]?.count || 0);
  }
}

// ============================================================================
// ACHIEVEMENTS FUNCTIONS
// ============================================================================

export async function getAchievementsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(achievements).where(eq(achievements.userId, userId)).orderBy(desc(achievements.earnedAt));
}

export async function createAchievement(userId: number, badge: string) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(achievements).values({
    userId,
    badge,
  });
}

export async function checkAndAwardAchievements(userId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Get user stats
  const skillsCount = await getSkillsCount(userId);
  const commentsCount = await db.select({ count: sql<number>`count(*)` }).from(comments).where(eq(comments.userId, userId));
  const ranking = await getUserRanking(userId);
  
  const badges: string[] = [];
  
  // Award badges based on achievements
  if (skillsCount >= 1) badges.push("🎓 أول مهارة");
  if (skillsCount >= 5) badges.push("🌟 5 مهارات");
  if (skillsCount >= 10) badges.push("⭐ 10 مهارات");
  if (commentsCount[0]?.count || 0 >= 1) badges.push("💬 أول تعليق");
  if (ranking?.rank === 1) badges.push("🥇 الأول");
  if (ranking?.rank === 2) badges.push("🥈 الثاني");
  if (ranking?.rank === 3) badges.push("🥉 الثالث");
  
  // Award new badges
  for (const badge of badges) {
    const existing = await db.select().from(achievements).where(and(eq(achievements.userId, userId), eq(achievements.badge, badge))).limit(1);
    if (existing.length === 0) {
      await createAchievement(userId, badge);
    }
  }
}

// ============================================================================
// CONCEPTS FUNCTIONS
// ============================================================================

export async function getAllConcepts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(concepts).orderBy(asc(concepts.orderIndex));
}

export async function getConceptById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(concepts).where(eq(concepts.id, id)).limit(1);
  return result[0] || null;
}

export async function getConceptByConceptId(conceptId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(concepts).where(eq(concepts.conceptId, conceptId)).limit(1);
  return result[0] || null;
}

export async function createConcept(data: {
  conceptId: string;
  title: string;
  description?: string;
  risk?: string;
  example?: string;
  prevention?: string;
  orderIndex?: number;
}) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(concepts).values({
    conceptId: data.conceptId,
    title: data.title,
    description: data.description,
    risk: data.risk,
    example: data.example,
    prevention: data.prevention,
    orderIndex: data.orderIndex || 0,
  });
}

// ============================================================================
// BADGES FUNCTIONS
// ============================================================================

export async function getAllBadges() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(badges).orderBy(asc(badges.orderIndex));
}

export async function getBadgeById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(badges).where(eq(badges.id, id)).limit(1);
  return result[0] || null;
}

export async function getBadgeByBadgeId(badgeId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(badges).where(eq(badges.badgeId, badgeId)).limit(1);
  return result[0] || null;
}

export async function createBadge(data: {
  badgeId: string;
  name: string;
  description?: string;
  icon?: string;
  orderIndex?: number;
}) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(badges).values({
    badgeId: data.badgeId,
    name: data.name,
    description: data.description,
    icon: data.icon,
    orderIndex: data.orderIndex || 0,
  });
}


// ============================================
// CYBERSECURITY NEWS QUERIES
// ============================================

export async function getLatestNews(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(cybersecurityNews)
    .where(eq(cybersecurityNews.isPublished, true))
    .orderBy(desc(cybersecurityNews.publishedAt))
    .limit(limit);
}

export async function getNewsByCategory(category: string, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(cybersecurityNews)
    .where(
      and(
        eq(cybersecurityNews.category, category as any),
        eq(cybersecurityNews.isPublished, true)
      )
    )
    .orderBy(desc(cybersecurityNews.publishedAt))
    .limit(limit);
}

export async function searchNews(query: string) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(cybersecurityNews)
    .where(
      and(
        sql`(title LIKE ${`%${query}%`} OR content LIKE ${`%${query}%`})`,
        eq(cybersecurityNews.isPublished, true)
      )
    )
    .orderBy(desc(cybersecurityNews.publishedAt));
}

export async function createNews(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(cybersecurityNews).values(data);
}

export async function updateNews(id: number, data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .update(cybersecurityNews)
    .set(data)
    .where(eq(cybersecurityNews.id, id));
}

export async function deleteNews(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .delete(cybersecurityNews)
    .where(eq(cybersecurityNews.id, id));
}

export async function getNewsById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(cybersecurityNews)
    .where(eq(cybersecurityNews.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getNewsBySeverity(severity: string, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(cybersecurityNews)
    .where(
      and(
        eq(cybersecurityNews.severity, severity as any),
        eq(cybersecurityNews.isPublished, true)
      )
    )
    .orderBy(desc(cybersecurityNews.publishedAt))
    .limit(limit);
}


// ============================================
// NEWS NOTIFICATIONS QUERIES
// ============================================

export async function getUnreadNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(newsNotifications)
    .where(
      and(
        eq(newsNotifications.userId, userId),
        eq(newsNotifications.isRead, false)
      )
    )
    .orderBy(desc(newsNotifications.createdAt));
}

export async function getAllNotifications(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(newsNotifications)
    .where(eq(newsNotifications.userId, userId))
    .orderBy(desc(newsNotifications.createdAt))
    .limit(limit);
}

export async function getUnreadCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql`COUNT(*)` })
    .from(newsNotifications)
    .where(
      and(
        eq(newsNotifications.userId, userId),
        eq(newsNotifications.isRead, false)
      )
    );
  return result[0]?.count || 0;
}

export async function createNewsNotification(data: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(newsNotifications).values(data);
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .update(newsNotifications)
    .set({
      isRead: true,
      readAt: new Date(),
    })
    .where(eq(newsNotifications.id, notificationId));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .update(newsNotifications)
    .set({
      isRead: true,
      readAt: new Date(),
    })
    .where(
      and(
        eq(newsNotifications.userId, userId),
        eq(newsNotifications.isRead, false)
      )
    );
}

export async function deleteNotification(notificationId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .delete(newsNotifications)
    .where(eq(newsNotifications.id, notificationId));
}

export async function deleteAllNotifications(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .delete(newsNotifications)
    .where(eq(newsNotifications.userId, userId));
}

// ============================================
// USER NOTIFICATION PREFERENCES QUERIES
// ============================================

export async function getUserNotificationPreferences(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(userNotificationPreferences)
    .where(eq(userNotificationPreferences.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createUserNotificationPreferences(userId: number, data?: any) {
  const db = await getDb();
  if (!db) return undefined;
  return await db.insert(userNotificationPreferences).values({
    userId,
    enableNotifications: true,
    enableCritical: true,
    enableHigh: true,
    enableMedium: false,
    enableLow: false,
    enableSound: true,
    categories: JSON.stringify(["تهديدات", "تحديثات"]),
    ...data,
  });
}

export async function updateUserNotificationPreferences(userId: number, data: any) {
  const db = await getDb();
  if (!db) return undefined;
  const existing = await getUserNotificationPreferences(userId);
  if (existing) {
    return await db
      .update(userNotificationPreferences)
      .set(data)
      .where(eq(userNotificationPreferences.userId, userId));
  } else {
    return await createUserNotificationPreferences(userId, data);
  }
}

export async function shouldSendNotification(userId: number, severity: string, category: string) {
  const db = await getDb();
  if (!db) return false;
  
  const prefs = await getUserNotificationPreferences(userId);
  if (!prefs || !prefs.enableNotifications) return false;

  // Check severity level
  if (severity === "حرجة" && !prefs.enableCritical) return false;
  if (severity === "عالية" && !prefs.enableHigh) return false;
  if (severity === "متوسطة" && !prefs.enableMedium) return false;
  if (severity === "منخفضة" && !prefs.enableLow) return false;

  // Check category preference
  const categories = typeof prefs.categories === "string" 
    ? JSON.parse(prefs.categories) 
    : prefs.categories;
  if (Array.isArray(categories) && !categories.includes(category)) return false;

  return true;
}

export async function broadcastNotificationToAllUsers(newsId: number, title: string, message: string, type: string, severity: string, category: string) {
  const db = await getDb();
  if (!db) return undefined;

  // Get all users
  const allUsers = await db.select({ id: users.id }).from(users);
  
  // Send notification to users based on their preferences
  for (const user of allUsers) {
    const shouldSend = await shouldSendNotification(user.id, severity, category);
    if (shouldSend) {
      await createNewsNotification({
        userId: user.id,
        newsId,
        type,
        title,
        message,
      });
    }
  }
}


// ============================================
// DEVICE TOKENS QUERIES (FCM Push Notifications)
// ============================================

export async function registerDeviceToken(userId: number, fcmToken: string, deviceName?: string, userAgent?: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  // Check if token already exists
  const existing = await db
    .select()
    .from(deviceTokens)
    .where(eq(deviceTokens.fcmToken, fcmToken))
    .limit(1);

  if (existing.length > 0) {
    // Update existing token
    return await db
      .update(deviceTokens)
      .set({
        userId,
        isActive: true,
        lastUsedAt: new Date(),
      })
      .where(eq(deviceTokens.fcmToken, fcmToken));
  } else {
    // Insert new token
    return await db.insert(deviceTokens).values({
      userId,
      fcmToken,
      deviceName,
      userAgent,
      isActive: true,
    });
  }
}

export async function getUserDeviceTokens(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(deviceTokens)
    .where(
      and(
        eq(deviceTokens.userId, userId),
        eq(deviceTokens.isActive, true)
      )
    );
}

export async function getAllActiveDeviceTokens() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(deviceTokens)
    .where(eq(deviceTokens.isActive, true));
}

export async function deactivateDeviceToken(fcmToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .update(deviceTokens)
    .set({ isActive: false })
    .where(eq(deviceTokens.fcmToken, fcmToken));
}

export async function deleteDeviceToken(fcmToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .delete(deviceTokens)
    .where(eq(deviceTokens.fcmToken, fcmToken));
}

export async function deleteUserDeviceTokens(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return await db
    .delete(deviceTokens)
    .where(eq(deviceTokens.userId, userId));
}

export async function getDeviceTokensByUserPreferences(severity: string, category: string) {
  const db = await getDb();
  if (!db) return [];

  // Get all users who should receive this notification based on their preferences
  const eligibleUsers = await db
    .select({ userId: userNotificationPreferences.userId })
    .from(userNotificationPreferences)
    .where(
      and(
        eq(userNotificationPreferences.enableNotifications, true),
        severity === "حرجة" ? eq(userNotificationPreferences.enableCritical, true) :
        severity === "عالية" ? eq(userNotificationPreferences.enableHigh, true) :
        eq(userNotificationPreferences.enableMedium, true)
      )
    );

  if (eligibleUsers.length === 0) return [];

  // Get device tokens for these users
  const userIds = eligibleUsers.map(u => u.userId);
  // Fetch all active tokens and filter in memory
  const allTokens = await db
    .select()
    .from(deviceTokens)
    .where(eq(deviceTokens.isActive, true));
  
  return allTokens.filter(token => userIds.includes(token.userId));
}


// Authentication functions
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createUser(data: {
  name?: string;
  email: string;
  passwordHash: string;
  loginMethod: string;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(users).values({
    name: data.name,
    email: data.email,
    passwordHash: data.passwordHash,
    loginMethod: data.loginMethod,
    openId: `email-${data.email}`,
    role: "user",
    lastSignedIn: new Date(),
  });

  const newUser = await getUserByEmail(data.email);
  if (!newUser) {
    throw new Error("Failed to create user");
  }

  return newUser;
}
