import { describe, it, expect, beforeAll } from "vitest";
import { db } from "./db";
import { trpc } from "./routers";

describe("Demo Data Removal", () => {
  describe("Leaderboard", () => {
    it("should not contain demo/test users", async () => {
      const leaderboard = await db.getLeaderboard();
      
      const demoNames = ["Ahmed", "Test", "User1", "User2", "Demo", "test"];
      const hasDemoData = leaderboard.some((entry) =>
        demoNames.some((name) => entry.userName?.toLowerCase().includes(name.toLowerCase()))
      );
      
      expect(hasDemoData).toBe(false);
    });

    it("should only show real users with actual points", async () => {
      const leaderboard = await db.getLeaderboard();
      
      // All users should have valid names and points > 0
      leaderboard.forEach((entry) => {
        expect(entry.userName).toBeTruthy();
        expect(entry.totalPoints).toBeGreaterThanOrEqual(0);
        expect(entry.userId).toBeGreaterThan(0);
      });
    });

    it("should be empty if no real users exist", async () => {
      const leaderboard = await db.getLeaderboard();
      // This is valid - leaderboard can be empty
      expect(Array.isArray(leaderboard)).toBe(true);
    });
  });

  describe("Comments", () => {
    it("should not contain demo comments", async () => {
      const comments = await db.getCommentsByLesson(1);
      
      const demoTexts = ["test comment", "demo", "ahmed"];
      const hasDemoComments = comments.some((comment) =>
        demoTexts.some((text) => comment.text?.toLowerCase().includes(text.toLowerCase()))
      );
      
      expect(hasDemoComments).toBe(false);
    });

    it("should only show real user comments", async () => {
      const comments = await db.getCommentsByLesson(1);
      
      comments.forEach((comment) => {
        expect(comment.userId).toBeGreaterThan(0);
        expect(comment.text).toBeTruthy();
        expect(comment.text?.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Skills", () => {
    it("should not contain hardcoded demo skills", async () => {
      // Skills should be managed by system, not hardcoded
      const skills = await db.getSkills();
      
      // Verify skills are from DB, not hardcoded
      expect(Array.isArray(skills)).toBe(true);
    });

    it("should only show skills earned by users", async () => {
      // User skills should be linked to actual user achievements
      const userSkills = await db.getUserSkills(1);
      
      userSkills.forEach((skill) => {
        expect(skill.userId).toBeGreaterThan(0);
        expect(skill.skillName).toBeTruthy();
      });
    });
  });

  describe("Database", () => {
    it("should not have demo data in lessons table", async () => {
      const lessons = await db.getLessons();
      
      // All lessons should be real cybersecurity lessons
      lessons.forEach((lesson) => {
        expect(lesson.title).toBeTruthy();
        expect(lesson.slug).toBeTruthy();
        expect(lesson.slug).not.toContain("demo");
        expect(lesson.slug).not.toContain("test");
      });
    });

    it("should not have demo data in users table", async () => {
      const users = await db.getAllUsers();
      
      const demoNames = ["Ahmed", "Test", "User1", "Demo"];
      users.forEach((user) => {
        const hasDemoName = demoNames.some((name) =>
          user.name?.toLowerCase().includes(name.toLowerCase())
        );
        expect(hasDemoName).toBe(false);
      });
    });

    it("should not have demo data in videos table", async () => {
      const videos = await db.getVideos();
      
      videos.forEach((video) => {
        expect(video.title).toBeTruthy();
        expect(video.url).toBeTruthy();
        expect(video.title).not.toContain("demo");
        expect(video.title).not.toContain("test");
      });
    });
  });

  describe("No Hardcoded Demo Names", () => {
    it("should not contain any test user IDs", async () => {
      // Test IDs typically are 1-10 or 999-1000
      // Real users should have IDs from actual registrations
      const rankings = await db.getLeaderboard();
      
      rankings.forEach((entry) => {
        // Verify user ID is reasonable (not a test ID)
        expect(entry.userId).toBeGreaterThan(0);
      });
    });

    it("should not show placeholder data", async () => {
      const leaderboard = await db.getLeaderboard();
      
      const placeholderTexts = ["placeholder", "n/a", "unknown", "test"];
      leaderboard.forEach((entry) => {
        const hasPlaceholder = placeholderTexts.some((text) =>
          entry.userName?.toLowerCase().includes(text)
        );
        expect(hasPlaceholder).toBe(false);
      });
    });
  });
});
