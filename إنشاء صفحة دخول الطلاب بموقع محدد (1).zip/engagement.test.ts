import { describe, it, expect } from "vitest";
import * as db from "./db";

describe("Engagement System", () => {
  describe("Comments", () => {
    it("should create a comment", async () => {
      // This test requires a user and lesson to exist
      // For now, we'll just test the function exists
      expect(typeof db.createComment).toBe("function");
    });

    it("should get comments by lesson", async () => {
      const comments = await db.getCommentsByLesson(1);
      expect(Array.isArray(comments)).toBe(true);
    });

    it("should get comments by user", async () => {
      const comments = await db.getCommentsByUser(1);
      expect(Array.isArray(comments)).toBe(true);
    });
  });

  describe("Skills", () => {
    it("should create a skill", async () => {
      expect(typeof db.createSkill).toBe("function");
    });

    it("should get skills by user", async () => {
      const skills = await db.getSkillsByUser(1);
      expect(Array.isArray(skills)).toBe(true);
    });

    it("should count skills by user", async () => {
      const count = await db.getSkillsCount(1);
      expect(typeof count).toBe("number");
      expect(count >= 0).toBe(true);
    });

    it("should update skill level", async () => {
      expect(typeof db.updateSkillLevel).toBe("function");
    });
  });

  describe("Rankings", () => {
    it("should get leaderboard", async () => {
      const leaderboard = await db.getLeaderboard(10);
      expect(Array.isArray(leaderboard)).toBe(true);
    });

    it("should get user ranking", async () => {
      const ranking = await db.getUserRanking(1);
      if (ranking) {
        expect(ranking).toHaveProperty("userId");
        expect(ranking).toHaveProperty("totalPoints");
      }
    });

    it("should update user ranking", async () => {
      expect(typeof db.updateUserRanking).toBe("function");
    });

    it("should recalculate leaderboard", async () => {
      expect(typeof db.recalculateLeaderboard).toBe("function");
    });
  });

  describe("Achievements", () => {
    it("should get achievements by user", async () => {
      const achievements = await db.getAchievementsByUser(1);
      expect(Array.isArray(achievements)).toBe(true);
    });

    it("should create achievement", async () => {
      expect(typeof db.createAchievement).toBe("function");
    });

    it("should check and award achievements", async () => {
      expect(typeof db.checkAndAwardAchievements).toBe("function");
    });
  });

  describe("Integration", () => {
    it("all engagement functions should be callable", async () => {
      const functions = [
        db.getCommentsByLesson,
        db.createComment,
        db.getCommentsByUser,
        db.getSkillsByUser,
        db.createSkill,
        db.getSkillsCount,
        db.updateSkillLevel,
        db.getLeaderboard,
        db.getUserRanking,
        db.updateUserRanking,
        db.recalculateLeaderboard,
        db.getAchievementsByUser,
        db.createAchievement,
        db.checkAndAwardAchievements,
      ];

      functions.forEach(fn => {
        expect(typeof fn).toBe("function");
      });
    });
  });
});
