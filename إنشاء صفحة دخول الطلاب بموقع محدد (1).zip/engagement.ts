import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import * as db from "../db";

export const engagementRouter = router({
  // ============================================================================
  // COMMENTS ROUTES
  // ============================================================================
  
  comments: router({
    byLesson: publicProcedure
      .input(z.object({ lessonId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCommentsByLesson(input.lessonId);
      }),

    byUser: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getCommentsByUser(ctx.user.id);
      }),

    create: protectedProcedure
      .input(z.object({
        lessonId: z.number(),
        text: z.string().min(1).max(1000),
        rating: z.number().min(1).max(5).default(5),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.createComment(
          ctx.user.id,
          input.lessonId,
          input.text,
          input.rating
        );
        
        // Update user ranking
        const skillsCount = await db.getSkillsCount(ctx.user.id);
        const commentsCount = (await db.getCommentsByUser(ctx.user.id)).length;
        await db.updateUserRanking(ctx.user.id, skillsCount * 10 + commentsCount * 5, skillsCount, commentsCount);
        
        // Check and award achievements
        await db.checkAndAwardAchievements(ctx.user.id);
        
        return result;
      }),
  }),

  // ============================================================================
  // SKILLS ROUTES
  // ============================================================================

  skills: router({
    byUser: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getSkillsByUser(ctx.user.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
        points: z.number().default(10),
        level: z.enum(["مبتدئ", "متوسط", "محترف"]).default("مبتدئ"),
        lessonId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.createSkill(
          ctx.user.id,
          input.name,
          input.points,
          input.level,
          input.lessonId
        );
        
        // Update user ranking
        const skillsCount = await db.getSkillsCount(ctx.user.id);
        const commentsCount = (await db.getCommentsByUser(ctx.user.id)).length;
        const totalPoints = skillsCount * 10 + commentsCount * 5;
        await db.updateUserRanking(ctx.user.id, totalPoints, skillsCount, commentsCount);
        
        // Check and award achievements
        await db.checkAndAwardAchievements(ctx.user.id);
        
        return result;
      }),

    count: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getSkillsCount(ctx.user.id);
      }),
  }),

  // ============================================================================
  // RANKINGS ROUTES
  // ============================================================================

  rankings: router({
    leaderboard: publicProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .query(async ({ input }) => {
        return await db.getLeaderboard(input.limit);
      }),

    userRanking: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getUserRanking(ctx.user.id);
      }),

    addLessonPoints: protectedProcedure
      .input(z.object({ points: z.number().default(20) }))
      .mutation(async ({ ctx, input }) => {
        // Get current ranking
        const currentRanking = await db.getUserRanking(ctx.user.id);
        const currentPoints = currentRanking?.totalPoints || 0;
        const newPoints = currentPoints + input.points;
        
        // Update ranking with new points
        const skillsCount = currentRanking?.skillsCount || 0;
        const commentsCount = currentRanking?.commentsCount || 0;
        
        return await db.updateUserRanking(ctx.user.id, newPoints, skillsCount, commentsCount);
      }),

    recalculate: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Only admins can recalculate leaderboard");
        }
        return await db.recalculateLeaderboard();
      }),
  }),

  // ============================================================================
  // ACHIEVEMENTS ROUTES
  // ============================================================================

  achievements: router({
    byUser: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getAchievementsByUser(ctx.user.id);
      }),

    check: protectedProcedure
      .mutation(async ({ ctx }) => {
        return await db.checkAndAwardAchievements(ctx.user.id);
      }),
  }),
});
