import { initializeApp } from 'firebase/app';
import { getMessaging, onMessage, getToken } from 'firebase/messaging';

// Firebase configuration
// Note: In production, these should come from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyDemoKey",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "spirit-platform.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "spirit-platform",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "spirit-platform.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123456789:web:abcdef123456",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Get messaging instance
export const messaging = getMessaging(app);

/**
 * Request permission and get FCM token
 */
export async function requestNotificationPermission() {
  try {
    // Check if browser supports notifications
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return null;
    }

    // Check if notifications are already enabled
    if (Notification.permission === 'granted') {
      return await getFCMToken();
    }

    // Request permission
    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        return await getFCMToken();
      }
    }

    return null;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return null;
  }
}

/**
 * Get FCM token from Firebase
 */
export async function getFCMToken() {
  try {
    const token = await getToken(messaging, {
      vapidKey: import.meta.env.VITE_FIREBASE_VAPID_KEY || "BDemoVAPIDKey",
    });

    if (token) {
      console.log('FCM Token:', token);
      return token;
    } else {
      console.log('No registration token available');
      return null;
    }
  } catch (error) {
    console.error('Error getting FCM token:', error);
    return null;
  }
}

/**
 * Handle foreground messages
 */
export function setupForegroundMessageHandler(callback: (payload: any) => void) {
  onMessage(messaging, (payload) => {
    console.log('Message received in foreground:', payload);
    callback(payload);

    // Show notification in foreground
    if (payload.notification) {
      const notificationTitle = payload.notification.title || 'إشعار جديد';
      const notificationOptions = {
        body: payload.notification.body || '',
        icon: payload.notification.image || '/favicon.ico',
        badge: '/favicon.ico',
        tag: 'notification',
        requireInteraction: payload.data?.requireInteraction === 'true',
      };

      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then((registration) => {
          registration.showNotification(notificationTitle, notificationOptions);
        });
      }
    }
  });
}

export default app;
