#!/usr/bin/env python3
"""
Generate React component code for adding new sections to educational platforms.
Useful for creating card components with consistent styling and navigation.
"""

import json
import sys
from typing import Optional

def generate_section_card(
    section_name: str,
    emoji: str,
    description: str,
    color_scheme: str = "pink",
    button_text: str = "ادخل الآن",
    route: str = None
) -> str:
    """
    Generate a React Card component for a new platform section.
    
    Args:
        section_name: Arabic name of the section (e.g., "زهرة البرقوق")
        emoji: Emoji to display (e.g., "🌸")
        description: Arabic description text
        color_scheme: Color scheme (pink, cyan, purple, etc.)
        button_text: Button label text
        route: Navigation route (e.g., "/program/plum-blossom-girls")
    
    Returns:
        JSX code for the Card component
    """
    
    color_map = {
        "pink": {
            "gradient": "from-pink-900/30 to-pink-800/20",
            "border": "border-pink-500/30",
            "hover": "hover:border-pink-500",
            "button": "from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700"
        },
        "cyan": {
            "gradient": "from-cyan-900/30 to-cyan-800/20",
            "border": "border-cyan-500/30",
            "hover": "hover:border-cyan-500",
            "button": "from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700"
        },
        "purple": {
            "gradient": "from-purple-900/30 to-purple-800/20",
            "border": "border-purple-500/30",
            "hover": "hover:border-purple-500",
            "button": "from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
        },
        "green": {
            "gradient": "from-green-900/30 to-green-800/20",
            "border": "border-green-500/30",
            "hover": "hover:border-green-500",
            "button": "from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
        },
        "orange": {
            "gradient": "from-orange-900/30 to-orange-800/20",
            "border": "border-orange-500/30",
            "hover": "hover:border-orange-500",
            "button": "from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
        }
    }
    
    colors = color_map.get(color_scheme, color_map["pink"])
    route_handler = f'onClick={() => setLocation("{route}")}' if route else ""
    
    jsx = f'''<Card className="bg-gradient-to-br {colors['gradient']} {colors['border']} p-8 hover:border-opacity-100 transition cursor-pointer group"
  {route_handler}>
  <div className="text-5xl mb-6">{emoji}</div>
  <h3 className="text-2xl font-bold mb-4">{section_name}</h3>
  <p className="text-slate-300 mb-6">
    {description}
  </p>
  <Button className="w-full bg-gradient-to-r {colors['button']} text-white">
    {button_text}
  </Button>
</Card>'''
    
    return jsx

def generate_nav_button(
    label: str,
    emoji: str,
    route: str
) -> str:
    """Generate a navigation button for the header."""
    return f'<button onClick={() => setLocation("{route}")} className="hover:text-cyan-400 transition bg-none border-none cursor-pointer">{emoji} {label}</button>'

def generate_footer_link(
    label: str,
    emoji: str,
    route: str
) -> str:
    """Generate a footer link button."""
    return f'<button onClick={() => setLocation("{route}")} className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer">{emoji} {label}</button>'

def generate_poetry_section(
    line1: str,
    line2: str
) -> str:
    """Generate a poetry/text section with styling."""
    jsx = f'''<div className="mt-6 text-center">
  <p className="text-slate-400 text-sm">
    {line1}
  </p>
  <p className="text-slate-400 text-sm mt-1">
    {line2}
  </p>
</div>'''
    return jsx

def main():
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "section":
            # Example: python generate_section.py section "عطر الفرموزة" "🌺" "قسم متخصص..." "purple" "استكشف الآن" "/program/perfume-plum"
            if len(sys.argv) >= 8:
                name = sys.argv[2]
                emoji = sys.argv[3]
                desc = sys.argv[4]
                color = sys.argv[5]
                btn_text = sys.argv[6]
                route = sys.argv[7]
                print(generate_section_card(name, emoji, desc, color, btn_text, route))
        
        elif command == "nav":
            if len(sys.argv) >= 5:
                label = sys.argv[2]
                emoji = sys.argv[3]
                route = sys.argv[4]
                print(generate_nav_button(label, emoji, route))
        
        elif command == "footer":
            if len(sys.argv) >= 5:
                label = sys.argv[2]
                emoji = sys.argv[3]
                route = sys.argv[4]
                print(generate_footer_link(label, emoji, route))
        
        elif command == "poetry":
            if len(sys.argv) >= 4:
                line1 = sys.argv[2]
                line2 = sys.argv[3]
                print(generate_poetry_section(line1, line2))
    else:
        print("Usage:")
        print("  python generate_section.py section <name> <emoji> <description> <color> <button_text> <route>")
        print("  python generate_section.py nav <label> <emoji> <route>")
        print("  python generate_section.py footer <label> <emoji> <route>")
        print("  python generate_section.py poetry <line1> <line2>")
        print("\nColors: pink, cyan, purple, green, orange")

if __name__ == "__main__":
    main()
