import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import cors from "cors";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import * as db from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  
  // Configure CORS
  app.use(cors({
    origin: true,
    credentials: true,
  }));
  
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // OAuth callback under /api/oauth/callback
  app.use("/api/oauth", cors({
    origin: true,
    credentials: true,
  }));
  registerOAuthRoutes(app);
  
  // REST API endpoints for testing (BEFORE Vite)
  app.use("/api", cors({
    origin: true,
    credentials: true,
  }));
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const data = await db.getLeaderboard(limit);
      res.json({
        success: true,
        count: data.length,
        data: data,
        timestamp: new Date().toISOString(),
        database: "TiDB Cloud (MySQL-compatible)",
        host: "gateway05.us-east-1.prod.aws.tidbcloud.com:4000",
        databaseName: "dtQdyXjihEM8NNuUeyV7Uu",
        tables: ["users", "rankings", "progress", "concepts", "badges", "achievements"]
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });
  
  // tRPC API
  app.use(
    "/api/trpc",
    cors({
      origin: true,
      credentials: true,
    }),
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  
  // development mode uses Vite, production mode uses static files
  // NOTE: Vite middleware must be last to avoid intercepting API routes
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
