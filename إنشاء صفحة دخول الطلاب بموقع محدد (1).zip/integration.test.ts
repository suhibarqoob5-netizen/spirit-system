import { describe, it, expect, beforeAll, afterAll } from "vitest";
import * as db from "./db";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { users, rankings, progress, concepts, badges, achievements } from "../drizzle/schema";

describe("Integration: Database System", () => {
  let connection: any;
  let testUserId: number;
  const testOpenId = `test-user-${Date.now()}`;

  beforeAll(async () => {
    // Connect to database
    if (!process.env.DATABASE_URL) {
      console.warn("DATABASE_URL not set, skipping integration tests");
      return;
    }
    connection = await mysql.createConnection(process.env.DATABASE_URL);
  });

  afterAll(async () => {
    if (connection) {
      await connection.end();
    }
  });

  it("should create user in database", async () => {
    await db.upsertUser({
      openId: testOpenId,
      name: "Test User",
      email: `test-${Date.now()}@example.com`,
      loginMethod: "oauth",
      role: "user",
    });

    const userDb = drizzle(process.env.DATABASE_URL!);
    const result = await userDb.select().from(users).where(
      (u) => u.openId === testOpenId
    );

    expect(result.length).toBeGreaterThan(0);
    testUserId = result[0].id;
  });

  it("should create ranking entry for user", async () => {
    if (!testUserId) return;

    await db.updateUserRanking(testUserId, 0, 0, 0);

    const userDb = drizzle(process.env.DATABASE_URL!);
    const result = await userDb.select().from(rankings).where(
      (r) => r.userId === testUserId
    );

    expect(result.length).toBeGreaterThan(0);
    expect(result[0].totalPoints).toBe(0);
  });

  it("should add points to user ranking", async () => {
    if (!testUserId) return;

    await db.updateUserRanking(testUserId, 20, 0, 0);

    const ranking = await db.getUserRanking(testUserId);
    expect(ranking?.totalPoints).toBe(20);
  });

  it("should mark lesson as complete", async () => {
    if (!testUserId) return;

    await db.markLessonComplete(testUserId, 1);

    const userProgress = await db.getUserProgress(testUserId);
    const completedLesson = userProgress.find((p: any) => p.lessonId === 1);

    expect(completedLesson).toBeDefined();
    expect(completedLesson.completed).toBe(true);
  });

  it("should retrieve concepts from database", async () => {
    const allConcepts = await db.getAllConcepts();

    expect(allConcepts.length).toBeGreaterThan(0);
    expect(allConcepts[0]).toHaveProperty("conceptId");
    expect(allConcepts[0]).toHaveProperty("title");
  });

  it("should retrieve badges from database", async () => {
    const allBadges = await db.getAllBadges();

    expect(allBadges.length).toBeGreaterThan(0);
    expect(allBadges[0]).toHaveProperty("badgeId");
    expect(allBadges[0]).toHaveProperty("name");
  });

  it("should retrieve user ranking", async () => {
    if (!testUserId) return;

    const ranking = await db.getUserRanking(testUserId);

    expect(ranking).toBeDefined();
    expect(ranking?.userId).toBe(testUserId);
    expect(ranking?.totalPoints).toBeGreaterThanOrEqual(0);
  });

  it("should retrieve leaderboard", async () => {
    const leaderboard = await db.getLeaderboard(100);

    expect(Array.isArray(leaderboard)).toBe(true);
    if (leaderboard.length > 0) {
      expect(leaderboard[0]).toHaveProperty("userName");
      expect(leaderboard[0]).toHaveProperty("totalPoints");
      expect(leaderboard[0]).toHaveProperty("rank");
    }
  });

  it("should create achievement for user", async () => {
    if (!testUserId) return;

    await db.createAchievement(testUserId, "🎓 أول مهارة");

    const userAchievements = await db.getAchievementsByUser(testUserId);

    expect(userAchievements.length).toBeGreaterThan(0);
    expect(userAchievements[0].badge).toBe("🎓 أول مهارة");
  });

  it("should complete full learning flow", async () => {
    if (!testUserId) return;

    // 1. Mark concept as learned
    await db.markLessonComplete(testUserId, 2);

    // 2. Add points
    await db.updateUserRanking(testUserId, 40, 1, 0);

    // 3. Create achievement
    await db.createAchievement(testUserId, "🌟 5 مهارات");

    // 4. Verify all changes persisted
    const progress = await db.getUserProgress(testUserId);
    const ranking = await db.getUserRanking(testUserId);
    const achievements = await db.getAchievementsByUser(testUserId);

    expect(progress.some((p: any) => p.lessonId === 2 && p.completed)).toBe(true);
    expect(ranking?.totalPoints).toBe(40);
    expect(achievements.length).toBeGreaterThan(0);
  });
});
