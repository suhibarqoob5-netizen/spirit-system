// Leaderboard Service - Real data management
// Data is stored in localStorage and synced across the app

export interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  rank: number;
  title: string;
  lastUpdated: number;
}

const STORAGE_KEY = 'spirit_leaderboard';
const USERS_KEY = 'spirit_users';

// Get title based on points
export function getTitleByPoints(points: number): string {
  if (points < 50) return 'مبتدئ';
  if (points < 100) return 'متقدم';
  if (points < 200) return 'محترف';
  return 'أسطورة';
}

// Get color for rank
export function getColorByRank(rank: number): string {
  if (rank === 1) return '#FFD700'; // Gold
  if (rank === 2) return '#C0C0C0'; // Silver
  if (rank === 3) return '#CD7F32'; // Bronze
  return '#6B7280'; // Gray
}

// Initialize leaderboard from localStorage
function getLeaderboard(): LeaderboardEntry[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error reading leaderboard:', error);
    return [];
  }
}

// Save leaderboard to localStorage
function saveLeaderboard(entries: LeaderboardEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch (error) {
    console.error('Error saving leaderboard:', error);
  }
}

// Add or update points for a user
export function addPoints(userId: string, userName: string, points: number): LeaderboardEntry {
  let entries = getLeaderboard();
  
  // Find existing entry
  let entry = entries.find(e => e.id === userId);
  
  if (entry) {
    // Update existing entry
    entry.points += points;
    entry.lastUpdated = Date.now();
  } else {
    // Create new entry
    entry = {
      id: userId,
      name: userName,
      points: points,
      rank: 0,
      title: getTitleByPoints(points),
      lastUpdated: Date.now(),
    };
    entries.push(entry);
  }
  
  // Update title
  entry.title = getTitleByPoints(entry.points);
  
  // Re-sort and update ranks
  entries.sort((a, b) => b.points - a.points);
  entries.forEach((e, index) => {
    e.rank = index + 1;
  });
  
  // Save to localStorage
  saveLeaderboard(entries);
  
  return entry;
}

// Get leaderboard sorted by points
export function getLeaderboardSorted(): LeaderboardEntry[] {
  const entries = getLeaderboard();
  return entries.sort((a, b) => b.points - a.points);
}

// Get user's current position
export function getUserPosition(userId: string): LeaderboardEntry | null {
  const entries = getLeaderboard();
  return entries.find(e => e.id === userId) || null;
}

// Get top N users
export function getTopUsers(limit: number = 10): LeaderboardEntry[] {
  return getLeaderboardSorted().slice(0, limit);
}

// Clear all data (for testing)
export function clearLeaderboard(): void {
  localStorage.removeItem(STORAGE_KEY);
}
