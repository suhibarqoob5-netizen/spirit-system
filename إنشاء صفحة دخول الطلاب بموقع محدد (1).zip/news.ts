import { publicProcedure, protectedProcedure, router, adminProcedure } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";

export const newsRouter = router({
  // Get latest news
  latest: publicProcedure
    .input(z.object({ limit: z.number().default(10) }).optional())
    .query(async ({ input }) => {
      const limit = input?.limit || 10;
      const news = await db.getLatestNews(limit);
      return {
        success: true,
        count: news.length,
        data: news,
      };
    }),

  // Get news by category
  byCategory: publicProcedure
    .input(z.object({ 
      category: z.enum(["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]),
      limit: z.number().default(10)
    }))
    .query(async ({ input }) => {
      const news = await db.getNewsByCategory(input.category, input.limit);
      return {
        success: true,
        count: news.length,
        category: input.category,
        data: news,
      };
    }),

  // Search news
  search: publicProcedure
    .input(z.object({ query: z.string().min(1) }))
    .query(async ({ input }) => {
      const news = await db.searchNews(input.query);
      return {
        success: true,
        count: news.length,
        query: input.query,
        data: news,
      };
    }),

  // Get news by severity
  bySeverity: publicProcedure
    .input(z.object({ 
      severity: z.enum(["منخفضة", "متوسطة", "عالية", "حرجة"]),
      limit: z.number().default(10)
    }))
    .query(async ({ input }) => {
      const news = await db.getNewsBySeverity(input.severity, input.limit);
      return {
        success: true,
        count: news.length,
        severity: input.severity,
        data: news,
      };
    }),

  // Get single news by ID
  byId: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const news = await db.getNewsById(input.id);
      if (!news) {
        throw new Error("الخبر غير موجود");
      }
      return {
        success: true,
        data: news,
      };
    }),

  // Create news (admin only)
  create: adminProcedure
    .input(z.object({
      title: z.string().min(5),
      content: z.string().min(20),
      summary: z.string().optional(),
      source: z.string().optional(),
      sourceUrl: z.string().url().optional(),
      category: z.enum(["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]).default("أخرى"),
      imageUrl: z.string().url().optional(),
      severity: z.enum(["منخفضة", "متوسطة", "عالية", "حرجة"]).default("متوسطة"),
      isPublished: z.boolean().default(true),
    }))
    .mutation(async ({ input }) => {
      const news = await db.createNews({
        ...input,
        publishedAt: new Date(),
      });
      return {
        success: true,
        data: news,
      };
    }),

  // Update news (admin only)
  update: adminProcedure
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      content: z.string().optional(),
      summary: z.string().optional(),
      source: z.string().optional(),
      sourceUrl: z.string().url().optional(),
      category: z.enum(["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]).optional(),
      imageUrl: z.string().url().optional(),
      severity: z.enum(["منخفضة", "متوسطة", "عالية", "حرجة"]).optional(),
      isPublished: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...updateData } = input;
      const news = await db.updateNews(id, updateData);
      return {
        success: true,
        data: news,
      };
    }),

  // Delete news (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteNews(input.id);
      return {
        success: true,
        message: "تم حذف الخبر بنجاح",
      };
    }),
});
