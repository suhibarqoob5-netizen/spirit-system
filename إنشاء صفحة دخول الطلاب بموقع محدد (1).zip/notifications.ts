import { publicProcedure, protectedProcedure, router, adminProcedure } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";

export const notificationsRouter = router({
  // Get unread notifications
  unread: protectedProcedure
    .input(z.object({ limit: z.number().default(10) }).optional())
    .query(async ({ ctx, input }) => {
      const limit = input?.limit || 10;
      const notifications = await db.getUnreadNotifications(ctx.user.id);
      return {
        success: true,
        count: notifications.length,
        data: notifications.slice(0, limit),
      };
    }),

  // Get all notifications
  all: protectedProcedure
    .input(z.object({ limit: z.number().default(50) }).optional())
    .query(async ({ ctx, input }) => {
      const limit = input?.limit || 50;
      const notifications = await db.getAllNotifications(ctx.user.id, limit);
      return {
        success: true,
        count: notifications.length,
        data: notifications,
      };
    }),

  // Get unread count
  unreadCount: protectedProcedure
    .query(async ({ ctx }) => {
      const count = await db.getUnreadCount(ctx.user.id);
      return {
        success: true,
        unreadCount: count,
      };
    }),

  // Mark notification as read
  markAsRead: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input }) => {
      await db.markNotificationAsRead(input.notificationId);
      return {
        success: true,
        message: "تم تحديث الإشعار",
      };
    }),

  // Mark all notifications as read
  markAllAsRead: protectedProcedure
    .mutation(async ({ ctx }) => {
      await db.markAllNotificationsAsRead(ctx.user.id);
      return {
        success: true,
        message: "تم تحديث جميع الإشعارات",
      };
    }),

  // Delete notification
  delete: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteNotification(input.notificationId);
      return {
        success: true,
        message: "تم حذف الإشعار",
      };
    }),

  // Delete all notifications
  deleteAll: protectedProcedure
    .mutation(async ({ ctx }) => {
      await db.deleteAllNotifications(ctx.user.id);
      return {
        success: true,
        message: "تم حذف جميع الإشعارات",
      };
    }),

  // Get user preferences
  preferences: protectedProcedure
    .query(async ({ ctx }) => {
      const prefs = await db.getUserNotificationPreferences(ctx.user.id);
      if (!prefs) {
        // Create default preferences
        await db.createUserNotificationPreferences(ctx.user.id);
        const newPrefs = await db.getUserNotificationPreferences(ctx.user.id);
        return {
          success: true,
          data: newPrefs,
        };
      }
      return {
        success: true,
        data: prefs,
      };
    }),

  // Update user preferences
  updatePreferences: protectedProcedure
    .input(z.object({
      enableNotifications: z.boolean().optional(),
      enableCritical: z.boolean().optional(),
      enableHigh: z.boolean().optional(),
      enableMedium: z.boolean().optional(),
      enableLow: z.boolean().optional(),
      enableSound: z.boolean().optional(),
      categories: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const updateData: any = { ...input };
      if (input.categories) {
        updateData.categories = JSON.stringify(input.categories);
      }
      
      await db.updateUserNotificationPreferences(ctx.user.id, updateData);
      return {
        success: true,
        message: "تم تحديث التفضيلات",
      };
    }),

  // Send alert (admin only)
  sendAlert: adminProcedure
    .input(z.object({
      newsId: z.number(),
      title: z.string(),
      message: z.string(),
      type: z.enum(["breaking", "urgent", "important", "info"]).default("breaking"),
      severity: z.enum(["منخفضة", "متوسطة", "عالية", "حرجة"]),
      category: z.enum(["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]),
    }))
    .mutation(async ({ input }) => {
      await db.broadcastNotificationToAllUsers(
        input.newsId,
        input.title,
        input.message,
        input.type,
        input.severity,
        input.category
      );
      return {
        success: true,
        message: "تم إرسال الإشعار",
      };
    }),
});
