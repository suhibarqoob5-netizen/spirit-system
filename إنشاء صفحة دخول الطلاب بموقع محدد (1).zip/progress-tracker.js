// Progress Tracker - حفظ وتتبع تقدم الطالب باستخدام LocalStorage

class ProgressTracker {
  constructor() {
    this.storageKey = 'spirit-platform-progress';
    this.lessonsStorageKey = 'spirit-platform-lessons';
    this.initializeStorage();
  }

  // تهيئة التخزين
  initializeStorage() {
    if (!localStorage.getItem(this.storageKey)) {
      const initialProgress = {
        track: null,
        completedLessons: [],
        totalLessonsCompleted: 0,
        level: 'مبتدئ',
        lastUpdated: new Date().toISOString()
      };
      localStorage.setItem(this.storageKey, JSON.stringify(initialProgress));
    }
  }

  // الحصول على البيانات الحالية
  getProgress() {
    const data = localStorage.getItem(this.storageKey);
    return data ? JSON.parse(data) : null;
  }

  // تعيين المسار
  setTrack(trackName) {
    const progress = this.getProgress();
    progress.track = trackName;
    progress.lastUpdated = new Date().toISOString();
    localStorage.setItem(this.storageKey, JSON.stringify(progress));
    console.log(`✅ تم اختيار المسار: ${trackName}`);
  }

  // إضافة درس مكتمل
  completeLesson(lessonId, lessonName) {
    const progress = this.getProgress();
    
    if (!progress.completedLessons.includes(lessonId)) {
      progress.completedLessons.push(lessonId);
      progress.totalLessonsCompleted = progress.completedLessons.length;
      
      // تحديث المستوى
      if (progress.totalLessonsCompleted >= 9) {
        progress.level = 'خريج';
      } else if (progress.totalLessonsCompleted >= 6) {
        progress.level = 'متعلم متقدم';
      } else if (progress.totalLessonsCompleted >= 3) {
        progress.level = 'متعلم';
      }
      
      progress.lastUpdated = new Date().toISOString();
      localStorage.setItem(this.storageKey, JSON.stringify(progress));
      console.log(`✅ تم إكمال الدرس: ${lessonName}`);
      return true;
    }
    return false;
  }

  // التحقق من إكمال درس معين
  isLessonCompleted(lessonId) {
    const progress = this.getProgress();
    return progress.completedLessons.includes(lessonId);
  }

  // الحصول على نسبة الإكمال
  getCompletionPercentage() {
    const progress = this.getProgress();
    return Math.round((progress.totalLessonsCompleted / 9) * 100);
  }

  // الحصول على المستوى الحالي
  getCurrentLevel() {
    const progress = this.getProgress();
    return progress.level;
  }

  // إعادة تعيين التقدم
  resetProgress() {
    localStorage.removeItem(this.storageKey);
    this.initializeStorage();
    console.log('✅ تم إعادة تعيين التقدم');
  }

  // تصدير البيانات
  exportProgress() {
    return JSON.stringify(this.getProgress(), null, 2);
  }

  // عرض ملخص التقدم
  displaySummary() {
    const progress = this.getProgress();
    console.log('📊 ملخص التقدم:');
    console.log(`المسار: ${progress.track || 'لم يتم الاختيار'}`);
    console.log(`الدروس المكتملة: ${progress.totalLessonsCompleted} / 9`);
    console.log(`المستوى: ${progress.level}`);
    console.log(`نسبة الإكمال: ${this.getCompletionPercentage()}%`);
    console.log(`آخر تحديث: ${new Date(progress.lastUpdated).toLocaleString('ar-SA')}`);
  }
}

// إنشاء نسخة عامة من الـ Tracker
const progressTracker = new ProgressTracker();

// دالة مساعدة لإضافة زر "إنهاء الدرس" إلى الدروس
function setupLessonCompletion(lessonId, lessonName) {
  const completeBtn = document.querySelector('[data-complete-lesson]');
  if (completeBtn) {
    completeBtn.addEventListener('click', function() {
      progressTracker.completeLesson(lessonId, lessonName);
      alert(`✅ تم حفظ تقدمك في الدرس: ${lessonName}`);
      // إعادة توجيه إلى الدرس التالي أو الدورة
      setTimeout(() => {
        window.location.href = '/course.html';
      }, 1500);
    });
  }
}

// دالة لتحديث لوحة التحكم بالبيانات الحية
function updateDashboard() {
  const progress = progressTracker.getProgress();
  
  // تحديث عدد الدروس المكتملة
  const completedCount = document.querySelector('[data-completed-count]');
  if (completedCount) {
    completedCount.textContent = `${progress.totalLessonsCompleted} / 9`;
  }
  
  // تحديث المستوى
  const levelDisplay = document.querySelector('[data-level-display]');
  if (levelDisplay) {
    levelDisplay.textContent = progress.level;
  }
  
  // تحديث نسبة الإكمال
  const percentageDisplay = document.querySelector('[data-percentage-display]');
  if (percentageDisplay) {
    percentageDisplay.textContent = `${progressTracker.getCompletionPercentage()}%`;
  }
  
  // تحديث المسار
  const trackDisplay = document.querySelector('[data-track-display]');
  if (trackDisplay) {
    trackDisplay.textContent = progress.track || 'لم يتم الاختيار';
  }
}

// تحديث لوحة التحكم عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
  updateDashboard();
});

// تصدير للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ProgressTracker, progressTracker };
}
