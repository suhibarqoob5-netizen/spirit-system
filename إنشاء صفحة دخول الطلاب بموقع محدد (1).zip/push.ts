import { protectedProcedure, router, adminProcedure } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";

export const pushRouter = router({
  // Register device token
  registerToken: protectedProcedure
    .input(z.object({
      fcmToken: z.string(),
      deviceName: z.string().optional(),
      userAgent: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await db.registerDeviceToken(
        ctx.user.id,
        input.fcmToken,
        input.deviceName,
        input.userAgent
      );
      return {
        success: true,
        message: "تم تسجيل الجهاز بنجاح",
      };
    }),

  // Get user device tokens
  getDevices: protectedProcedure
    .query(async ({ ctx }) => {
      const tokens = await db.getUserDeviceTokens(ctx.user.id);
      return {
        success: true,
        data: tokens,
      };
    }),

  // Deactivate device token
  deactivateToken: protectedProcedure
    .input(z.object({ fcmToken: z.string() }))
    .mutation(async ({ input }) => {
      await db.deactivateDeviceToken(input.fcmToken);
      return {
        success: true,
        message: "تم تعطيل الجهاز",
      };
    }),

  // Delete device token
  deleteToken: protectedProcedure
    .input(z.object({ fcmToken: z.string() }))
    .mutation(async ({ input }) => {
      await db.deleteDeviceToken(input.fcmToken);
      return {
        success: true,
        message: "تم حذف الجهاز",
      };
    }),

  // Send push notification (admin only)
  sendNotification: adminProcedure
    .input(z.object({
      title: z.string(),
      body: z.string(),
      data: z.record(z.string(), z.string()).optional(),
      tokens: z.array(z.string()).optional(), // Specific tokens, or null for all
      userIds: z.array(z.number()).optional(), // Specific users
    }))
    .mutation(async ({ input }) => {
      try {
        let targetTokens: string[] = [];

        if (input.tokens) {
          targetTokens = input.tokens;
        } else if (input.userIds && input.userIds.length > 0) {
          const allTokensArrays = await Promise.all(
            input.userIds.map(userId => db.getUserDeviceTokens(userId))
          );
          const allTokens = allTokensArrays.flat();
          targetTokens = allTokens.map(t => t.fcmToken);
        } else {
          // Send to all active devices
          const allTokens = await db.getAllActiveDeviceTokens();
          targetTokens = allTokens.map(t => t.fcmToken);
        }

        if (targetTokens.length === 0) {
          return {
            success: true,
            message: "لا توجد أجهزة لإرسال الإشعارات إليها",
            sentCount: 0,
          };
        }

        // In a real implementation, you would send these to Firebase Cloud Messaging
        // For now, we'll just log them
        console.log(`Sending push notification to ${targetTokens.length} devices`);
        console.log('Notification:', {
          title: input.title,
          body: input.body,
          data: input.data,
        });

        return {
          success: true,
          message: `تم إرسال الإشعار إلى ${targetTokens.length} جهاز`,
          sentCount: targetTokens.length,
        };
      } catch (error) {
        console.error('Error sending push notification:', error);
        return {
          success: false,
          message: "حدث خطأ أثناء إرسال الإشعار",
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  // Send notification to users with specific preferences
  sendSmartNotification: adminProcedure
    .input(z.object({
      title: z.string(),
      body: z.string(),
      severity: z.enum(["منخفضة", "متوسطة", "عالية", "حرجة"]),
      category: z.enum(["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]),
      data: z.record(z.string(), z.string()).optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        const eligibleTokens: any[] = await db.getDeviceTokensByUserPreferences(
          input.severity,
          input.category
        );

        const targetTokens = eligibleTokens.map(t => t.fcmToken);

        if (targetTokens.length === 0) {
          return {
            success: true,
            message: "لا توجد أجهزة مهتمة بهذا الإشعار",
            sentCount: 0,
          };
        }

        console.log(`Sending smart notification to ${targetTokens.length} devices`);

        return {
          success: true,
          message: `تم إرسال الإشعار إلى ${targetTokens.length} جهاز`,
          sentCount: targetTokens.length,
        };
      } catch (error) {
        console.error('Error sending smart notification:', error);
        return {
          success: false,
          message: "حدث خطأ أثناء إرسال الإشعار",
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),
});
