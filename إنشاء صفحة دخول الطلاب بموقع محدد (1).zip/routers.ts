import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { cybersecurityRouter } from "./routers/cybersecurity";
import { academicRouter } from "./routers/academic";
import { engagementRouter } from "./routers/engagement";
import { newsRouter } from "./routers/news";
import { notificationsRouter } from "./routers/notifications";
import { pushRouter } from "./routers/push";
import { seedRouter } from "./routers/seed";
import * as db from "./db";
import { sdk } from "./_core/sdk";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  
  // Public API endpoints for testing
  api: router({
    leaderboard: publicProcedure
      .input(z.object({ limit: z.number().default(100) }).optional().or(z.undefined()))
      .query(async ({ input }) => {
        const limit = input?.limit || 100;
        const leaderboard = await db.getLeaderboard(limit);
        return {
          success: true,
          count: leaderboard.length,
          data: leaderboard,
          timestamp: new Date().toISOString(),
          database: "TiDB Cloud (MySQL-compatible)",
          host: "gateway05.us-east-1.prod.aws.tidbcloud.com:4000",
          databaseName: "dtQdyXjihEM8NNuUeyV7Uu",
          tables: ["users", "rankings", "progress", "concepts", "badges", "achievements"]
        };
      }),
  }),

  system: systemRouter,
  cybersecurity: cybersecurityRouter,
  academic: academicRouter,
  engagement: engagementRouter,
  news: newsRouter,
  notifications: notificationsRouter,
  push: pushRouter,
  seed: seedRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string().min(6) }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserByEmail(input.email);
        if (!user || !user.passwordHash) {
          throw new Error("البريد الإلكتروني أو كلمة المرور غير صحيحة");
        }

        const isPasswordValid = await db.verifyPassword(input.password, user.passwordHash);
        if (!isPasswordValid) {
          throw new Error("البريد الإلكتروني أو كلمة المرور غير صحيحة");
        }

        // Create a session token using SDK
        const sessionToken = await sdk.signSession({
          openId: user.openId || `email-${user.id}`,
          appId: process.env.VITE_APP_ID || "",
          name: user.name || user.email || "",
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: 7 * 24 * 60 * 60 * 1000 });

        return {
          success: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
          },
        };
      }),
    register: publicProcedure
      .input(z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(6) }))
      .mutation(async ({ input, ctx }) => {
        const existingUser = await db.getUserByEmail(input.email);
        if (existingUser) {
          throw new Error("البريد الإلكتروني مسجل بالفعل");
        }

        const passwordHash = await db.hashPassword(input.password);
        const newUser = await db.createUser({
          name: input.name,
          email: input.email,
          passwordHash,
          loginMethod: "email",
        });

        // Create a session token using SDK
        const sessionToken = await sdk.signSession({
          openId: newUser.openId || `email-${newUser.id}`,
          appId: process.env.VITE_APP_ID || "",
          name: newUser.name || newUser.email || "",
        });

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: 7 * 24 * 60 * 60 * 1000 });

        return {
          success: true,
          user: {
            id: newUser.id,
            name: newUser.name,
            email: newUser.email,
          },
        };
      }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
