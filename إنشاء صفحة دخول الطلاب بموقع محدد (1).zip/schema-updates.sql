-- Comments and Feedback System
CREATE TABLE IF NOT EXISTS comments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  lessonId INT NOT NULL,
  text TEXT NOT NULL,
  rating INT CHECK (rating >= 1 AND rating <= 5),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id),
  FOREIGN KEY (lessonId) REFERENCES lessons(id)
);

-- Skills System
CREATE TABLE IF NOT EXISTS skills (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  points INT DEFAULT 10,
  level ENUM('مبتدئ', 'متوسط', 'محترف') DEFAULT 'مبتدئ',
  lessonId INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id),
  FOREIGN KEY (lessonId) REFERENCES lessons(id)
);

-- Rankings System
CREATE TABLE IF NOT EXISTS rankings (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL UNIQUE,
  totalPoints INT DEFAULT 0,
  rank INT,
  skillsCount INT DEFAULT 0,
  commentsCount INT DEFAULT 0,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);

-- Achievements/Badges
CREATE TABLE IF NOT EXISTS achievements (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  badge VARCHAR(255) NOT NULL,
  earnedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);

-- Create indexes for performance
CREATE INDEX idx_comments_userId ON comments(userId);
CREATE INDEX idx_comments_lessonId ON comments(lessonId);
CREATE INDEX idx_skills_userId ON skills(userId);
CREATE INDEX idx_skills_lessonId ON skills(lessonId);
CREATE INDEX idx_rankings_totalPoints ON rankings(totalPoints DESC);
CREATE INDEX idx_achievements_userId ON achievements(userId);
