import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  json,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }).default("oauth"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  track: varchar("track", { length: 50 }),
  level: mysqlEnum("level", ["مبتدئ", "متوسط", "متقدم", "خريج"]).default("مبتدئ"),
  completedLessons: int("completedLessons").default(0),
  completionPercentage: decimal("completionPercentage", { precision: 5, scale: 2 }).default("0"),
  lastActivityAt: timestamp("lastActivityAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Programs table - main learning programs
 */
export const programs = mysqlTable("programs", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  slug: varchar("slug", { length: 100 }).unique().notNull(),
  icon: varchar("icon", { length: 100 }),
  color: varchar("color", { length: 20 }),
  isPublished: boolean("isPublished").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Program = typeof programs.$inferSelect;
export type InsertProgram = typeof programs.$inferInsert;

/**
 * Levels table - learning levels within programs
 */
export const levels = mysqlTable("levels", {
  id: int("id").autoincrement().primaryKey(),
  programId: int("programId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  orderIndex: int("orderIndex").notNull().default(0),
  isPublished: boolean("isPublished").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Level = typeof levels.$inferSelect;
export type InsertLevel = typeof levels.$inferInsert;

/**
 * Courses table - courses within levels
 */
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  levelId: int("levelId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  slug: varchar("slug", { length: 100 }).unique().notNull(),
  orderIndex: int("orderIndex").notNull().default(0),
  isPublished: boolean("isPublished").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

/**
 * Lessons table - stores all cybersecurity lessons
 */
export const lessons = mysqlTable("lessons", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId"),
  slug: varchar("slug", { length: 100 }).unique().notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  stage: int("stage").notNull(),
  orderIndex: int("orderIndex").notNull(),
  videoUrl: varchar("videoUrl", { length: 500 }),
  contentHtml: text("contentHtml"),
  objectives: json("objectives"),
  isPublished: boolean("isPublished").default(false),
  difficulty: mysqlEnum("difficulty", ["سهل", "متوسط", "صعب"]).default("متوسط"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = typeof lessons.$inferInsert;

/**
 * Progress table - tracks student progress through lessons
 */
export const progress = mysqlTable("progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  lessonId: int("lessonId").notNull(),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completedAt"),
  timeSpent: int("timeSpent").default(0),
  score: decimal("score", { precision: 5, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Progress = typeof progress.$inferSelect;
export type InsertProgress = typeof progress.$inferInsert;

/**
 * Tasks table - assignments for each lesson
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  instructions: text("instructions"),
  isActive: boolean("isActive").default(true),
  dueDate: timestamp("dueDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Task submissions table - student submissions for tasks
 */
export const taskSubmissions = mysqlTable("taskSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  userId: int("userId").notNull(),
  reportText: text("reportText").notNull(),
  status: mysqlEnum("status", ["جديد", "تمت المراجعة", "مقبول", "يحتاج تعديل"]).default("جديد"),
  aiInitialReview: text("aiInitialReview"),
  adminReview: text("adminReview"),
  score: decimal("score", { precision: 5, scale: 2 }),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TaskSubmission = typeof taskSubmissions.$inferSelect;
export type InsertTaskSubmission = typeof taskSubmissions.$inferInsert;

/**
 * Certificates table - course completion certificates
 */
export const certificates = mysqlTable("certificates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  certificateNumber: varchar("certificateNumber", { length: 100 }).unique(),
  track: varchar("track", { length: 50 }),
  lessonsCompleted: int("lessonsCompleted"),
  issuedAt: timestamp("issuedAt"),
  status: mysqlEnum("status", ["غير مصدرة", "مصدرة", "ملغاة"]).default("غير مصدرة"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = typeof certificates.$inferInsert;

/**
 * Videos table - video content for lessons
 */
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  url: varchar("url", { length: 500 }).notNull(),
  type: mysqlEnum("type", ["youtube", "local", "external"]).default("youtube"),
  duration: int("duration"),
  thumbnail: varchar("thumbnail", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

/**
 * Quizzes table - AI-generated quizzes for lessons
 */
export const quizzes = mysqlTable("quizzes", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  questions: json("questions"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = typeof quizzes.$inferInsert;

/**
 * Quiz attempts table - student quiz attempts
 */
export const quizAttempts = mysqlTable("quizAttempts", {
  id: int("id").autoincrement().primaryKey(),
  quizId: int("quizId").notNull(),
  userId: int("userId").notNull(),
  answers: json("answers"),
  score: decimal("score", { precision: 5, scale: 2 }),
  passed: boolean("passed").default(false),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAttempt = typeof quizAttempts.$inferInsert;

/**
 * Scenarios table - interactive cybersecurity scenarios
 */
export const scenarios = mysqlTable("scenarios", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  scenarioType: mysqlEnum("scenarioType", ["phishing", "fake-link", "social-engineering", "malware", "password"]),
  content: json("content"),
  correctAnswer: text("correctAnswer"),
  explanation: text("explanation"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Scenario = typeof scenarios.$inferSelect;
export type InsertScenario = typeof scenarios.$inferInsert;

/**
 * Scenario attempts table - student scenario interactions
 */
export const scenarioAttempts = mysqlTable("scenarioAttempts", {
  id: int("id").autoincrement().primaryKey(),
  scenarioId: int("scenarioId").notNull(),
  userId: int("userId").notNull(),
  userAnswer: text("userAnswer"),
  isCorrect: boolean("isCorrect"),
  timeSpent: int("timeSpent"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ScenarioAttempt = typeof scenarioAttempts.$inferSelect;
export type InsertScenarioAttempt = typeof scenarioAttempts.$inferInsert;

/**
 * AI interactions table - track AI assistant conversations
 */
export const aiInteractions = mysqlTable("aiInteractions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  lessonId: int("lessonId"),
  question: text("question").notNull(),
  answer: text("answer"),
  context: text("context"),
  isHelpful: boolean("isHelpful"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AIInteraction = typeof aiInteractions.$inferSelect;
export type InsertAIInteraction = typeof aiInteractions.$inferInsert;

/**
 * Notifications table - system notifications for students
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["progress", "warning", "achievement", "suggestion", "admin"]),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  actionUrl: varchar("actionUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Analytics table - track student analytics for admin dashboard
 */
export const analytics = mysqlTable("analytics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  lessonId: int("lessonId"),
  eventType: varchar("eventType", { length: 50 }),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = typeof analytics.$inferInsert;

/**
 * Admin logs table - track admin actions
 */
export const adminLogs = mysqlTable("adminLogs", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  targetType: varchar("targetType", { length: 50 }),
  targetId: int("targetId"),
  details: json("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertAdminLog = typeof adminLogs.$inferInsert;

/**
 * Comments table - student feedback and comments on lessons
 */
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  lessonId: int("lessonId").notNull(),
  text: text("text").notNull(),
  rating: int("rating").default(5),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

/**
 * Skills table - student skills earned from lessons
 */
export const skills = mysqlTable("skills", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  points: int("points").default(10),
  level: mysqlEnum("level", ["مبتدئ", "متوسط", "محترف"]).default("مبتدئ"),
  lessonId: int("lessonId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = typeof skills.$inferInsert;

/**
 * Rankings table - student rankings and leaderboard
 */
export const rankings = mysqlTable("rankings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  totalPoints: int("totalPoints").default(0),
  rank: int("rank"),
  skillsCount: int("skillsCount").default(0),
  commentsCount: int("commentsCount").default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ranking = typeof rankings.$inferSelect;
export type InsertRanking = typeof rankings.$inferInsert;

/**
 * Security Concepts table - cybersecurity learning concepts
 */
export const concepts = mysqlTable("concepts", {
  id: int("id").autoincrement().primaryKey(),
  conceptId: varchar("conceptId", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  risk: text("risk"),
  example: text("example"),
  prevention: text("prevention"),
  orderIndex: int("orderIndex").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Concept = typeof concepts.$inferSelect;
export type InsertConcept = typeof concepts.$inferInsert;

/**
 * Badges table - achievement badges
 */
export const badges = mysqlTable("badges", {
  id: int("id").autoincrement().primaryKey(),
  badgeId: varchar("badgeId", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 255 }),
  orderIndex: int("orderIndex").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = typeof badges.$inferInsert;

/**
 * Achievements table - student badges and achievements
 */
export const achievements = mysqlTable("achievements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  badge: varchar("badge", { length: 255 }).notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = typeof achievements.$inferInsert;


/**
 * Cybersecurity News table - latest cybersecurity news and updates
 */
export const cybersecurityNews = mysqlTable("cybersecurityNews", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  summary: text("summary"),
  source: varchar("source", { length: 255 }),
  sourceUrl: varchar("sourceUrl", { length: 500 }),
  category: mysqlEnum("category", ["تهديدات", "نصائح", "تحديثات", "أبحاث", "أحداث", "أخرى"]).default("أخرى"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  severity: mysqlEnum("severity", ["منخفضة", "متوسطة", "عالية", "حرجة"]).default("متوسطة"),
  isPublished: boolean("isPublished").default(true),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CybersecurityNews = typeof cybersecurityNews.$inferSelect;
export type InsertCybersecurityNews = typeof cybersecurityNews.$inferInsert;


/**
 * News Notifications table - notifications for breaking news
 */
export const newsNotifications = mysqlTable("newsNotifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  newsId: int("newsId").notNull(),
  type: mysqlEnum("type", ["breaking", "urgent", "important", "info"]).default("info"),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NewsNotification = typeof newsNotifications.$inferSelect;
export type InsertNewsNotification = typeof newsNotifications.$inferInsert;

/**
 * User Notification Preferences table - user preferences for notifications
 */
export const userNotificationPreferences = mysqlTable("userNotificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  enableNotifications: boolean("enableNotifications").default(true),
  enableCritical: boolean("enableCritical").default(true),
  enableHigh: boolean("enableHigh").default(true),
  enableMedium: boolean("enableMedium").default(false),
  enableLow: boolean("enableLow").default(false),
  enableSound: boolean("enableSound").default(true),
  categories: json("categories"), // Array of categories user is interested in
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserNotificationPreference = typeof userNotificationPreferences.$inferSelect;
export type InsertUserNotificationPreference = typeof userNotificationPreferences.$inferInsert;


/**
 * Device Tokens table - FCM tokens for push notifications
 */
export const deviceTokens = mysqlTable("deviceTokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fcmToken: varchar("fcmToken", { length: 500 }).notNull().unique(),
  deviceName: varchar("deviceName", { length: 255 }),
  userAgent: text("userAgent"),
  isActive: boolean("isActive").default(true),
  lastUsedAt: timestamp("lastUsedAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DeviceToken = typeof deviceTokens.$inferSelect;
export type InsertDeviceToken = typeof deviceTokens.$inferInsert;
