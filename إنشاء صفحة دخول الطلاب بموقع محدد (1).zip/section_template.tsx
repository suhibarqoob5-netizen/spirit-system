// Template: New Section Card Component
// استخدم هذا القالب لإضافة أقسام جديدة إلى منصتك التعليمية

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface SectionCardProps {
  title: string;
  emoji: string;
  description: string;
  colorScheme: "pink" | "cyan" | "purple" | "green" | "orange";
  buttonText: string;
  route: string;
}

const colorMap = {
  pink: {
    gradient: "from-pink-900/30 to-pink-800/20",
    border: "border-pink-500/30",
    hover: "hover:border-pink-500",
    button: "from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700"
  },
  cyan: {
    gradient: "from-cyan-900/30 to-cyan-800/20",
    border: "border-cyan-500/30",
    hover: "hover:border-cyan-500",
    button: "from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700"
  },
  purple: {
    gradient: "from-purple-900/30 to-purple-800/20",
    border: "border-purple-500/30",
    hover: "hover:border-purple-500",
    button: "from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
  },
  green: {
    gradient: "from-green-900/30 to-green-800/20",
    border: "border-green-500/30",
    hover: "hover:border-green-500",
    button: "from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
  },
  orange: {
    gradient: "from-orange-900/30 to-orange-800/20",
    border: "border-orange-500/30",
    hover: "hover:border-orange-500",
    button: "from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
  }
};

export function SectionCard({
  title,
  emoji,
  description,
  colorScheme,
  buttonText,
  route
}: SectionCardProps) {
  const [, setLocation] = useLocation();
  const colors = colorMap[colorScheme];

  return (
    <Card
      className={`bg-gradient-to-br ${colors.gradient} ${colors.border} p-8 ${colors.hover} transition cursor-pointer group`}
      onClick={() => setLocation(route)}
    >
      <div className="text-5xl mb-6">{emoji}</div>
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-slate-300 mb-6">{description}</p>
      <Button
        className={`w-full bg-gradient-to-r ${colors.button} text-white`}
        onClick={(e) => {
          e.stopPropagation();
          setLocation(route);
        }}
      >
        {buttonText}
      </Button>
    </Card>
  );
}

// Usage Example:
// <SectionCard
//   title="عطر الفرموزة"
//   emoji="🌺"
//   description="قسم متخصص: المحتوى المتقدم، الأبحاث الأمنية، والتطبيقات العملية للحماية الرقمية"
//   colorScheme="purple"
//   buttonText="استكشف الآن"
//   route="/program/perfume-plum"
// />

// ============================================
// Template: Navigation Button
// ============================================

export function NavButton({
  label,
  emoji,
  route
}: {
  label: string;
  emoji: string;
  route: string;
}) {
  const [, setLocation] = useLocation();

  return (
    <button
      onClick={() => setLocation(route)}
      className="hover:text-cyan-400 transition bg-none border-none cursor-pointer"
    >
      {emoji} {label}
    </button>
  );
}

// ============================================
// Template: Footer Link
// ============================================

export function FooterLink({
  label,
  emoji,
  route
}: {
  label: string;
  emoji: string;
  route: string;
}) {
  const [, setLocation] = useLocation();

  return (
    <button
      onClick={() => setLocation(route)}
      className="text-slate-400 hover:text-cyan-400 transition text-sm bg-none border-none cursor-pointer"
    >
      {emoji} {label}
    </button>
  );
}

// ============================================
// Template: Poetry/Text Section
// ============================================

export function PoetrySection({
  lines
}: {
  lines: string[];
}) {
  return (
    <div className="mt-6 text-center">
      {lines.map((line, index) => (
        <p
          key={index}
          className={`text-slate-400 text-sm ${index > 0 ? "mt-1" : ""}`}
        >
          {line}
        </p>
      ))}
    </div>
  );
}

// Usage Example:
// <PoetrySection
//   lines={[
//     "تطير النحلة تشدو بين ألوان الزهور",
//     "بين زهرة البرقوق وعطر الفرموزة يحلو"
//   ]}
// />
