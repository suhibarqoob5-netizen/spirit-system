import { publicProcedure, router } from "../_core/trpc";
import * as db from "../db";

export const seedRouter = router({
  // Seed data for programs, levels, courses, and lessons
  seedData: publicProcedure.mutation(async () => {
    try {
      // 1. Create Programs
      const programs = [
        { title: "زهرة البرقوق", slug: "plum-blossom-girls", description: "برنامج شامل لحماية البنات والفتيات في الفضاء الرقمي", icon: "🌸", isPublished: true },
        { title: "غصن البرقوق", slug: "plum-branch-boys", description: "برنامج متقدم لتعليم الشباب مهارات الأمان الرقمي", icon: "🌿", isPublished: true },
        { title: "عطر الفرموزة", slug: "fragrant-apricot", description: "برنامج متخصص في حماية الخصوصية والأمان الرقمي المتقدم", icon: "🌺", isPublished: true },
      ];

      let programCount = 0;
      const programIds: number[] = [];
      try {
        for (const program of programs) {
          try {
            const result = await db.createProgram(program);
            programCount++;
            programIds.push((result as any).insertId || programCount);
          } catch (e) {
            console.log("Error creating program:", e);
          }
        }
      } catch (e) {
        console.log("Error creating programs:", e);
      }

      // 2. Create Levels
      const levels = [
        { programId: 1, levelNumber: 1, title: "المستوى الأول", description: "مقدمة عن الأمان الرقمي" },
        { programId: 1, levelNumber: 2, title: "المستوى الثاني", description: "الحماية المتقدمة" },
        { programId: 1, levelNumber: 3, title: "المستوى الثالث", description: "الخصوصية والأمان" },
        { programId: 2, levelNumber: 1, title: "المستوى الأول", description: "مقدمة عن الأمان الرقمي" },
        { programId: 2, levelNumber: 2, title: "المستوى الثاني", description: "الحماية المتقدمة" },
        { programId: 3, levelNumber: 1, title: "المستوى الأول", description: "الخصوصية والأمان المتقدم" },
      ];

      let levelCount = 0;
      try {
        for (const level of levels) {
          try {
            await db.createLevel(level);
            levelCount++;
          } catch (e) {
            console.log("Error creating level:", e);
          }
        }
      } catch (e) {
        console.log("Error creating levels:", e);
      }

      // 3. Create Courses
      const courses = [
        // Level 1
        { levelId: 1, title: "حماية البيانات", slug: "course-1-1", description: "تعلم كيفية حماية بياناتك الشخصية", orderIndex: 1 },
        { levelId: 1, title: "حماية كلمات المرور", slug: "course-1-2", description: "أساسيات حماية كلمات المرور", orderIndex: 2 },
        // Level 2
        { levelId: 2, title: "الأمان الرقمي", slug: "course-2-1", description: "مفاهيم الأمان الرقمي المتقدمة", orderIndex: 1 },
        { levelId: 2, title: "الخصوصية الرقمية", slug: "course-2-2", description: "حماية الخصوصية على الإنترنت", orderIndex: 2 },
        // Level 3
        { levelId: 3, title: "مواجهة الابتزاز", slug: "course-3-1", description: "كيفية التعامل مع الابتزاز الإلكتروني", orderIndex: 1 },
        { levelId: 3, title: "الحماية من التجسس", slug: "course-3-2", description: "تقنيات الحماية من التجسس", orderIndex: 2 },
        // Program 2 - Level 1
        { levelId: 4, title: "أساسيات الأمان", slug: "course-4-1", description: "أساسيات الأمان الرقمي للشباب", orderIndex: 1 },
        { levelId: 4, title: "الحماية من الاختراق", slug: "course-4-2", description: "حماية الحسابات من الاختراق", orderIndex: 2 },
        // Program 2 - Level 2
        { levelId: 5, title: "الأمان المتقدم", slug: "course-5-1", description: "تقنيات أمان متقدمة", orderIndex: 1 },
        { levelId: 5, title: "الحماية من البرامج الضارة", slug: "course-5-2", description: "حماية الجهاز من البرامج الضارة", orderIndex: 2 },
        // Program 3 - Level 1
        { levelId: 6, title: "الخصوصية المتقدمة", slug: "course-6-1", description: "حماية الخصوصية المتقدمة", orderIndex: 1 },
        { levelId: 6, title: "الأمان الشامل", slug: "course-6-2", description: "نظام أمان شامل", orderIndex: 2 },
      ];

      let courseCount = 0;
      try {
        for (const course of courses) {
          try {
            await db.createCourse(course);
            courseCount++;
          } catch (e) {
            console.log("Error creating course:", e);
          }
        }
      } catch (e) {
        console.log("Error creating courses:", e);
      }

      // 4. Create Lessons
      const lessons = [
        // Level 1 courses
        { courseId: 1, title: "درس 1: مقدمة", slug: "lesson-1-1", description: "مقدمة عن حماية البيانات", stage: 1, orderIndex: 1 },
        { courseId: 1, title: "درس 2: التطبيق العملي", slug: "lesson-1-2", description: "تطبيق عملي لحماية البيانات", stage: 1, orderIndex: 2 },
        { courseId: 2, title: "درس 1: مقدمة", slug: "lesson-2-1", description: "مقدمة عن حماية كلمات المرور", stage: 1, orderIndex: 1 },
        { courseId: 2, title: "درس 2: التطبيق العملي", slug: "lesson-2-2", description: "تطبيق عملي لحماية كلمات المرور", stage: 1, orderIndex: 2 },
        { courseId: 3, title: "درس 1: مقدمة", slug: "lesson-3-1", description: "مقدمة عن الأمان الرقمي", stage: 1, orderIndex: 1 },
        { courseId: 3, title: "درس 2: التطبيق العملي", slug: "lesson-3-2", description: "تطبيق عملي للأمان الرقمي", stage: 1, orderIndex: 2 },
        { courseId: 4, title: "درس 1: مقدمة", slug: "lesson-4-1", description: "مقدمة عن الخصوصية الرقمية", stage: 1, orderIndex: 1 },
        { courseId: 4, title: "درس 2: التطبيق العملي", slug: "lesson-4-2", description: "تطبيق عملي للخصوصية الرقمية", stage: 1, orderIndex: 2 },
        // Level 2 courses
        { courseId: 5, title: "درس 1: مقدمة", slug: "lesson-5-1", description: "مقدمة عن مواجهة الابتزاز", stage: 1, orderIndex: 1 },
        { courseId: 5, title: "درس 2: التطبيق العملي", slug: "lesson-5-2", description: "تطبيق عملي لمواجهة الابتزاز", stage: 1, orderIndex: 2 },
        { courseId: 6, title: "درس 1: مقدمة", slug: "lesson-6-1", description: "مقدمة عن الحماية من التجسس", stage: 1, orderIndex: 1 },
        { courseId: 6, title: "درس 2: التطبيق العملي", slug: "lesson-6-2", description: "تطبيق عملي للحماية من التجسس", stage: 1, orderIndex: 2 },
        // Program 2 courses
        { courseId: 7, title: "درس 1: مقدمة", slug: "lesson-7-1", description: "مقدمة عن أساسيات الأمان", stage: 1, orderIndex: 1 },
        { courseId: 7, title: "درس 2: التطبيق العملي", slug: "lesson-7-2", description: "تطبيق عملي لأساسيات الأمان", stage: 1, orderIndex: 2 },
        { courseId: 8, title: "درس 1: مقدمة", slug: "lesson-8-1", description: "مقدمة عن الحماية من الاختراق", stage: 1, orderIndex: 1 },
        { courseId: 8, title: "درس 2: التطبيق العملي", slug: "lesson-8-2", description: "تطبيق عملي للحماية من الاختراق", stage: 1, orderIndex: 2 },
        { courseId: 9, title: "درس 1: مقدمة", slug: "lesson-9-1", description: "مقدمة عن الأمان المتقدم", stage: 1, orderIndex: 1 },
        { courseId: 9, title: "درس 2: التطبيق العملي", slug: "lesson-9-2", description: "تطبيق عملي للأمان المتقدم", stage: 1, orderIndex: 2 },
        { courseId: 10, title: "درس 1: مقدمة", slug: "lesson-10-1", description: "مقدمة عن الحماية من البرامج الضارة", stage: 1, orderIndex: 1 },
        { courseId: 10, title: "درس 2: التطبيق العملي", slug: "lesson-10-2", description: "تطبيق عملي للحماية من البرامج الضارة", stage: 1, orderIndex: 2 },
        // Program 3 courses
        { courseId: 11, title: "درس 1: مقدمة", slug: "lesson-11-1", description: "مقدمة عن الخصوصية المتقدمة", stage: 1, orderIndex: 1 },
        { courseId: 11, title: "درس 2: التطبيق العملي", slug: "lesson-11-2", description: "تطبيق عملي للخصوصية المتقدمة", stage: 1, orderIndex: 2 },
        { courseId: 12, title: "درس 1: مقدمة", slug: "lesson-12-1", description: "مقدمة عن الأمان الشامل", stage: 1, orderIndex: 1 },
        { courseId: 12, title: "درس 2: التطبيق العملي", slug: "lesson-12-2", description: "تطبيق عملي للأمان الشامل", stage: 1, orderIndex: 2 },
      ];

      let lessonCount = 0;
      try {
        for (const lesson of lessons) {
          try {
            await db.createLesson(lesson);
            lessonCount++;
          } catch (e) {
            console.log("Error creating lesson:", e);
          }
        }
      } catch (e) {
        console.log("Error creating lessons:", e);
      }

      return {
        success: true,
        message: "Seed data created successfully",
        data: {
          programs: programCount,
          levels: levelCount,
          courses: courseCount,
          lessons: lessonCount,
        },
      };
    } catch (error) {
      console.error("Seed error:", error);
      return {
        success: false,
        message: "Failed to seed data",
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),
});
