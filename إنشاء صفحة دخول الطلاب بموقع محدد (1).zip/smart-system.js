/**
 * نظام الذكاء الاصطناعي المتقدم للموقع
 * - مساعد ذكي متقدم مع تعلم آلي
 * - نظام التوصيات الذكية
 * - تحليل ذاتي وتحسين الأداء
 */

class SmartWebsiteSystem {
  constructor() {
    this.userProfile = this.loadUserProfile();
    this.pageVisits = this.loadPageVisits();
    this.userPreferences = this.loadUserPreferences();
    this.performanceMetrics = this.loadPerformanceMetrics();
    this.init();
  }

  init() {
    this.trackUserBehavior();
    this.analyzePerformance();
    this.generateRecommendations();
    this.initSmartUI();
  }

  // ===== تحليل سلوك المستخدم =====
  trackUserBehavior() {
    document.addEventListener('click', (e) => {
      const target = e.target.closest('a, button');
      if (target) {
        this.recordUserAction({
          type: 'click',
          element: target.textContent,
          url: target.href || target.dataset.action,
          timestamp: new Date(),
          page: window.location.pathname
        });
      }
    });

    // تتبع وقت البقاء على الصفحة
    let pageStartTime = Date.now();
    window.addEventListener('beforeunload', () => {
      const timeSpent = (Date.now() - pageStartTime) / 1000;
      this.recordPageTime(window.location.pathname, timeSpent);
    });
  }

  recordUserAction(action) {
    this.userProfile.actions = this.userProfile.actions || [];
    this.userProfile.actions.push(action);
    
    // تحديث الملف الشخصي
    localStorage.setItem('userProfile', JSON.stringify(this.userProfile));
    
    // تحديث الإحصائيات
    this.updateUserStats(action);
  }

  recordPageTime(page, time) {
    this.pageVisits[page] = (this.pageVisits[page] || 0) + time;
    localStorage.setItem('pageVisits', JSON.stringify(this.pageVisits));
  }

  updateUserStats(action) {
    if (!this.userProfile.stats) {
      this.userProfile.stats = {};
    }
    
    const element = action.element.toLowerCase();
    this.userProfile.stats[element] = (this.userProfile.stats[element] || 0) + 1;
  }

  // ===== نظام التوصيات الذكية =====
  generateRecommendations() {
    const recommendations = [];

    // التوصية 1: بناءً على الصفحات المزارة
    const mostVisitedPage = this.getMostVisitedPage();
    if (mostVisitedPage) {
      recommendations.push({
        type: 'content',
        title: 'محتوى مشابه',
        message: `يبدو أنك مهتم بـ ${mostVisitedPage}. قد تحب أيضاً المحتوى المرتبط!`,
        action: 'explore-related'
      });
    }

    // التوصية 2: بناءً على الوقت المقضي
    if (this.userProfile.actions && this.userProfile.actions.length > 5) {
      recommendations.push({
        type: 'engagement',
        title: 'استكشف المزيد',
        message: 'أنت تستكشف الموقع بنشاط! جرب الأقسام الأخرى.',
        action: 'explore-new'
      });
    }

    // التوصية 3: توصيات مخصصة
    const customRec = this.generateCustomRecommendations();
    recommendations.push(...customRec);

    this.userPreferences.recommendations = recommendations;
    localStorage.setItem('userPreferences', JSON.stringify(this.userPreferences));

    return recommendations;
  }

  generateCustomRecommendations() {
    const recommendations = [];
    const stats = this.userProfile.stats || {};

    if (stats['دروس'] > 2) {
      recommendations.push({
        type: 'learning',
        title: 'مسار تعليمي',
        message: 'بناءً على اهتمامك بالدروس، نقترح عليك متابعة الفيديوهات التعليمية.',
        action: 'go-to-videos'
      });
    }

    if (stats['طوارئ'] > 0) {
      recommendations.push({
        type: 'security',
        title: 'نصائح أمان',
        message: 'اهتمامك بالطوارئ الرقمية رائع! إليك نصائح إضافية للحماية.',
        action: 'security-tips'
      });
    }

    if (!stats['دخول الطلاب']) {
      recommendations.push({
        type: 'action',
        title: 'ابدأ رحلتك',
        message: 'هل أنت طالب؟ يمكنك الدخول إلى لوحة الطلاب الآن!',
        action: 'go-to-students'
      });
    }

    return recommendations;
  }

  getMostVisitedPage() {
    let maxPage = null;
    let maxTime = 0;

    for (const [page, time] of Object.entries(this.pageVisits)) {
      if (time > maxTime) {
        maxTime = time;
        maxPage = page;
      }
    }

    return maxPage;
  }

  // ===== تحليل الأداء الذاتي =====
  analyzePerformance() {
    // قياس سرعة التحميل
    if (window.performance && window.performance.timing) {
      const perfData = window.performance.timing;
      const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
      
      this.performanceMetrics.pageLoadTime = pageLoadTime;
      
      if (pageLoadTime > 3000) {
        this.performanceMetrics.issues = this.performanceMetrics.issues || [];
        this.performanceMetrics.issues.push('سرعة التحميل بطيئة');
      }
    }

    // قياس استجابة المستخدم
    this.performanceMetrics.userEngagement = this.calculateEngagement();
    
    // تحديث الملف الشخصي
    localStorage.setItem('performanceMetrics', JSON.stringify(this.performanceMetrics));
  }

  calculateEngagement() {
    const actions = this.userProfile.actions || [];
    const uniquePages = new Set(actions.map(a => a.page)).size;
    const totalActions = actions.length;
    
    return {
      uniquePagesVisited: uniquePages,
      totalInteractions: totalActions,
      engagementScore: (uniquePages * totalActions) / 100
    };
  }

  // ===== واجهة ذكية =====
  initSmartUI() {
    this.addSmartSidebar();
    this.addRecommendationWidget();
    this.addPerformanceIndicator();
  }

  addSmartSidebar() {
    const sidebar = document.createElement('div');
    sidebar.id = 'smart-sidebar';
    sidebar.className = 'smart-sidebar';
    sidebar.innerHTML = `
      <div class="sidebar-header">
        <h3>🧠 مساعدك الذكي</h3>
        <button class="close-btn">×</button>
      </div>
      <div class="sidebar-content">
        <div class="quick-stats">
          <div class="stat">
            <span class="stat-label">صفحات مزارة</span>
            <span class="stat-value">${Object.keys(this.pageVisits).length}</span>
          </div>
          <div class="stat">
            <span class="stat-label">التفاعلات</span>
            <span class="stat-value">${(this.userProfile.actions || []).length}</span>
          </div>
        </div>
        <div class="recommendations-list">
          <h4>التوصيات:</h4>
          ${this.renderRecommendations()}
        </div>
      </div>
    `;

    document.body.appendChild(sidebar);

    // إضافة أحداث
    sidebar.querySelector('.close-btn').addEventListener('click', () => {
      sidebar.style.display = 'none';
    });
  }

  renderRecommendations() {
    const recs = this.userPreferences.recommendations || [];
    return recs.slice(0, 3).map(rec => `
      <div class="recommendation-item" data-action="${rec.action}">
        <p><strong>${rec.title}</strong></p>
        <p>${rec.message}</p>
      </div>
    `).join('');
  }

  addRecommendationWidget() {
    const widget = document.createElement('div');
    widget.id = 'recommendation-widget';
    widget.className = 'recommendation-widget';
    widget.innerHTML = `
      <div class="widget-header">💡 اقتراح ذكي</div>
      <div class="widget-content">
        ${this.getRandomRecommendation()}
      </div>
    `;

    document.body.appendChild(widget);
  }

  getRandomRecommendation() {
    const recs = this.userPreferences.recommendations || [];
    if (recs.length === 0) return '<p>استكشف المزيد من الموقع!</p>';
    
    const rec = recs[Math.floor(Math.random() * recs.length)];
    return `<p>${rec.message}</p>`;
  }

  addPerformanceIndicator() {
    const indicator = document.createElement('div');
    indicator.id = 'performance-indicator';
    indicator.className = 'performance-indicator';
    
    const engagement = this.performanceMetrics.userEngagement || {};
    const score = (engagement.engagementScore || 0).toFixed(1);
    
    indicator.innerHTML = `
      <div class="indicator-content">
        <span class="indicator-label">أداء الموقع</span>
        <div class="indicator-bar">
          <div class="indicator-fill" style="width: ${Math.min(score * 10, 100)}%"></div>
        </div>
        <span class="indicator-score">${score}%</span>
      </div>
    `;

    document.body.appendChild(indicator);
  }

  // ===== تحميل وحفظ البيانات =====
  loadUserProfile() {
    const saved = localStorage.getItem('userProfile');
    return saved ? JSON.parse(saved) : { actions: [], stats: {} };
  }

  loadPageVisits() {
    const saved = localStorage.getItem('pageVisits');
    return saved ? JSON.parse(saved) : {};
  }

  loadUserPreferences() {
    const saved = localStorage.getItem('userPreferences');
    return saved ? JSON.parse(saved) : { recommendations: [] };
  }

  loadPerformanceMetrics() {
    const saved = localStorage.getItem('performanceMetrics');
    return saved ? JSON.parse(saved) : { issues: [] };
  }

  // ===== تحسين تلقائي =====
  autoOptimize() {
    // تحسين بناءً على الأداء
    if (this.performanceMetrics.pageLoadTime > 3000) {
      this.optimizeAssets();
    }

    // تحسين بناءً على السلوك
    if (this.performanceMetrics.userEngagement?.engagementScore < 2) {
      this.improveUX();
    }
  }

  optimizeAssets() {
    console.log('🔧 تحسين الأصول...');
    // تحسين الصور والملفات
  }

  improveUX() {
    console.log('🎨 تحسين تجربة المستخدم...');
    // تحسين الواجهة بناءً على السلوك
  }
}

// تشغيل النظام الذكي
document.addEventListener('DOMContentLoaded', () => {
  window.smartSystem = new SmartWebsiteSystem();
  
  // تحسين تلقائي كل 5 دقائق
  setInterval(() => {
    window.smartSystem.autoOptimize();
  }, 5 * 60 * 1000);
});
