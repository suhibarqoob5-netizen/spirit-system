import { describe, it, expect, beforeAll } from 'vitest';
import { getDb } from './db';
import {
  getThreatStatisticsByType,
  getThreatStatisticsBySeverity,
  getThreatFrequencyTrends,
  getGeographicThreatDistribution,
  getTopCountriesByAttacks,
  getGlobalAttackStatistics,
  getThreatImpactAnalysis,
} from './db';

describe('Threat Analytics API', () => {
  beforeAll(async () => {
    const db = await getDb();
    if (!db) {
      throw new Error('Database connection failed');
    }
  });

  describe('Threat Statistics by Type', () => {
    it('should return threat statistics grouped by type', async () => {
      const result = await getThreatStatisticsByType();
      expect(Array.isArray(result)).toBe(true);
      
      if (result.length > 0) {
        expect(result[0]).toHaveProperty('name');
        expect(result[0]).toHaveProperty('value');
        expect(result[0]).toHaveProperty('frequency');
        expect(typeof result[0].value).toBe('number');
      }
    });
  });

  describe('Threat Statistics by Severity', () => {
    it('should return threat count by severity level', async () => {
      const result = await getThreatStatisticsBySeverity();
      expect(result).toHaveProperty('منخفضة');
      expect(result).toHaveProperty('متوسطة');
      expect(result).toHaveProperty('عالية');
      expect(result).toHaveProperty('حرجة');
      expect(typeof result.منخفضة).toBe('number');
      expect(typeof result.متوسطة).toBe('number');
      expect(typeof result.عالية).toBe('number');
      expect(typeof result.حرجة).toBe('number');
    });
  });

  describe('Threat Frequency Trends', () => {
    it('should return threat frequency trends over time', async () => {
      const result = await getThreatFrequencyTrends();
      expect(Array.isArray(result)).toBe(true);
      
      if (result.length > 0) {
        expect(result[0]).toHaveProperty('date');
        expect(result[0]).toHaveProperty('occurrences');
        expect(typeof result[0].occurrences).toBe('number');
      }
    });
  });

  describe('Geographic Threat Distribution', () => {
    it('should return threat statistics by country', async () => {
      const result = await getGeographicThreatDistribution();
      expect(Array.isArray(result)).toBe(true);
      
      if (result.length > 0) {
        expect(result[0]).toHaveProperty('country');
        expect(result[0]).toHaveProperty('totalAttacks');
        expect(result[0]).toHaveProperty('criticalCount');
        expect(result[0]).toHaveProperty('highCount');
        expect(result[0]).toHaveProperty('mediumCount');
        expect(result[0]).toHaveProperty('lowCount');
        expect(typeof result[0].totalAttacks).toBe('number');
      }
    });
  });

  describe('Top Countries by Attacks', () => {
    it('should return top countries by attack count', async () => {
      const result = await getTopCountriesByAttacks(10);
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeLessThanOrEqual(10);
      
      if (result.length > 1) {
        const first = result[0].totalAttacks || 0;
        const second = result[1].totalAttacks || 0;
        expect(first).toBeGreaterThanOrEqual(second);
      }
    });

    it('should respect limit parameter', async () => {
      const result = await getTopCountriesByAttacks(5);
      expect(result.length).toBeLessThanOrEqual(5);
    });
  });

  describe('Global Attack Statistics', () => {
    it('should return global attack statistics', async () => {
      const result = await getGlobalAttackStatistics();
      
      if (result) {
        expect(result).toHaveProperty('totalAttacksToday');
        expect(result).toHaveProperty('totalAttacksWeek');
        expect(result).toHaveProperty('totalAttacksMonth');
        expect(result).toHaveProperty('criticalThreats');
        expect(result).toHaveProperty('affectedCountries');
        expect(typeof result.totalAttacksToday).toBe('number');
      }
    });
  });

  describe('Threat Impact Analysis', () => {
    it('should return threats ranked by impact score', async () => {
      const result = await getThreatImpactAnalysis();
      expect(Array.isArray(result)).toBe(true);
      
      if (result.length > 0) {
        expect(result[0]).toHaveProperty('name');
        expect(result[0]).toHaveProperty('frequency');
        expect(result[0]).toHaveProperty('impactScore');
        expect(result[0]).toHaveProperty('severity');
        expect(typeof result[0].impactScore).toBe('number');
      }

      if (result.length > 1) {
        expect(result[0].impactScore).toBeGreaterThanOrEqual(result[1].impactScore);
      }
    });
  });

  describe('Data Consistency', () => {
    it('should have consistent data across different endpoints', async () => {
      const typesData = await getThreatStatisticsByType();
      const severityData = await getThreatStatisticsBySeverity();
      const impactData = await getThreatImpactAnalysis();

      const typesTotal = typesData.reduce((sum, t) => sum + t.value, 0);
      const severityTotal = Object.values(severityData).reduce((sum, count) => sum + count, 0);

      expect(typesTotal).toBeGreaterThanOrEqual(0);
      expect(severityTotal).toBeGreaterThanOrEqual(0);
      expect(impactData.length).toBeGreaterThanOrEqual(0);
    });
  });
});
