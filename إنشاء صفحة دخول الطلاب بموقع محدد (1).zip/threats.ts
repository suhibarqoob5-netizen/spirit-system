import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  getAllThreats,
  getThreatsByCategory,
  getTopThreats,
  getThreatById,
  getThreatStatisticsData,
  getThreatStatisticsByType,
  getThreatStatisticsBySeverity,
  getThreatFrequencyTrends,
  getGeographicThreatDistribution,
  getTopCountriesByAttacks,
  getGlobalAttackStatistics,
  getThreatImpactAnalysis,
} from "../db";

export const threatsRouter = router({
  getAll: publicProcedure.query(async () => {
    return await getAllThreats();
  }),

  getByCategory: publicProcedure
    .input(z.object({ category: z.string() }))
    .query(async ({ input }) => {
      return await getThreatsByCategory(input.category);
    }),

  getTopThreats: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      return await getTopThreats(input.limit);
    }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await getThreatById(input.id);
    }),

  getStatistics: publicProcedure
    .input(z.object({ threatId: z.number() }))
    .query(async ({ input }) => {
      return await getThreatStatisticsData(input.threatId);
    }),

  getCategories: publicProcedure.query(async () => {
    const threats = await getAllThreats();
    const categoriesSet = new Set(threats.map(t => t.category));
    const categories = Array.from(categoriesSet);
    return categories;
  }),

  getSeverityDistribution: publicProcedure.query(async () => {
    const threats = await getAllThreats();
    const distribution = {
      منخفضة: threats.filter(t => t.severity === "منخفضة").length,
      متوسطة: threats.filter(t => t.severity === "متوسطة").length,
      عالية: threats.filter(t => t.severity === "عالية").length,
      حرجة: threats.filter(t => t.severity === "حرجة").length,
    };
    return distribution;
  }),

  // New analytics endpoints for charts
  getStatisticsByType: publicProcedure.query(async () => {
    return await getThreatStatisticsByType();
  }),

  getStatisticsBySeverity: publicProcedure.query(async () => {
    return await getThreatStatisticsBySeverity();
  }),

  getFrequencyTrends: publicProcedure.query(async () => {
    return await getThreatFrequencyTrends();
  }),

  getGeographicDistribution: publicProcedure.query(async () => {
    return await getGeographicThreatDistribution();
  }),

  getTopCountries: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      return await getTopCountriesByAttacks(input.limit);
    }),

  getGlobalStats: publicProcedure.query(async () => {
    return await getGlobalAttackStatistics();
  }),

  getImpactAnalysis: publicProcedure.query(async () => {
    return await getThreatImpactAnalysis();
  }),
});
